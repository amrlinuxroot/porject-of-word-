// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { interfaceLocalization } from './scripts/interface-localization.mjs';

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
  },
  vite: {
    plugins: [interfaceLocalization()],
    // Pre-bundle deps up front so a mid-session re-optimization can't load two React copies.
    optimizeDeps: {
      include: [
        "react", "react-dom", "@supabase/supabase-js", "@lovable.dev/cloud-auth-js",
        "@radix-ui/react-slot", "@radix-ui/react-label", "@radix-ui/react-select", "@radix-ui/react-dialog", "@radix-ui/react-tabs", "@radix-ui/react-checkbox", "@radix-ui/react-popover", "@radix-ui/react-dropdown-menu",
        "class-variance-authority", "clsx", "lucide-react", "sonner", "tailwind-merge",
      ],
    },
  },
});
