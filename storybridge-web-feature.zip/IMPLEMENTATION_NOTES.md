# Team files and member cloud links

This source-only change set extends the supplied TanStack Start/Supabase website archive. It does not modify the original ZIP, attach a Webdev project, apply a database migration, or publish the website.

## Implemented in source

- `drizzle/migrations/0020_team_files_and_cloud_links.sql` adds a private `team-files` bucket, a project-linked `team_files` table, and `member_cloud_links` with row-level security.
- New team-file uploads are limited to PDF, DOC, DOCX and TXT, 20 MiB, and are private by default. Only a project owner or accepted member can upload. A file becomes readable to accepted members only after its uploader or project owner explicitly shares it. Signed download URLs last 60 seconds. The owner/uploader can unshare or delete subject to the storage policies.
- The Documents page lets each authenticated member save a private external folder/file link, or deliberately expose a link to an accepted project. Providers include Box, Google Drive, Dropbox, OneDrive, and a generic HTTPS provider. External links are not imported; the external provider controls its own sharing permissions.
- Supabase client table typings and focused validator tests were added.

## Required before production use

1. Review and apply migration 0020 to the intended Supabase database. It is additive; it creates new tables/bucket/policies and does not drop existing application tables or user data. The migration is not applied by this source patch.
2. Confirm the `team-files` bucket and policy statements compile against the target project's actual Supabase version and existing storage policies.
3. Run the app's lint, tests and production build after installing dependencies, then test with at least two real accounts (accepted member and non-member), including membership removal and signed-download expiry.
4. Configure malware scanning or keep the visible unscanned-file warning and accept the operational risk. This code does not claim that files are malware-scanned.
5. Validate provider sharing at Box/Google Drive/Dropbox/OneDrive: a team-visible URL does not grant access inside that provider.

## External service / database limits

No live database is attached in this task, so no SQL was executed against production or staging and no live RLS test was possible. No OAuth connection to external cloud providers is included; the feature stores HTTPS links only.


## Local validation on the isolated source copy

- `bun run test`: passed, 16 test files and 164 tests.
- `bun run build`: passed for the production bundle.
- `tsc --noEmit`: passed after correcting runtime provider validation and adding an invalid-provider regression assertion.
- Focused ESLint on all changed TS/TSX files: passed.
- Whole-repository ESLint remains failing with 1,650 errors and 11 warnings, predominantly formatting findings across the wider source tree. The changed application files pass the focused lint run.
- The migration is still unapplied. Its bucket creation now uses `ON CONFLICT DO NOTHING` and raises an exception if a pre-existing `team-files` bucket does not match the required private settings; it will not rewrite that bucket's configuration.
- These are source/build checks only. No two-account RLS test, live Supabase SQL validation, malware scan, or deployment was performed.
