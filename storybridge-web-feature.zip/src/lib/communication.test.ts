import { describe, it, expect } from "vitest";
import { onlineMembers, canReadDirectMessage, audienceAllows } from "./communication";
describe("member communication", () => {
  it("everyone allows email visibility to signed-out visitors", () => expect(audienceAllows("everyone", false, false)).toBe(true));
  it("members excludes visitors but allows signed-in members", () => { expect(audienceAllows("members", false, false)).toBe(false); expect(audienceAllows("members", true, false)).toBe(true); });
  it("admins excludes ordinary members", () => { expect(audienceAllows("admins", true, false)).toBe(false); expect(audienceAllows("admins", true, true)).toBe(true); });
  it("none denies even admins", () => expect(audienceAllows("none", true, true)).toBe(false));
  it("excludes stale connections and counts a member only once across tabs", () => {
    expect(onlineMembers([{ user_id: "a", last_seen: "2026-11-01T01:08:00Z" }, { user_id: "b", last_seen: "2026-11-01T01:06:30Z" }], Date.parse("2026-11-01T01:08:00Z")).map(r => r.user_id)).toEqual(["a"]);
  });
  it("keeps direct conversations private to participants", () => {
    const message = { sender_id: "a", recipient_id: "b" };
    expect(canReadDirectMessage("a", message)).toBe(true);
    expect(canReadDirectMessage("b", message)).toBe(true);
    expect(canReadDirectMessage("admin", message)).toBe(false);
  });
});