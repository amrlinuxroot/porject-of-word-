export const CHARTER_VERSION = '2026-11-01-v1';
export const CHARTER_JURISDICTIONS = 'السعودية، مصر، ألمانيا';
export const CHARTER_TEXT = 'أتعهد بالمحافظة على سرية الوثائق والشهادات والتقارير الطبية وجميع البيانات التي أتلقاها بصفتي مترجمًا معتمدًا، واستخدامها للترجمة المكلّف بها فقط. أتحمل مسؤولية حماية البيانات ضمن نطاق حيازتي، وعدم نشرها أو مشاركتها أو رفعها إلى خدمات الذكاء الاصطناعي أو أي طرف دون تفويض قانوني صريح. ألتزم بضوابط أمن البيانات والقوانين الواجبة التطبيق في بلد إقامتي والبلدان المعلنة لتشغيل مشروع كلمة: السعودية، مصر، ألمانيا، بحسب الاختصاص القانوني الفعلي. أبلغ الإدارة فورًا عن أي فقد أو تسريب، وأحذف النسخ بعد إتمام العمل وفق متطلبات الاحتفاظ القانونية. هذا التزام إلكتروني مسجل ولا يلغي المسؤوليات القانونية التي تقع على المنصة أو أي طرف آخر، ولا يثبت وحده صحة اعتماد مهني أو صلاحية توقيع قانونية في جميع البلدان.';
export const DOCUMENT_KINDS = { academic: 'شهادات ووثائق علمية', international: 'شهادات دولية', medical: 'تقارير طبية', legal: 'وثائق قانونية', other: 'وثائق أخرى' };
export const STATUS_LABELS: Record<string, string> = { pending: 'بانتظار الإدارة', open: 'متاح للمشاركة', assigned: 'قيد الترجمة', completed: 'مكتمل', rejected: 'مرفوض', approved: 'معتمد بعد المراجعة' };
export function canReceiveCertifiedDocument(input: { signedVersion?: string | undefined; approved: boolean; targetMatches: boolean; countryMatches: boolean; authorityMatches: boolean }) {
  return input.signedVersion === CHARTER_VERSION && input.approved && input.targetMatches && input.countryMatches && input.authorityMatches;
}
export function workModeMatches(preference: string, job: string) { return preference === 'both' || preference === job; }
export function quoteToCents(value: string): number | null {
  if (!value.trim()) return null;
  if (!/^\d+(\.\d{1,2})?$/.test(value.trim())) throw new Error('أدخل مبلغًا غير سالب بدقتين عشريتين كحد أقصى');
  const cents = Math.round(Number(value) * 100);
  if (!Number.isSafeInteger(cents) || cents > 2147483647) throw new Error('المبلغ خارج النطاق');
  return cents;
}