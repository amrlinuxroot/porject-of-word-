import { it, expect } from "vitest";
import { assembleTechnicalResult } from "./technical";
it("retains exact source code and identifiers in the combined translation result", () => {
  const source = 'def calculate_energy(mass_kg):\n    return mass_kg * SPEED_OF_LIGHT ** 2\n';
  expect(assembleTechnicalResult("code", source, "شرح الطاقة")).toContain(source);
  expect(assembleTechnicalResult("code", source, "شرح الطاقة").slice(0, -"شرح الطاقة".length)).toContain("calculate_energy(mass_kg)");
});
it("returns scientific translation and explanation without changing the result", () => expect(assembleTechnicalResult("scientific", "E=mc²", "الطاقة E=mc²")).toBe("الطاقة E=mc²"));