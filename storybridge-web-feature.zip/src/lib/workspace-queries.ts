import { queryOptions } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
export const documentsQuery = (userId: string, admin = false) => queryOptions({ queryKey: ['member-documents',userId,admin], queryFn: async()=>{
  const q=supabase.from('member_documents').select('*').order('created_at',{ascending:false});
  const {data,error}=await (admin?q:q.eq('user_id',userId));if(error)throw error;return data;
}});
export const tasksQuery = (userId:string) => queryOptions({queryKey:['member-tasks',userId],queryFn:async()=>{
  const {data,error}=await supabase.from('member_tasks').select('*').eq('user_id',userId).order('created_at',{ascending:false});if(error)throw error;return data;
}});
export const inboxQuery = (userId:string) => queryOptions({queryKey:['member-inbox',userId],queryFn:async()=>{
  const {data,error}=await supabase.from('direct_messages').select('*').or(`sender_id.eq.${userId},recipient_id.eq.${userId}`).order('created_at',{ascending:false});if(error)throw error;
  const ids=[...new Set(data.map(m=>m.sender_id===userId?m.recipient_id:m.sender_id))];
  const {data:profiles,error:pe}=ids.length?await supabase.from('profiles').select('id,display_name').in('id',ids):{data:[],error:null};if(pe)throw pe;
  return {messages:data,names:Object.fromEntries((profiles??[]).map(p=>[p.id,p.display_name]))};
}});