// Splits a text into pages. Explicit page breaks ("\f" or a line with only "---")
// are respected; otherwise paragraphs are packed up to ~maxChars per page.
export function splitIntoPages(text: string, maxChars = 1800): string[] {
  const clean = text.replace(/\r\n/g, "\n").trim();
  if (!clean) return [];
  const explicit = clean.split(/\f|\n\s*---\s*\n/).map((s) => s.trim()).filter(Boolean);
  if (explicit.length > 1) return explicit;
  const paras = clean.split(/\n\s*\n/);
  const pages: string[] = [];
  let cur = "";
  for (const p of paras) {
    if (cur && cur.length + p.length + 2 > maxChars) {
      pages.push(cur.trim());
      cur = "";
    }
    if (p.length > maxChars) {
      for (let i = 0; i < p.length; i += maxChars) pages.push(p.slice(i, i + maxChars).trim());
      continue;
    }
    cur += (cur ? "\n\n" : "") + p;
  }
  if (cur.trim()) pages.push(cur.trim());
  return pages;
}

export interface Share { translatorId: string; pages: number; cents: number }

// Book revenue: ops_percent covers operating costs, the rest is split among
// translators in proportion to how many selected pages each translated.
// The charity keeps no profit.
export function distributeRevenue(
  totalCents: number,
  opsPercent: number,
  selectedPagesByTranslator: Record<string, number>,
): { opsCents: number; shares: Share[] } {
  const entries = Object.entries(selectedPagesByTranslator).filter(([, n]) => n > 0);
  const totalPages = entries.reduce((s, [, n]) => s + n, 0);
  if (totalPages === 0) return { opsCents: totalCents, shares: [] };
  const opsCents = Math.round((totalCents * opsPercent) / 100);
  const pool = totalCents - opsCents;
  const shares = entries.map(([translatorId, pages]) => ({
    translatorId,
    pages,
    cents: Math.floor((pool * pages) / totalPages),
  }));
  // Give rounding remainder to translators (largest first) so nothing is retained.
  let rest = pool - shares.reduce((s, x) => s + x.cents, 0);
  shares.sort((a, b) => b.pages - a.pages);
  for (let i = 0; rest > 0; i = (i + 1) % shares.length, rest--) shares[i]!.cents++;
  return { opsCents, shares };
}

export const LANGUAGES = ["Arabic", "English", "French", "Spanish", "German", "Chinese", "Russian", "Hindi", "Portuguese", "Turkish", "Persian", "Urdu", "Japanese", "Swahili", "Italian"];
export const TECHNICAL_FIELDS = ["Technical", "Scientific", "Computer science", "Artificial intelligence", "Scientific documents", "Programming / code"];
export const FIELDS = ["Literary", "Poetry", ...TECHNICAL_FIELDS, "Medical", "Legal", "Philosophy", "History", "Religion", "Children's"];
export const formatMoney = (c: number) => `$${(c / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// Optional author royalty: taken from the translators' pool after operations, if the author asked for one.
export function authorRoyaltyCents(totalCents: number, opsPercent: number, authorPercent: number): number {
  if (authorPercent <= 0) return 0;
  const pool = totalCents - Math.round((totalCents * opsPercent) / 100);
  return Math.round((pool * Math.min(100, authorPercent)) / 100);
}

export const MAX_ACTIVE_PROJECTS = 5;

export const CONTRIBUTOR_ROLES = [
  { id: "translator", label: "Translator" },
  { id: "student", label: "Student" },
  { id: "writer", label: "Writer / author" },
  { id: "poet", label: "Poet" },
  { id: "publisher", label: "Publisher" },
  { id: "researcher", label: "Researcher / academic" },
  { id: "reader", label: "Reader / supporter" },
] as const;

export interface Segment { start: string; end: string; text: string }

// Parses subtitle-style blocks: "00:00:01,000 --> 00:00:04,000" followed by text lines (SRT numbering optional).
export function parseSegments(raw: string): Segment[] {
  const blocks = raw.replace(/\r\n/g, "\n").trim().split(/\n\s*\n/);
  const out: Segment[] = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l.trim());
    const i = lines.findIndex((l) => l.includes("-->"));
    if (i < 0) continue;
    const [start, end] = lines[i]!.split("-->").map((s) => s.trim());
    const text = lines.slice(i + 1).join("\n").trim();
    if (start && end && text) out.push({ start, end, text });
  }
  return out;
}

export function toSrt(segments: Segment[]): string {
  return segments.map((s, i) => `${i + 1}\n${s.start} --> ${s.end}\n${s.text}\n`).join("\n");
}

// Converts "HH:MM:SS,mmm" / "HH:MM:SS.mmm" / "MM:SS.mmm" to milliseconds; null if malformed.
export function timeToMs(t: string): number | null {
  const m = /^(?:(\d{1,2}):)?(\d{2}):(\d{2})[,.](\d{3})$/.exec(t.trim());
  if (!m) return null;
  const [, h = "0", min, s, ms] = m;
  if (Number(min) > 59 || Number(s) > 59) return null;
  return ((Number(h) * 60 + Number(min)) * 60 + Number(s)) * 1000 + Number(ms);
}

const pad = (n: number, w = 2) => String(n).padStart(w, "0");
export function msToTime(ms: number, sep: "," | "."): string {
  return `${pad(Math.floor(ms / 3600000))}:${pad(Math.floor(ms / 60000) % 60)}:${pad(Math.floor(ms / 1000) % 60)}${sep}${pad(ms % 1000, 3)}`;
}

export const MAX_LINE_CHARS = 42;
export const MAX_LINES = 2;
export interface SegmentIssue { index: number; level: "error" | "warning"; message: string }

// Errors block download (bad time, end before start, overlap, empty text); warnings are readability hints.
export function validateSegments(segments: Segment[]): SegmentIssue[] {
  const issues: SegmentIssue[] = [];
  let prevEnd = -1;
  segments.forEach((s, i) => {
    const a = timeToMs(s.start), b = timeToMs(s.end);
    if (a === null || b === null) issues.push({ index: i, level: "error", message: "Time format must be HH:MM:SS,mmm" });
    else {
      if (b <= a) issues.push({ index: i, level: "error", message: "End time must be after start time" });
      if (prevEnd >= 0 && a < prevEnd) issues.push({ index: i, level: "error", message: "Overlaps the previous segment" });
      prevEnd = b;
    }
    if (!s.text.trim()) issues.push({ index: i, level: "error", message: "Empty subtitle text" });
    const lines = s.text.split("\n");
    if (lines.length > MAX_LINES) issues.push({ index: i, level: "warning", message: `More than ${MAX_LINES} lines` });
    if (lines.some((l) => l.length > MAX_LINE_CHARS)) issues.push({ index: i, level: "warning", message: `Line longer than ${MAX_LINE_CHARS} characters` });
  });
  return issues;
}

export function toVtt(segments: Segment[]): string {
  const fix = (t: string) => { const ms = timeToMs(t); return ms === null ? t : msToTime(ms, "."); };
  return "WEBVTT\n\n" + segments.map((s, i) => `${i + 1}\n${fix(s.start)} --> ${fix(s.end)}\n${s.text}\n`).join("\n");
}
