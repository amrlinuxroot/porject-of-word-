import { FIELDS, LANGUAGES, CONTRIBUTOR_ROLES } from "@/lib/text";
export const MISSION = {
  eyebrow: "مشروع كلمة · ذاكرة للإنسان والإنسانية",
  title: "نترجم الكلمة، ونحفظ ذاكرة الإنسان",
  paragraphs: [
    "من بغداد إلى الإسكندرية، يذكّرنا ضياع المكتبات بأن فقدان المعرفة لا يمحو كتبًا فحسب، بل يطفئ شيئًا من ذاكرة الإنسانية. وما تبقى من هذا الإرث يحتاج إلى أيدٍ تصونه، ولغاتٍ تحمله إلى آفاق جديدة.",
    "مشروع كلمة مبادرة حضارية إنسانية عالمية لا تهدف للربح. نجتمع فيها لنحفظ ما أبدعه الإنسان من أدبٍ وعلمٍ وفكر، ونترجمه ونتشاركه عبر اللغات والثقافات، بعيدًا عن الحروب والدمار، وباحترام حقوق أصحاب الأعمال.",
    "نؤمن بأن الكتاب والكلمة والترجمة جسورٌ بين الأجيال؛ بها نُبقي المعرفة حيّة، ونورث أبناءنا ثمار التجربة الإنسانية ناضجةً أمينة، ليواصلوا بناء الحضارة. لسنا أصحاب هذا النور، بل أمناء عليه حتى نسلّمه إلى من يأتي بعدنا.",
    "كن معنا، وساهم بما تستطيع، ولو بترجمة كلمة واحدة. فكل كلمة تعبر إلى لغة أخرى تفتح نافذةً لإنسان جديد. معًا نحمل شراع الكلمة نحو المستقبل، ونسلّم مصباح المعرفة إلى أيدٍ تواصل الطريق.",
  ],
  closing: "حتى تحيا الكلمة، وتبقى المعرفة إرثًا مشتركًا للإنسانية.",
  join: "انضم إلى فريق مشروع كلمة",
};
export const HOME_STRINGS = [
  ...FIELDS, ...LANGUAGES, ...CONTRIBUTOR_ROLES.map(r => r.label),
  ...Object.values(MISSION).flat(),
  "Project of Word · مشروع كلمة", "Find a book. Or help it find a new language.",
  "Suggest a book or film", "Browse the library", "Join us",
  "Suggest a work", "Books, study books or films — always with the rights holder's permission.",
  "Translate together", "Volunteers matched by language and field translate page by page or scene by scene.",
  "Vote for the best", "The community votes; winners are notified the moment they're selected.",
  "Publish & share", "Google Books, Amazon KDP and our free reader. Proceeds go to translators — and the author, if they wish.",
  "Students", "Translate the science and study books your university or school uses, and help classmates everywhere.",
  "Writers & publishers", "Bring your book to new languages. You can receive a share of the translated book's sales.",
  "Films & multimedia", "Subtitle documentaries, lectures and films with time-coded segments and ready SRT files.",
  "Support the work", "We keep no profit. Donations fund servers, editing and outreach so more knowledge crosses more borders.",
  "Donate", "Library", "Free Library", "Store", "Contact", "Public Mail", "Join as translator", "About", "An idea by", "Menu",
  "Search books", "Title, author, language — or describe what you need", "Searching…", "Ask AI", "Nothing found yet. Try \"Ask AI\", or suggest this book for translation.", "Free library", "Translated",
  "Suggest a work to translate", "Books, study books, films or lectures. We only translate with the rights holder's permission.",
  "Type", "Book / text", "Poetry / poems", "Study book (school / university)", "Film / video / multimedia", "Title", "Author / creator", "Field", "Choose…", "Original language", "Translate into", "Short description", "Link to the file (MediaFire, Google Drive, Dropbox, YouTube…)", "Or upload a text / subtitle file from your computer (.txt, .md, .srt)", "Rights & permission", "Is the work protected by copyright?", "Do you have permission to translate it?", "Author / publisher name", "Author / publisher email", "Link to proof (permission letter, contract, licence page)", "Describe the permission", "The author would like a share of the translated book's sales", "Your name", "Your email", "You are a…", "I confirm the information above is true. I hold or have verified the translation rights, and I accept responsibility for any copyright claim caused by false information.", "Sending…", "Send suggestion",
  "Yes — it is protected by copyright", "No — public domain (author died 70+ years ago, or free worldwide)", "Open licence (Creative Commons / open access)", "I don't know", "I am the author / rights holder", "I have written permission from the author or publisher", "Not needed — public domain or open licence", "No permission yet — please contact the author",
  "e.g. Arabic, German", "e.g. Email from the author on 3 March 2026 allowing an Arabic translation", "An open book releasing lines of many scripts like birds", "For PDF, EPUB or video files, upload them to MediaFire / Google Drive and paste the link.", "Text file is too large — please share a link instead.", "Please answer the copyright and permission questions.", "A protected work needs the author's permission.", "Add a link to the permission document or describe it.", "Please confirm the rights declaration.", "Thank you! Our team will review the rights and contact you by email.", "Search failed",
];
export const HOME_COPY_VERSION = "mission-2026-11-01-v2";
export function validateHomeTranslation(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid translation");
  const entries = Object.entries(value);
  const dictionary = Object.fromEntries(entries);
  for (const source of HOME_STRINGS) {
    const translated = dictionary[source];
    if (typeof translated !== "string" || !translated.trim() || translated.length > 6000) throw new Error("Incomplete page translation");
  }
  return Object.fromEntries(HOME_STRINGS.map(s => [s, dictionary[s]]));
}