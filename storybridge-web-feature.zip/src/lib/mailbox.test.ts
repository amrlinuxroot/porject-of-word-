import { describe, expect, it } from "vitest";
import { assembleBook, checkCompleteness } from "./mailbox";

describe("checkCompleteness", () => {
  it("lists missing pages", () => {
    expect(checkCompleteness(5, [1, 3, 5])).toEqual({ missing: [2, 4], complete: false });
  });
  it("is complete when every page arrived", () => {
    expect(checkCompleteness(3, [3, 1, 2, 2]).complete).toBe(true);
  });
});

describe("assembleBook", () => {
  it("orders pages by page number", () => {
    expect(assembleBook([{ page_number: 2, content: "B" }, { page_number: 1, content: "A" }])).toBe("A\n\n— — —\n\nB");
  });
});
