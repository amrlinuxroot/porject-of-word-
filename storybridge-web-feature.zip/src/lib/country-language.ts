const GROUPS: Record<string, string> = {
  de: "DE AT LI", ar: "AE BH DZ EG IQ JO KW LB LY MA MR OM PS QA SA SD SY TN YE", en: "US GB AU NZ IE AG BS BB BZ BW CA DM FJ FM GD GH GY JM KE KI LC LR MH MT MU NA NG NR PG PH PW SB SG SL SS TO TT TV UG VC VU ZA ZM ZW", fr: "FR BE BF BI BJ CD CF CG CI CM DJ GA GN HT LU MC ML NE SN TD TG", es: "ES AR BO CL CO CR CU DO EC GQ GT HN MX NI PA PE PR PY SV UY VE", pt: "PT BR AO CV GW MZ ST TL", ru: "RU BY", zh: "CN TW HK MO", hi: "IN", ja: "JP", ko: "KR KP", tr: "TR", fa: "IR", ur: "PK", ps: "AF", bn: "BD", id: "ID", ms: "MY BN", th: "TH", vi: "VN", km: "KH", lo: "LA", my: "MM", ne: "NP", si: "LK", dz: "BT", mn: "MN", sw: "TZ", am: "ET", ti: "ER", so: "SO", rw: "RW", mg: "MG", ny: "MW", is: "IS", da: "DK", no: "NO", sv: "SE", fi: "FI", nl: "NL SR", it: "IT SM VA", el: "GR CY", sq: "AL XK", bs: "BA", bg: "BG", hr: "HR", sr: "RS ME", sl: "SI", mk: "MK", ro: "RO MD", hu: "HU", cs: "CZ", sk: "SK", pl: "PL", uk: "UA", lt: "LT", lv: "LV", et: "EE", ka: "GE", hy: "AM", az: "AZ", kk: "KZ", ky: "KG", uz: "UZ", tk: "TM", tg: "TJ", he: "IL", dv: "MV", zu: "SZ", st: "LS", kl: "GL", fo: "FO", sm: "WS", to: "TO", sey: "SC", tet: "TL",
};
export function countryLanguage(country: string | null | undefined): string | null {
  if (!country) return null;
  const code = country.toUpperCase();
  return Object.entries(GROUPS).find(([, countries]) => countries.split(" ").includes(code))?.[0] ?? null;
}
export function preferredLanguage(country: string | null, browserLanguage: string): string {
  return countryLanguage(country) || browserLanguage.split("-")[0] || "en";
}