import type { Tables } from "@/integrations/supabase/types";

export function personalProjects<T extends Pick<Tables<"projects">, "id" | "created_by">>(projects: T[], userId: string, joinedIds: string[]): T[] {
  const joined = new Set(joinedIds);
  return projects.filter((project) => project.created_by === userId || joined.has(project.id));
}

export function splitPoems(text: string): string[] {
  return text.replace(/\r\n/g, "\n").split(/\n\s*---\s*\n|\f/).map((poem) => poem.trim()).filter(Boolean);
}

export function memberDestination(value: unknown): string {
  return typeof value === "string" && value.startsWith("/") && !value.startsWith("//") && !value.includes("\\") ? value : "/dashboard";
}