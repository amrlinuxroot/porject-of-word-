import { supabase } from '@/integrations/supabase/client';
import { validateOrganizationFile } from './organization-verification';
export const ORGANIZATION_BUCKET = 'organization-verification';
export async function uploadOrganizationFile(userId: string, requestId: string, file: File) {
  validateOrganizationFile(file);
  const extension = file.name.split('.').pop()?.toLowerCase();
  const path = `${userId}/${requestId}/${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from(ORGANIZATION_BUCKET).upload(path, file);
  if (error) throw error;
  return path;
}
export async function openOrganizationFile(path: string) {
  const { data, error } = await supabase.storage.from(ORGANIZATION_BUCKET).createSignedUrl(path, 60);
  if (error) throw error;
  if (!data?.signedUrl) throw new Error('تعذر فتح الوثيقة');
  window.location.assign(data.signedUrl);
}