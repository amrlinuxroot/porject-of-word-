export function aiContributionPercent(value: string): number {
  if (!/^\d+$/.test(value.trim())) throw new Error('أدخل نسبة مشاركة الذكاء الاصطناعي من 0 إلى 100');
  const percent = Number(value);
  if (!Number.isInteger(percent) || percent < 0 || percent > 100) throw new Error('النسبة يجب أن تكون من 0 إلى 100');
  return percent;
}