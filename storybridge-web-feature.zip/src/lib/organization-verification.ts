export const ORGANIZATION_TYPES = { government: 'جهة حكومية', university: 'جامعة' } as const;
export function isOrganizationType(value: string): value is keyof typeof ORGANIZATION_TYPES {
  return value === 'government' || value === 'university';
}
export function validateOrganizationFile(file: { name: string; size: number }) {
  if (!/\.(pdf|png|jpe?g)$/i.test(file.name)) throw new Error('أرفق صورة JPG أو PNG أو ملف PDF');
  if (file.size === 0 || file.size > 20 * 1024 * 1024) throw new Error('يجب أن يكون حجم الملف بين 1 بايت و20 ميغابايت');
}