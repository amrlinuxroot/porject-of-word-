export const CERTIFIED_OPERATIONS_PERCENT = 5;
export function splitCertifiedRevenue(totalCents:number,participants:string[]) {
  if(!Number.isSafeInteger(totalCents)||totalCents<0||!participants.length)throw new Error('Invalid revenue or team');
  const team=[...new Set(participants)];const opsCents=Math.floor(totalCents*CERTIFIED_OPERATIONS_PERCENT/100);const pool=totalCents-opsCents;
  const shares=team.map((userId,i)=>({userId,cents:Math.floor(pool/team.length)+(i<pool%team.length?1:0)}));
  return {opsCents,shares};
}