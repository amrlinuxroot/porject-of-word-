import { describe, it, expect } from 'vitest';
import { isOrganizationType, validateOrganizationFile } from './organization-verification';
describe('institution verification', () => {
  it('supports government accounts', () => expect(isOrganizationType('government')).toBe(true));
  it('supports university accounts', () => expect(isOrganizationType('university')).toBe(true));
  it('does not treat a volunteer as an institution', () => expect(isOrganizationType('volunteer_translator')).toBe(false));
  it('rejects executable files', () => expect(() => validateOrganizationFile({name:'proof.exe',size:100})).toThrow());
  it('accepts certificate images', () => expect(() => validateOrganizationFile({name:'certificate.png',size:100})).not.toThrow());
});