import { describe, expect, it } from "vitest";
import { personalProjects, splitPoems, memberDestination } from "./projects";

describe("personal projects", () => {
  it("includes owned and joined projects, excludes unrelated work without duplicates", () => {
    const projects = [{ id: "owned", created_by: "me" }, { id: "joined", created_by: "other" }, { id: "outside", created_by: "other" }];
    expect(personalProjects(projects, "me", ["owned", "joined"]).map((p) => p.id)).toEqual(["owned", "joined"]);
  });
});
describe("poetry", () => {
  it("preserves lines and stanzas without arbitrary page splitting", () => {
    const poem = `first line\nsecond line\n\n${"long verse ".repeat(250)}`.trim();
    expect(splitPoems(poem)).toEqual([poem]);
  });
  it("separates poems only at explicit boundaries", () => {
    expect(splitPoems("poem one\n---\npoem two")).toEqual(["poem one", "poem two"]);
  });
});
describe("member landing", () => {
  it("defaults to personal projects", () => expect(memberDestination(null)).toBe("/dashboard"));
  it("preserves an explicitly requested internal project", () => expect(memberDestination("/projects/123")).toBe("/projects/123"));
  it("rejects an external destination", () => expect(memberDestination("//example.com")).toBe("/dashboard"));
});