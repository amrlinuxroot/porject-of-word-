import { supabase } from '@/integrations/supabase/client';
export async function uploadCertifiedFile(userId: string, folder: 'requests' | 'credentials' | 'deliveries', file: File) {
  if (file.size > 20 * 1024 * 1024) throw new Error('الحد الأقصى للملف 20 ميغابايت');
  const extension = file.name.split('.').pop()?.toLowerCase();
  if (!extension || !['pdf','jpg','jpeg','png'].includes(extension)) throw new Error('أرفق PDF أو صورة JPG / PNG');
  const path = `${userId}/${folder}/${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from('certified-documents').upload(path, file, { upsert: false });
  if (error) throw error;
  return path;
}
export async function openCertifiedFile(path: string) {
  const { data, error } = await supabase.storage.from('certified-documents').createSignedUrl(path, 60);
  if (error) throw error;
  if (!data?.signedUrl) throw new Error('تعذر فتح الملف');
  window.location.assign(data.signedUrl);
}