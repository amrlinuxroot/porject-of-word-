import { describe, it, expect } from "vitest";
import { distributeRevenue, splitIntoPages } from "./text";

describe("revenue split by pages translated", () => {
  it("takes ops share then splits the rest by selected pages", () => {
    const r = distributeRevenue(10000, 10, { a: 3, b: 1 });
    expect(r.opsCents).toBe(1000);
    expect(r.shares.find((s) => s.translatorId === "a")!.cents).toBe(6750);
    expect(r.shares.find((s) => s.translatorId === "b")!.cents).toBe(2250);
  });
  it("retains nothing: ops + shares equal total", () => {
    const r = distributeRevenue(1001, 10, { a: 1, b: 1, c: 1 });
    expect(r.opsCents + r.shares.reduce((s, x) => s + x.cents, 0)).toBe(1001);
  });
});

describe("splitIntoPages", () => {
  it("respects explicit --- page breaks", () => {
    expect(splitIntoPages("one\n---\ntwo\n---\nthree")).toEqual(["one", "two", "three"]);
  });
});

import { authorRoyaltyCents, parseSegments, toSrt, MAX_ACTIVE_PROJECTS } from "./text";

describe("author royalty", () => {
  it("takes the author % from what remains after operations", () => {
    expect(authorRoyaltyCents(10000, 10, 20)).toBe(1800);
  });
  it("is zero when the author asked for nothing", () => {
    expect(authorRoyaltyCents(10000, 10, 0)).toBe(0);
  });
});

describe("project limit", () => {
  it("is five active projects", () => expect(MAX_ACTIVE_PROJECTS).toBe(5));
});

describe("subtitles", () => {
  it("parses SRT blocks and writes them back", () => {
    const segs = parseSegments("1\n00:00:01,000 --> 00:00:03,000\nHello\n\n2\n00:00:04,000 --> 00:00:05,000\nBye");
    expect(segs).toHaveLength(2);
    expect(segs[1]).toEqual({ start: "00:00:04,000", end: "00:00:05,000", text: "Bye" });
    expect(toSrt(segs)).toContain("2\n00:00:04,000 --> 00:00:05,000\nBye");
  });
});

import { validateSegments, toVtt, timeToMs } from "./text";

describe("subtitle checks", () => {
  it("reads SRT and VTT times", () => {
    expect(timeToMs("00:01:02,500")).toBe(62500);
    expect(timeToMs("01:02.500")).toBe(62500);
    expect(timeToMs("1:2:3")).toBeNull();
  });
  it("flags end before start and overlaps as errors", () => {
    const issues = validateSegments([
      { start: "00:00:05,000", end: "00:00:04,000", text: "a" },
      { start: "00:00:03,000", end: "00:00:06,000", text: "b" },
    ]);
    expect(issues.filter((i) => i.level === "error").map((i) => i.index)).toEqual([0, 1]);
  });
  it("warns on lines over 42 characters", () => {
    const issues = validateSegments([{ start: "00:00:01,000", end: "00:00:02,000", text: "x".repeat(43) }]);
    expect(issues).toEqual([{ index: 0, level: "warning", message: "Line longer than 42 characters" }]);
  });
  it("writes VTT with dot milliseconds and header", () => {
    expect(toVtt([{ start: "00:00:01,000", end: "00:00:02,000", text: "Hi" }])).toBe("WEBVTT\n\n1\n00:00:01.000 --> 00:00:02.000\nHi\n");
  });
});
