import { expect, it } from 'vitest';
import { aiContributionPercent } from './ai-disclosure';
it('requires an explicit self-declared AI percentage from zero to 100', () => {
  expect(aiContributionPercent('0')).toBe(0);
  expect(aiContributionPercent('100')).toBe(100);
  expect(aiContributionPercent('25')).toBe(25);
  for (const invalid of ['', '-1', '101', '1.5', 'unknown']) expect(() => aiContributionPercent(invalid)).toThrow();
});