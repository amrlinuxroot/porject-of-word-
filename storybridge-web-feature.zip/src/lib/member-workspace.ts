export const TASK_STATUSES = { todo: 'To do', in_progress: 'In progress', done: 'Done' } as const;
export function validateMemberDocument(file: { name: string; size: number }, rights: boolean) {
  if (!rights) throw new Error('Confirm your permission to upload this document.');
  if (!/\.(pdf|txt|docx?|png|jpe?g)$/i.test(file.name)) throw new Error('Choose PDF, Word, text, JPG or PNG.');
  if (file.size < 1 || file.size > 20 * 1024 * 1024) throw new Error('The file must be no larger than 20 MB.');
}