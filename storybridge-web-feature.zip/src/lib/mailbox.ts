// Given the number of pages in a book and the page numbers received,
// returns which pages are still missing and whether the book is complete.
export function checkCompleteness(totalPages: number, received: number[]) {
  const have = new Set(received.filter((n) => n >= 1 && n <= totalPages));
  const missing: number[] = [];
  for (let i = 1; i <= totalPages; i++) if (!have.has(i)) missing.push(i);
  return { missing, complete: totalPages > 0 && missing.length === 0 };
}

// Joins page texts in page order into one book.
export function assembleBook(pages: { page_number: number; content: string }[]) {
  return [...pages].sort((a, b) => a.page_number - b.page_number).map((p) => p.content.trim()).join("\n\n— — —\n\n");
}
