import { expect,it } from 'vitest';
import { validateMemberDocument, TASK_STATUSES } from './member-workspace';
it('requires upload permission',()=>expect(()=>validateMemberDocument({name:'book.pdf',size:12},false)).toThrow());
it('accepts document uploads',()=>expect(()=>validateMemberDocument({name:'book.docx',size:12},true)).not.toThrow());
it('rejects executables',()=>expect(()=>validateMemberDocument({name:'book.exe',size:12},true)).toThrow());
it('supports a completed task',()=>expect(TASK_STATUSES.done).toBe('Done'));