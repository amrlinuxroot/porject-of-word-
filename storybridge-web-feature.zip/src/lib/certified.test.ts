import { describe, expect, it } from 'vitest';
import { canReceiveCertifiedDocument, CHARTER_VERSION, quoteToCents, workModeMatches } from './certified';
describe('certified service access rules', () => {
  const valid = { signedVersion: CHARTER_VERSION, approved: true, targetMatches: true, countryMatches: true, authorityMatches: true };
  it('requires an electronic charter signature before receiving documents', () => {
    expect(canReceiveCertifiedDocument(valid)).toBe(true);
    expect(canReceiveCertifiedDocument({ ...valid, signedVersion: undefined })).toBe(false);
    expect(canReceiveCertifiedDocument({ ...valid, signedVersion: 'old' })).toBe(false);
  });
  it('requires reviewed accreditation for the destination authority and language', () => {
    for (const key of ['approved','targetMatches','countryMatches','authorityMatches'] as const) expect(canReceiveCertifiedDocument({ ...valid, [key]: false })).toBe(false);
  });
  it('honors volunteer versus paid participation choices', () => {
    expect(workModeMatches('volunteer','paid')).toBe(false);
    expect(workModeMatches('paid','volunteer')).toBe(false);
    expect(workModeMatches('both','paid')).toBe(true);
  });
  it('does not invent a price and accepts only non-negative precise quotes', () => {
    expect(quoteToCents('')).toBeNull();
    expect(quoteToCents('12.35')).toBe(1235);
    expect(quoteToCents('0')).toBe(0);
    expect(() => quoteToCents('-1')).toThrow();
    expect(() => quoteToCents('1.001')).toThrow();
  });
});