export const TEAM_FILE_MAX_BYTES = 20 * 1024 * 1024;

const teamFileExtensions = new Set(["pdf", "doc", "docx", "txt"]);
const providerHosts: Record<string, (hostname: string) => boolean> = {
  box: (host) => host === "box.com" || host.endsWith(".box.com"),
  google_drive: (host) => host === "drive.google.com" || host === "docs.google.com",
  dropbox: (host) =>
    host === "dropbox.com" || host.endsWith(".dropbox.com") || host === "dl.dropboxusercontent.com",
  onedrive: (host) =>
    host === "onedrive.live.com" ||
    host === "1drv.ms" ||
    host === "sharepoint.com" ||
    host.endsWith(".sharepoint.com"),
  other: () => true,
};

export type CloudProvider = keyof typeof providerHosts;

export function validateTeamFile(file: { name: string; size: number }, rightsConfirmed: boolean) {
  if (!rightsConfirmed) throw new Error("Confirm that you have permission to share this file.");
  const extension = file.name.split(".").pop()?.toLowerCase();
  if (!extension || !teamFileExtensions.has(extension))
    throw new Error("Choose a PDF, Word or text file.");
  if (!Number.isFinite(file.size) || file.size < 1 || file.size > TEAM_FILE_MAX_BYTES) {
    throw new Error("The file must be between 1 byte and 20 MiB.");
  }
}

export function validateCloudStorageLink(provider: CloudProvider, value: string): string {
  if (!Object.prototype.hasOwnProperty.call(providerHosts, provider))
    throw new Error("Choose a supported storage provider.");
  let parsed: URL;
  try {
    parsed = new URL(value.trim());
  } catch {
    throw new Error("Enter a valid cloud-storage URL.");
  }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.port) {
    throw new Error("Use an HTTPS link without embedded credentials.");
  }
  const matchesProvider = providerHosts[provider];
  if (typeof matchesProvider !== "function" || !matchesProvider(parsed.hostname.toLowerCase())) {
    throw new Error("The URL host does not match the selected storage provider.");
  }
  return parsed.toString();
}
