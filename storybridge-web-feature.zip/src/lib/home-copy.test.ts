import { it, expect } from "vitest";
import { HOME_STRINGS, validateHomeTranslation } from "./home-copy";
it("rejects partial page translations rather than replacing the page with missing text", () => expect(() => validateHomeTranslation({ [HOME_STRINGS[0] ?? ""]: "Translated" })).toThrow());
it("only accepts the fixed public copy and strips unexpected keys", () => {
  const result = validateHomeTranslation({ ...Object.fromEntries(HOME_STRINGS.map(s => [s, "Translated"])), private: "secret" });
  expect(result).not.toHaveProperty("private");
  expect(Object.keys(result)).toHaveLength(new Set(HOME_STRINGS).size);
});