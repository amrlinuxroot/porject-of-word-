import i18next from 'i18next';
export const interfaceI18n = i18next.createInstance();
void interfaceI18n.init({ lng: 'source', fallbackLng: 'source', resources: {}, keySeparator: false, nsSeparator: false, interpolation: { escapeValue: false }, initAsync: false });
let revision = 0;
const listeners = new Set<() => void>();
export function subscribeInterfaceLanguage(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; }
export function interfaceRevision() { return revision; }
export function applyInterfaceDictionary(language: string, dictionary: Record<string,string>) {
  if (language) { interfaceI18n.addResourceBundle(language,'translation',dictionary,true,true); void interfaceI18n.changeLanguage(language); }
  else void interfaceI18n.changeLanguage('source');
  revision++; listeners.forEach(listener => listener());
}
export function uiText(source: string) { return interfaceI18n.t(source,{defaultValue:source}); }