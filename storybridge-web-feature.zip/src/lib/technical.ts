export type TechnicalKind = "scientific" | "technical" | "code";
export function assembleTechnicalResult(kind: TechnicalKind, source: string, generated: string): string {
  return kind === "code" ? `الكود الأصلي — دون تغيير\n\n${source}\n\nالترجمة والشرح\n\n${generated}` : generated;
}