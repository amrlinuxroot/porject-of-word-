import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const DEFAULT_SETTINGS = {
  certified_pricing_policy: "تحدد إدارة مشروع كلمة سعرًا منصفًا وميسّرًا بحسب حجم الوثيقة واللغة ومتطلبات الاعتماد، دون مبالغة. يُعرض السعر الإجمالي للموافقة قبل إسناد العمل. ويمكن طلب ترجمة تطوعية بحسب توفر المترجمين المعتمدين.",
  contact_email: "info@amrdarweesh.de",
  whatsapp: "+49 176 201 766 85",
  meet_email: "amrlinuxroot@gmail.com",
  discord_url: "https://discord.gg/mTk4UtRch",
  iban: "DE78100101785082338120",
  storage_provider: "MediaFire",
  storage_url: "",
  storage_note: "Upload large book and video files to our shared folder, then paste the link.",
};
export type SettingKey = keyof typeof DEFAULT_SETTINGS;
export const SETTING_LABELS: Record<SettingKey, string> = {
  certified_pricing_policy: "سياسة أسعار ترجمة الوثائق المعتمدة",
  contact_email: "Contact email",
  whatsapp: "WhatsApp number",
  meet_email: "Google Meet organizer email",
  discord_url: "Discord invite link",
  iban: "Donation IBAN",
  storage_provider: "Book storage service (MediaFire, Google Drive, Archive.org…)",
  storage_url: "Shared upload folder link",
  storage_note: "Upload instructions shown to contributors",
};

export function useSettings() {
  const { data } = useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => (await supabase.from("site_settings").select("key, value")).data ?? [],
  });
  const s = { ...DEFAULT_SETTINGS };
  for (const r of data ?? []) if (r.key in s && r.value) s[r.key as SettingKey] = r.value;
  return s;
}

export const waLink = (phone: string) => `https://wa.me/${phone.replace(/\D/g, "").replace(/^00/, "")}`;
