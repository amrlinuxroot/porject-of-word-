import { it, expect } from "vitest";
import { preferredLanguage, countryLanguage } from "./country-language";
it("selects German for Germany even with an Arabic browser", () => expect(preferredLanguage("DE", "ar-SA")).toBe("de"));
it("uses the browser language only when country is unavailable", () => expect(preferredLanguage(null, "fr-CA")).toBe("fr"));
it("selects Arabic for Egypt", () => expect(countryLanguage("EG")).toBe("ar"));