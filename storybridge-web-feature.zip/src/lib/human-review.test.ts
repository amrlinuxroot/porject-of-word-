import { expect, it } from 'vitest';
import { isHumanReviewed } from './human-review';
it('rejects AI-only work and requires human review plus ethics agreement', () => {
  expect(isHumanReviewed(false,false)).toBe(false);
  expect(isHumanReviewed(false,true)).toBe(false);
  expect(isHumanReviewed(true,false)).toBe(false);
  expect(isHumanReviewed(true,true)).toBe(true);
});