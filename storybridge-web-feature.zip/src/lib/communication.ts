export const ONLINE_WINDOW_MS = 90000;
export type Audience = "everyone" | "members" | "admins" | "none";
export function audienceAllows(audience: Audience, signedIn: boolean, isAdmin: boolean): boolean {
  return audience === "everyone" || (audience === "members" && signedIn) || (audience === "admins" && signedIn && isAdmin);
}
export function onlineMembers<T extends { user_id: string; last_seen: string }>(rows: T[], now = Date.now()): T[] {
  return rows.filter((r) => { const age = now - Date.parse(r.last_seen); return age >= 0 && age < ONLINE_WINDOW_MS; });
}
export function canReadDirectMessage(userId: string, message: { sender_id: string; recipient_id: string }): boolean {
  return message.sender_id === userId || message.recipient_id === userId;
}