import { describe, expect, it } from "vitest";
import { validateCloudStorageLink, validateTeamFile } from "./team-sharing";

describe("team file validation", () => {
  it("accepts PDF and Word files under the size limit when rights are confirmed", () => {
    expect(() => validateTeamFile({ name: "chapter.docx", size: 1024 }, true)).not.toThrow();
    expect(() => validateTeamFile({ name: "scan.pdf", size: 1024 }, true)).not.toThrow();
  });
  it("rejects unconfirmed rights, unsupported file types, and oversized files", () => {
    expect(() => validateTeamFile({ name: "chapter.docx", size: 1024 }, false)).toThrow();
    expect(() => validateTeamFile({ name: "payload.exe", size: 1024 }, true)).toThrow();
    expect(() =>
      validateTeamFile({ name: "chapter.pdf", size: 20 * 1024 * 1024 + 1 }, true),
    ).toThrow();
  });
});

describe("external storage URL validation", () => {
  it("accepts provider-matched HTTPS links", () => {
    expect(validateCloudStorageLink("box", "https://app.box.com/s/example")).toContain(
      "https://app.box.com/",
    );
    expect(
      validateCloudStorageLink("google_drive", "https://drive.google.com/drive/folders/example"),
    ).toContain("drive.google.com");
    expect(
      validateCloudStorageLink("dropbox", "https://www.dropbox.com/s/example/file.pdf"),
    ).toContain("dropbox.com");
    expect(validateCloudStorageLink("onedrive", "https://1drv.ms/f/example")).toContain("1drv.ms");
  });
  it("rejects insecure, credential-bearing, or mismatched links", () => {
    expect(() => validateCloudStorageLink("box", "http://app.box.com/s/example")).toThrow();
    expect(() =>
      validateCloudStorageLink("box", "https://user:pass@app.box.com/s/example"),
    ).toThrow();
    expect(() => validateCloudStorageLink("box", "https://evilbox.com/s/example")).toThrow();
    expect(() =>
      validateCloudStorageLink("unsupported" as never, "https://files.example/s/example"),
    ).toThrow();
  });
});
