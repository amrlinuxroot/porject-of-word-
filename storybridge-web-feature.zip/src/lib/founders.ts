// Founders as confirmed by the project owner. Update here only — footer and About page read this list.
export const FOUNDERS = [
  { ar: "عمرو درويش الشريف", en: "Amr Darweesh Al-Sharif" },
  { ar: "نواف الشريف", en: "Nawaf Al-Sharif" },
  { ar: "سواهر صالح محمد نور", en: "Sawaher Saleh Mohammed Noor" },
];
