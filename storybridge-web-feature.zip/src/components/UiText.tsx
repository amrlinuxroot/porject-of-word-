import { useSyncExternalStore } from 'react';
import { interfaceRevision, subscribeInterfaceLanguage, uiText } from '@/lib/interface-language';
export function UiText({ source }: { source: string }) {
  useSyncExternalStore(subscribeInterfaceLanguage, interfaceRevision, () => 0);
  const clean=source.trim();
  return `${source.startsWith(' ') ? ' ' : ''}${uiText(clean)}${source.endsWith(' ') ? ' ' : ''}`;
}