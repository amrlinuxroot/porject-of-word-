import { useHomeLanguage } from "@/components/HomeLanguage";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CONTRIBUTOR_ROLES, FIELDS, LANGUAGES } from "@/lib/text";
import { aiContributionPercent } from "@/lib/ai-disclosure";

const COPYRIGHT = [
  { id: "protected", label: "Yes — it is protected by copyright" },
  { id: "public_domain", label: "No — public domain (author died 70+ years ago, or free worldwide)" },
  { id: "open_license", label: "Open licence (Creative Commons / open access)" },
  { id: "unknown", label: "I don't know" },
];
const PERMISSION = [
  { id: "i_am_author", label: "I am the author / rights holder" },
  { id: "have_permission", label: "I have written permission from the author or publisher" },
  { id: "not_needed", label: "Not needed — public domain or open licence" },
  { id: "no_permission", label: "No permission yet — please contact the author" },
];

const empty = {
  kind: "book", title: "", author: "", original_language: "", target_languages: "", field: "", description: "",
  source_link: "", source_text: "", submitter_name: "", submitter_email: "", submitter_role: "reader",
  has_copyright: "", permission: "", proof_link: "", proof_note: "", rights_holder_name: "", rights_holder_email: "",
  author_wants_royalty: false, declaration: false,
};

export function SuggestDialog({ trigger }: { trigger: React.ReactNode }) {
  const { t } = useHomeLanguage();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState(empty);
  const [busy, setBusy] = useState(false);
  const [aiPercent, setAiPercent] = useState("");
  const set = (k: keyof typeof empty, v: string | boolean) => setF((x) => ({ ...x, [k]: v }));
  const sel = "h-10 w-full rounded-md border bg-background px-3 text-sm";

  async function onFile(file: File) {
    if (!/\.(txt|md|srt|vtt)$/i.test(file.name)) return void toast.error(t("For PDF, EPUB or video files, upload them to MediaFire / Google Drive and paste the link."));
    if (file.size > 2_000_000) return void toast.error(t("Text file is too large — please share a link instead."));
    set("source_text", await file.text());
    toast.success(`${file.name} attached`);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!f.has_copyright || !f.permission) return void toast.error(t("Please answer the copyright and permission questions."));
    if (f.has_copyright === "protected" && f.permission !== "i_am_author" && f.permission !== "have_permission" && f.permission !== "no_permission")
      return void toast.error(t("A protected work needs the author's permission."));
    if (f.permission === "have_permission" && !f.proof_link.trim() && !f.proof_note.trim())
      return void toast.error(t("Add a link to the permission document or describe it."));
    if (!f.declaration) return void toast.error(t("Please confirm the rights declaration."));
    let percent: number | null = null;
    if (['book','study'].includes(f.kind)) { try { percent = aiContributionPercent(aiPercent); } catch(e) { return void toast.error(e instanceof Error ? e.message : 'أدخل نسبة الذكاء الاصطناعي'); } }
    setBusy(true);
    const { error } = await supabase.from("book_suggestions").insert({ ...f, ai_contribution_percent: percent, status: "pending" });
    setBusy(false);
    if (error) return void toast.error(error.message);
    toast.success(t("Thank you! Our team will review the rights and contact you by email."));
    setF(empty); setAiPercent(""); setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto" dir={useHomeLanguage().direction}>
        <DialogHeader>
          <DialogTitle>{t("Suggest a work to translate")}</DialogTitle>
          <DialogDescription>{t("Books, study books, films or lectures. We only translate with the rights holder's permission.")}</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-5">
          <fieldset className="grid gap-3 sm:grid-cols-2">
            <div><Label>{t("Type")}</Label><select className={sel} value={f.kind} onChange={(e) => set("kind", e.target.value)}>
              <option value="book">{t("Book / text")}</option><option value="poetry">{t("Poetry / poems")}</option><option value="study">{t("Study book (school / university)")}</option><option value="film">{t("Film / video / multimedia")}</option></select></div>
            <div><Label>{t("Title")}</Label><Input required maxLength={300} value={f.title} onChange={(e) => set("title", e.target.value)} /></div>
            <div><Label>{t("Author / creator")}</Label><Input value={f.author} onChange={(e) => set("author", e.target.value)} /></div>
            <div><Label>{t("Field")}</Label><select className={sel} value={f.field} onChange={(e) => set("field", e.target.value)}><option value="">{t("Choose\u2026")}</option>{FIELDS.map((x) => <option key={x} value={x}>{t(x)}</option>)}</select></div>
            <div><Label>{t("Original language")}</Label><select className={sel} value={f.original_language} onChange={(e) => set("original_language", e.target.value)}><option value="">{t("Choose\u2026")}</option>{LANGUAGES.map((x) => <option key={x} value={x}>{t(x)}</option>)}</select></div>
            <div><Label>{t("Translate into")}</Label><Input placeholder={t("e.g. Arabic, German")} value={f.target_languages} onChange={(e) => set("target_languages", e.target.value)} /></div>
            <div className="sm:col-span-2"><Label>{t("Short description")}</Label><Textarea rows={2} value={f.description} onChange={(e) => set("description", e.target.value)} /></div>
            {['book','study'].includes(f.kind) && <div className="sm:col-span-2"><Label htmlFor="suggest-ai">{t('نسبة مشاركة الذكاء الاصطناعي (%) — إفصاح مقدم الكتاب')}</Label><Input id="suggest-ai" required type="number" min={0} max={100} step={1} value={aiPercent} onChange={e => setAiPercent(e.target.value)} /></div>}
            <div className="sm:col-span-2"><Label>{t("Link to the file (MediaFire, Google Drive, Dropbox, YouTube\u2026)")}</Label><Input type="url" placeholder="https://" value={f.source_link} onChange={(e) => set("source_link", e.target.value)} /></div>
            <div className="sm:col-span-2"><Label>{t("Or upload a text / subtitle file from your computer (.txt, .md, .srt)")}</Label><Input type="file" accept=".txt,.md,.srt,.vtt" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} /></div>
          </fieldset>

          <fieldset className="space-y-3 rounded-lg border bg-muted/40 p-4">
            <legend className="px-1 font-semibold">{t("Rights & permission")}</legend>
            <div><Label>{t("Is the work protected by copyright?")}</Label>
              <div className="mt-1 space-y-1">{COPYRIGHT.map((o) => <label key={o.id} className="flex gap-2 text-sm"><input type="radio" name="cr" checked={f.has_copyright === o.id} onChange={() => set("has_copyright", o.id)} />{t(o.label)}</label>)}</div></div>
            <div><Label>{t("Do you have permission to translate it?")}</Label>
              <div className="mt-1 space-y-1">{PERMISSION.map((o) => <label key={o.id} className="flex gap-2 text-sm"><input type="radio" name="pm" checked={f.permission === o.id} onChange={() => set("permission", o.id)} />{t(o.label)}</label>)}</div></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>{t("Author / publisher name")}</Label><Input value={f.rights_holder_name} onChange={(e) => set("rights_holder_name", e.target.value)} /></div>
              <div><Label>{t("Author / publisher email")}</Label><Input type="email" value={f.rights_holder_email} onChange={(e) => set("rights_holder_email", e.target.value)} /></div>
              <div className="sm:col-span-2"><Label>{t("Link to proof (permission letter, contract, licence page)")}</Label><Input type="url" placeholder="https://" value={f.proof_link} onChange={(e) => set("proof_link", e.target.value)} /></div>
              <div className="sm:col-span-2"><Label>{t("Describe the permission")}</Label><Textarea rows={2} placeholder={t("e.g. Email from the author on 3 March 2026 allowing an Arabic translation")} value={f.proof_note} onChange={(e) => set("proof_note", e.target.value)} /></div>
            </div>
            <label className="flex gap-2 text-sm"><input type="checkbox" checked={f.author_wants_royalty} onChange={(e) => set("author_wants_royalty", e.target.checked)} />{t("The author would like a share of the translated book's sales")}</label>
          </fieldset>

          <fieldset className="grid gap-3 sm:grid-cols-3">
            <div><Label>{t("Your name")}</Label><Input required value={f.submitter_name} onChange={(e) => set("submitter_name", e.target.value)} /></div>
            <div><Label>{t("Your email")}</Label><Input required type="email" value={f.submitter_email} onChange={(e) => set("submitter_email", e.target.value)} /></div>
            <div><Label>{t("You are a\u2026")}</Label><select className={sel} value={f.submitter_role} onChange={(e) => set("submitter_role", e.target.value)}>{CONTRIBUTOR_ROLES.map((r) => <option key={r.id} value={r.id}>{t(r.label)}</option>)}</select></div>
          </fieldset>

          <label className="flex gap-2 text-sm"><input type="checkbox" checked={f.declaration} onChange={(e) => set("declaration", e.target.checked)} />
            {t("I confirm the information above is true. I hold or have verified the translation rights, and I accept responsibility for any copyright claim caused by false information.")}</label>
          <Button type="submit" disabled={busy} className="w-full">{busy ? t("Sending…") : t("Send suggestion")}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
