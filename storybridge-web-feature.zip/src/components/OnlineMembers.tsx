import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { MessageCircle, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { onlineMembers } from "@/lib/communication";
import { Button } from "@/components/ui/button";

export function OnlineMembers({ userId }: { userId: string }) {
  const { data: members = [], error, isPending } = useQuery({
    queryKey: ["online-members", userId], refetchInterval: 15000,
    queryFn: async () => {
      const { data, error } = await supabase.from("member_activity").select("user_id,last_seen").gte("last_seen", new Date(Date.now() - 90000).toISOString());
      if (error) throw error;
      const rows = onlineMembers(data ?? []);
      if (!rows.length) return [];
      const { data: profiles, error: profileError } = await supabase.from("profiles").select("id,display_name").in("id", rows.map(r => r.user_id));
      if (profileError) throw profileError;
      return Promise.all(rows.map(async r => ({ ...r, name: profiles?.find(p => p.id === r.user_id)?.display_name || "Member", canMessage: (await supabase.rpc("can_message_member", { _recipient: r.user_id })).data === true })));
    },
  });
  return <section dir="rtl">
    <h2 className="flex items-center gap-2 text-xl font-semibold"><Users className="h-5 w-5 text-primary" /> الأعضاء المتصلون الآن <span className="text-primary">{isPending ? "…" : members.length}</span></h2>
    <p className="mt-1 text-xs text-muted-foreground">نشاط خلال آخر ٩٠ ثانية · تحديث كل ١٥ ثانية</p>
    {error ? <p role="alert" className="py-4">تعذر تحميل الأعضاء المتصلين.</p> : <ul className="mt-3 divide-y border-y">{members.map(m => <li key={m.user_id} className="flex items-center gap-3 py-3"><span className="h-2 w-2 rounded-full bg-primary" /><span className="flex-1 break-words">{m.name}</span>{m.user_id !== userId && (m.canMessage ? <Button asChild variant="outline" size="sm"><Link to="/chat" search={{ member: m.user_id }}><MessageCircle className="h-4 w-4" /> مراسلة</Link></Button> : <span className="text-xs text-muted-foreground">الدردشة مغلقة</span>)}</li>)}</ul>}
    {!isPending && !error && !members.length && <p className="py-6 text-muted-foreground">لا يوجد أعضاء متصلون الآن.</p>}
  </section>;
}