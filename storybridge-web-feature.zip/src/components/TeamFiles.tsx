import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, FileText, Share2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { validateTeamFile } from "@/lib/team-sharing";

type TeamFile = {
  id: string;
  project_id: string;
  uploader_id: string;
  title: string;
  file_name: string;
  file_path: string;
  content_type: string;
  file_size: number;
  rights_confirmed: boolean;
  is_shared: boolean;
  created_at: string;
};

export function TeamFiles({
  projectId,
  userId,
  isOwner,
}: {
  projectId: string;
  userId: string;
  isOwner: boolean;
}) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const queryKey = ["team-files", projectId];
  const {
    data: files = [],
    isPending,
    error,
  } = useQuery({
    queryKey,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("team_files")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as TeamFile[];
    },
  });

  async function upload(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    const file = values.get("file");
    if (!(file instanceof File)) return;
    try {
      validateTeamFile(file, values.get("rights") === "on");
    } catch (validationError) {
      toast.error(validationError instanceof Error ? validationError.message : "Invalid file");
      return;
    }
    const extension = file.name.split(".").pop()?.toLowerCase();
    if (!extension) return;
    const contentType =
      {
        pdf: "application/pdf",
        doc: "application/msword",
        docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        txt: "text/plain",
      }[extension] ?? "application/octet-stream";
    const path = `${projectId}/${userId}/${crypto.randomUUID()}.${extension}`;
    setBusy(true);
    let uploaded = false;
    try {
      const { error: uploadError } = await supabase.storage.from("team-files").upload(path, file, {
        upsert: false,
        contentType,
        cacheControl: "0",
      });
      if (uploadError) throw uploadError;
      uploaded = true;
      const { error: recordError } = await supabase.from("team_files").insert({
        project_id: projectId,
        uploader_id: userId,
        title: String(values.get("title") ?? "").trim(),
        file_name: file.name,
        file_path: path,
        content_type: contentType,
        file_size: file.size,
        rights_confirmed: true,
        is_shared: false,
      });
      if (recordError) throw recordError;
      form.reset();
      await qc.invalidateQueries({ queryKey });
      toast.success("Uploaded privately. Share it with the team only after checking the file.");
    } catch (uploadFailure) {
      if (uploaded) await supabase.storage.from("team-files").remove([path]);
      toast.error(uploadFailure instanceof Error ? uploadFailure.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  async function toggleShare(file: TeamFile) {
    const next = !file.is_shared;
    if (
      next &&
      !window.confirm(
        `Share “${file.title}” with accepted members of this project? The file has not been malware-scanned. Only share files you trust and have permission to distribute.`,
      )
    )
      return;
    const { error: updateError } = await supabase
      .from("team_files")
      .update({ is_shared: next })
      .eq("id", file.id)
      .eq("project_id", projectId);
    if (updateError) return void toast.error(updateError.message);
    await qc.invalidateQueries({ queryKey });
    toast.success(
      next ? "File shared with the project team." : "File is private to you and the project owner.",
    );
  }

  async function download(file: TeamFile) {
    const { data, error: signedUrlError } = await supabase.storage
      .from("team-files")
      .createSignedUrl(file.file_path, 60);
    if (signedUrlError || !data?.signedUrl)
      return void toast.error(
        signedUrlError?.message ?? "Could not create a secure download link.",
      );
    window.location.assign(data.signedUrl);
  }

  async function remove(file: TeamFile) {
    if (!window.confirm(`Delete “${file.title}” from this project? This cannot be undone.`)) return;
    const { error: storageError } = await supabase.storage
      .from("team-files")
      .remove([file.file_path]);
    if (storageError) return void toast.error(storageError.message);
    const { error: rowError } = await supabase
      .from("team_files")
      .delete()
      .eq("id", file.id)
      .eq("project_id", projectId);
    if (rowError)
      return void toast.error(
        `File bytes were removed, but its record could not be deleted: ${rowError.message}`,
      );
    await qc.invalidateQueries({ queryKey });
  }

  return (
    <section className="space-y-4 border-t pt-5">
      <div>
        <h2 className="text-2xl font-semibold">Team files</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Files are private until their uploader or project owner explicitly shares them. Access is
          limited to the owner and accepted team members.
        </p>
        <p className="mt-2 text-sm text-amber-700">
          Malware scanning is not configured for this source. Uploaded files are not certified safe;
          download only files you trust.
        </p>
      </div>
      <form className="grid gap-3 rounded-lg border p-4 sm:grid-cols-2" onSubmit={upload}>
        <label>
          File title
          <Input name="title" required maxLength={200} disabled={busy} />
        </label>
        <label>
          PDF, Word or text file
          <Input name="file" type="file" accept=".pdf,.doc,.docx,.txt" required disabled={busy} />
        </label>
        <label className="flex items-start gap-2 text-sm sm:col-span-2">
          <input type="checkbox" name="rights" required disabled={busy} />I own this file or have
          permission to share it with this team.
        </label>
        <p className="text-sm text-muted-foreground sm:col-span-2">
          Maximum 20 MiB. New uploads remain private until you explicitly share them.
        </p>
        <Button type="submit" disabled={busy}>
          {busy ? "Uploading…" : "Upload privately"}
        </Button>
      </form>
      {isPending ? (
        <p role="status">Loading team files…</p>
      ) : error ? (
        <p role="alert">
          Team files could not be loaded. Access is determined by your current project membership.
        </p>
      ) : !files.length ? (
        <p className="border-y py-8 text-center text-sm text-muted-foreground">
          No team files yet.
        </p>
      ) : (
        <ul className="divide-y border-y">
          {files.map((file) => {
            const canManage = isOwner || file.uploader_id === userId;
            return (
              <li key={file.id} className="flex flex-wrap items-center gap-3 py-4">
                <FileText className="h-5 w-5 shrink-0 text-primary" />
                <div className="min-w-0 flex-1">
                  <p className="break-words font-medium">{file.title}</p>
                  <p className="break-all text-xs text-muted-foreground">
                    {file.file_name} · {(file.file_size / 1024 / 1024).toFixed(2)} MiB ·{" "}
                    {new Date(file.created_at).toLocaleDateString()}
                  </p>
                  <p className="text-xs">
                    {file.is_shared ? "Shared with accepted team members" : "Private / not shared"}
                  </p>
                </div>
                {(file.is_shared || canManage) && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => void download(file)}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                )}
                {canManage && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => void toggleShare(file)}
                  >
                    <Share2 className="mr-2 h-4 w-4" />
                    {file.is_shared ? "Unshare" : "Share with team"}
                  </Button>
                )}
                {canManage && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label={`Delete ${file.title}`}
                    title="Delete file"
                    onClick={() => void remove(file)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
