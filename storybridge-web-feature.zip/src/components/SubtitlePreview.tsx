import { useState } from "react";
import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toSrt, toVtt, validateSegments, type Segment } from "@/lib/text";

export function SubtitlePreview({ segments, fileName }: { segments: Segment[]; fileName: string }) {
  const [format, setFormat] = useState<"srt" | "vtt">("srt");
  const issues = validateSegments(segments);
  const errors = issues.filter((i) => i.level === "error");
  const warnings = issues.filter((i) => i.level === "warning");
  const body = format === "srt" ? toSrt(segments) : toVtt(segments);

  function download() {
    const url = URL.createObjectURL(new Blob([body], { type: format === "vtt" ? "text/vtt" : "text/plain" }));
    Object.assign(document.createElement("a"), { href: url, download: `${fileName}.${format}` }).click();
    URL.revokeObjectURL(url);
  }

  return (
    <Dialog>
      <DialogTrigger asChild><Button size="sm" variant="outline">Preview subtitles</Button></DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-4xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Subtitle preview</DialogTitle>
          <DialogDescription>Check timing and formatting before you download. Untranslated segments use the original text.</DialogDescription>
        </DialogHeader>
        <div className="flex flex-wrap items-center gap-2">
          <Button size="sm" variant={format === "srt" ? "default" : "outline"} onClick={() => setFormat("srt")}>SRT</Button>
          <Button size="sm" variant={format === "vtt" ? "default" : "outline"} onClick={() => setFormat("vtt")}>VTT</Button>
          <span className="ml-auto flex items-center gap-3 text-sm">
            {errors.length === 0 ? <span className="flex items-center gap-1 text-success"><CheckCircle2 className="h-4 w-4" /> Timing OK</span>
              : <span className="flex items-center gap-1 text-destructive"><XCircle className="h-4 w-4" /> {errors.length} error{errors.length === 1 ? "" : "s"}</span>}
            {warnings.length > 0 && <span className="flex items-center gap-1 text-accent"><AlertTriangle className="h-4 w-4" /> {warnings.length} warning{warnings.length === 1 ? "" : "s"}</span>}
          </span>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <ol className="max-h-[50vh] divide-y overflow-y-auto rounded-lg border bg-card text-sm">
            {segments.map((s, i) => {
              const mine = issues.filter((x) => x.index === i);
              const bad = mine.some((x) => x.level === "error");
              return (
                <li key={i} className={`p-3 ${bad ? "bg-destructive/10" : mine.length ? "bg-accent/10" : ""}`}>
                  <div className="font-mono text-xs text-muted-foreground">#{i + 1} · {s.start} → {s.end}</div>
                  <p dir="auto" className="whitespace-pre-wrap">{s.text}</p>
                  {mine.map((x, k) => <p key={k} className={`mt-1 text-xs ${x.level === "error" ? "text-destructive" : "text-accent"}`}>{x.message}</p>)}
                </li>
              );
            })}
          </ol>
          <pre className="max-h-[50vh] overflow-auto rounded-lg border bg-muted p-3 font-mono text-xs" dir="auto">{body}</pre>
        </div>
        <Button onClick={download} disabled={errors.length > 0}>{errors.length > 0 ? "Fix the errors to download" : `Download .${format}`}</Button>
      </DialogContent>
    </Dialog>
  );
}
