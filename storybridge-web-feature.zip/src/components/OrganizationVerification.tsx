import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ShieldCheck, Upload, FileText } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ORGANIZATION_TYPES, isOrganizationType, validateOrganizationFile } from '@/lib/organization-verification';
import { ORGANIZATION_BUCKET, uploadOrganizationFile, openOrganizationFile } from '@/lib/organization-files';

const statuses: Record<string, string> = { pending: 'قيد المراجعة', approved: 'تم قبول التحقق', rejected: 'مرفوض' };
export function OrganizationVerification({userId, organizationType, country}: {userId: string; organizationType: string; country: string}) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [identity, setIdentity] = useState<File | null>(null);
  const [certificates, setCertificates] = useState<File[]>([]);
  const {data: requests = [], isPending, error} = useQuery({queryKey:['organization-verifications',userId], queryFn:async()=>{
    const r = await supabase.from('organization_verifications').select('*').eq('user_id',userId).order('created_at',{ascending:false});
    if(r.error) throw r.error;
    return r.data;
  }});
  if (!isOrganizationType(organizationType)) return null;
  const latest = requests[0];
  return <section dir="rtl" className="space-y-4 border-t pt-6">
    <h3 className="flex items-center gap-2 text-xl font-semibold"><ShieldCheck className="h-5 w-5 text-primary"/>تحقق الجهات الحكومية والجامعات</h3>
    <p className="text-sm text-muted-foreground">الوثائق خاصة بصاحب الحساب والإدارة، ولا تُنشر في الملف العام. قبول التحقق لا يمنح صلاحيات إدارية.</p>
    {isPending && <p role="status">جارٍ تحميل حالة التحقق…</p>}
    {error && <p role="alert">تعذر تحميل طلبات التحقق؛ أعد تحميل الصفحة.</p>}
    {requests.map(r=><article key={r.id} className="space-y-2 rounded-lg border bg-card p-4">
      <h4 className="font-semibold">{r.organization_name} — {statuses[r.status]}</h4>
      <p className="text-sm">{ORGANIZATION_TYPES[r.organization_type as keyof typeof ORGANIZATION_TYPES]} · {r.country} · ممثل الجهة: {r.representative_name}</p>
      {r.review_note && <p>ملاحظة الإدارة: {r.review_note}</p>}
      <div className="flex flex-wrap gap-2"><Button type="button" variant="outline" onClick={()=>openOrganizationFile(r.identity_path).catch(e=>toast.error(e.message))}><FileText/>وثيقة الهوية</Button>{r.certificate_paths.map((path,i)=><Button key={path} type="button" variant="outline" onClick={()=>openOrganizationFile(path).catch(e=>toast.error(e.message))}>الشهادة {i+1}</Button>)}</div>
    </article>)}
    {!isPending && !error && (!latest || latest.status==='rejected') && <form className="grid gap-4 sm:grid-cols-2" onSubmit={async e=>{
      e.preventDefault();
      if(!identity || !certificates.length) return void toast.error('أرفق وثيقة الهوية وشهادة واحدة على الأقل');
      if(certificates.length>10) return void toast.error('الحد الأقصى عشر شهادات');
      const form=e.currentTarget;
      const f=new FormData(form);
      const id=crypto.randomUUID();
      const uploaded:string[]=[];
      let saved=false;
      setBusy(true);
      try {
        [identity,...certificates].forEach(validateOrganizationFile);
        const identityPath=await uploadOrganizationFile(userId,id,identity); uploaded.push(identityPath);
        for(const file of certificates) uploaded.push(await uploadOrganizationFile(userId,id,file));
        const {error: saveError}=await supabase.from('organization_verifications').insert({id,user_id:userId,organization_type:organizationType,organization_name:String(f.get('name')).trim(),country:String(f.get('country')).trim(),representative_name:String(f.get('representative')).trim(),identity_path:identityPath,certificate_paths:uploaded.slice(1)});
        if(saveError) throw saveError;
        saved=true;
        toast.success('أُرسل طلب التحقق إلى الإدارة');
        form.reset();setIdentity(null);setCertificates([]);
        await qc.invalidateQueries({queryKey:['organization-verifications',userId]});
      } catch(e) {
        if(!saved && uploaded.length) await supabase.storage.from(ORGANIZATION_BUCKET).remove(uploaded);
        toast.error(e instanceof Error?e.message:'تعذر إرسال طلب التحقق');
      } finally {setBusy(false);}
    }}>
      <label>الاسم الرسمي للجهة<Input name="name" required minLength={3} disabled={busy}/></label>
      <label>بلد مقر الجهة<Input name="country" required minLength={2} defaultValue={country} disabled={busy}/></label>
      <label className="sm:col-span-2">الاسم الكامل لممثل الجهة<Input name="representative" required minLength={3} disabled={busy}/></label>
      <label>وثيقة هوية الجهة / تسجيلها الرسمي<Input type="file" accept=".pdf,.jpg,.jpeg,.png" required disabled={busy} onChange={e=>setIdentity(e.target.files?.[0]??null)}/></label>
      <label>شهادات الاعتماد / تفويض ممثل الجهة<Input type="file" accept=".pdf,.jpg,.jpeg,.png" multiple required disabled={busy} onChange={e=>setCertificates(Array.from(e.target.files??[]))}/></label>
      <p className="text-sm text-muted-foreground sm:col-span-2">PDF أو صور JPG / PNG، حتى 20 ميغابايت لكل ملف، وعشر شهادات كحد أقصى.</p>
      <Button type="submit" disabled={busy}><Upload className="h-4 w-4"/>{busy?'جارٍ رفع الوثائق…':latest?'إرسال طلب جديد':'إرسال للتحقق'}</Button>
    </form>}
  </section>;
}

export function OrganizationVerificationAdmin({userId}:{userId:string}) {
  const qc=useQueryClient();
  const [busy,setBusy]=useState<string|null>(null);
  const {data:requests=[],error,isPending}=useQuery({queryKey:['admin-organization-verifications',userId],queryFn:async()=>{
    const r=await supabase.from('organization_verifications').select('*').order('created_at',{ascending:false});
    if(r.error) throw r.error; return r.data;
  }});
  return <section dir="rtl" className="space-y-4 border-t pt-6"><h2 className="text-2xl font-semibold">التحقق من الجهات الحكومية والجامعات</h2>
    {isPending?<p role="status">جارٍ تحميل الطلبات…</p>:error?<p role="alert">تعذر تحميل طلبات الجهات.</p>:!requests.length?<p className="text-muted-foreground">لا توجد طلبات تحقق للجهات.</p>:requests.map(r=><article key={r.id} className="space-y-3 rounded-lg border bg-card p-4">
      <h3 className="font-semibold">{r.organization_name} — {statuses[r.status]}</h3><p>{r.country} · {ORGANIZATION_TYPES[r.organization_type as keyof typeof ORGANIZATION_TYPES]} · {r.representative_name}</p>
      <p className="break-all text-xs text-muted-foreground">الحساب المرتبط: {r.user_id}</p>
      <div className="flex flex-wrap gap-2"><Button variant="outline" onClick={()=>openOrganizationFile(r.identity_path).catch(e=>toast.error(e.message))}>مراجعة الهوية</Button>{r.certificate_paths.map((p,i)=><Button key={p} variant="outline" onClick={()=>openOrganizationFile(p).catch(e=>toast.error(e.message))}>مراجعة الشهادة {i+1}</Button>)}</div>
      <form className="grid gap-3 sm:grid-cols-2" onSubmit={async e=>{
        e.preventDefault();const f=new FormData(e.currentTarget);setBusy(r.id);
        try {const {error}=await supabase.from('organization_verifications').update({status:String(f.get('status')),review_note:String(f.get('note')).trim(),reviewed_at:new Date().toISOString()}).eq('id',r.id);if(error)throw error;await qc.invalidateQueries({queryKey:['admin-organization-verifications',userId]});await qc.invalidateQueries({queryKey:['organization-verifications']});toast.success('حُفظت مراجعة الجهة');}catch(e){toast.error(e instanceof Error?e.message:'تعذر الحفظ');}finally{setBusy(null);}
      }}><label>نتيجة التحقق<select name="status" defaultValue={r.status} className="block w-full rounded-md border bg-background p-2"><option value="pending">قيد المراجعة</option><option value="approved">مقبول</option><option value="rejected">مرفوض</option></select></label><label>ملاحظة الإدارة<Input name="note" defaultValue={r.review_note}/></label><Button disabled={busy===r.id} type="submit">حفظ مراجعة الجهة</Button></form>
    </article>)}
  </section>;
}