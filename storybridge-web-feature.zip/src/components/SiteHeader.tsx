import { useHomeLanguage } from "@/components/HomeLanguage";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, BookOpen, Menu } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { Button } from "@/components/ui/button";

export function SiteHeader() {
  const { t } = useHomeLanguage();
  const { user } = useSession();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const { data: unread = 0 } = useQuery({
    queryKey: ["unread", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).eq("read", false);
      return count ?? 0;
    },
  });

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const { data: isAdmin = false } = useQuery({
    queryKey: ["is-admin", user?.id],
    enabled: !!user,
    queryFn: async () => user ? (await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" })).data ?? false : false,
  });
  const a = { className: "hover:text-primary", activeProps: { className: "text-primary font-medium" } };
  const links = (
    <>
      <Link to="/library" {...a}>{t("Library")}</Link>
      <Link to="/free-library" {...a}>{t("Free Library")}</Link>
      <Link to="/store" {...a}>{t("Store")}</Link>
      <Link to="/donate" {...a}>{t("Donate")}</Link>
      <Link to="/contact" {...a}>{t("Contact")}</Link>
      <Link to="/email-directory" {...a}>{t("Public Mail")}</Link>
      <Link to="/certified" {...a}>الترجمة المعتمدة</Link>
      {user && <Link to="/certified-work" {...a}>طلبات الوثائق</Link>}
      {user && <Link to="/dashboard" {...a}>My projects</Link>}
      {user && <Link to="/explore" {...a}>Explore projects</Link>}
      {user && <Link to="/poets" {...a}>Poets</Link>}
      {user && <Link to="/technical" {...a}>Science & code</Link>}
      {user && <Link to="/authoring" {...a}>تأليف كتاب</Link>}
      {user && <Link to="/programming" {...a}>البرمجة المشتركة</Link>}
      {user && <Link to="/mailbox" {...a}>Mailbox</Link>}
      {user && <Link to="/inbox" {...a}>Inbox</Link>}
      {user && <Link to="/documents" {...a}>Documents</Link>}
      {user && <Link to="/tasks" {...a}>Tasks</Link>}
      {user && <Link to="/ai-tools" {...a}>AI helper</Link>}
      {user && <Link to="/chat" search={{ member: undefined }} {...a}>Chat</Link>}
      {user && <Link to="/meetings" {...a}>Meetings</Link>}
      {user && <Link to="/privacy" {...a}>الخصوصية</Link>}
      {isAdmin && <Link to="/admin" {...a}>Admin</Link>}
    </>
  );

  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-6 px-4">
        <Link to={user ? "/dashboard" : "/"} className="flex shrink-0 items-center gap-2 font-display text-lg font-semibold">
          <BookOpen className="h-5 w-5 text-accent" /> Project of Word
        </Link>
        <nav className="hidden items-center gap-4 text-sm 2xl:flex">{links}</nav>
        <div className="ml-auto flex items-center gap-2">
          {user ? (
            <>
              <Link to="/notifications" className="relative rounded-md p-2 hover:bg-muted" aria-label="Notifications">
                <Bell className="h-5 w-5" />
                {unread > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-accent" />}
              </Link>
              <Button variant="ghost" size="sm" onClick={signOut} className="hidden 2xl:inline-flex">Sign out</Button>
            </>
          ) : (
            <Button asChild size="sm"><Link to="/auth">{t("Join as translator")}</Link></Button>
          )}
          <Button variant="ghost" size="icon" className="2xl:hidden" onClick={() => setOpen(!open)} aria-label="Menu"><Menu className="h-5 w-5" /></Button>
        </div>
      </div>
      {open && (
        <nav className="flex flex-col gap-3 border-t px-4 py-3 text-sm 2xl:hidden" onClick={() => setOpen(false)}>
          {links}
          {user && <button className="text-left" onClick={signOut}>Sign out</button>}
        </nav>
      )}
    </header>
  );
}
