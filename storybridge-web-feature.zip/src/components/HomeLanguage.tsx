import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Languages, RotateCcw } from "lucide-react";
import { translateHomepage, visitorCountry } from "@/lib/home-translation.functions";
import { preferredLanguage } from "@/lib/country-language";
import { HOME_COPY_VERSION, validateHomeTranslation } from "@/lib/home-copy";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { translateInterface } from '@/lib/interface-translation.functions';
import { applyInterfaceDictionary } from '@/lib/interface-language';
import catalog from '@/lib/ui-catalog.json';

const LanguageContext = createContext({ t: (text: string) => text, language: "", ready: false, hasPreference: false, direction: "ltr" as "ltr" | "rtl", setTranslation: (_language: string, _dictionary: Record<string, string>) => {} });
export function HomeLanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState("");
  const [dictionary, setDictionary] = useState<Record<string, string>>({});
  const [ready, setReady] = useState(false);
  const [hasPreference, setHasPreference] = useState(false);
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(HOME_COPY_VERSION) || "null");
      if (saved?.original) setHasPreference(true);
      else if (saved?.language) { const copy = validateHomeTranslation(saved.dictionary); setDictionary(copy); applyInterfaceDictionary(saved.language,copy); setLanguage(saved.language); setHasPreference(true); }
    } catch { /* Invalid cached translation: use the original. */ }
    setReady(true);
  }, []);
  const active = true;
  const direction = /^(ar|he|fa|ur|ps|sd|yi|dv|ku)(-|$)|arabic|hebrew|persian|urdu|pashto|sindhi|yiddish|dhivehi/i.test(language) ? "rtl" : "ltr";
  useEffect(()=>{document.documentElement.lang=language||'en';document.documentElement.dir=direction;},[language,direction]);
  function setTranslation(next: string, copy: Record<string, string>) {
    setLanguage(next); setDictionary(copy);
    applyInterfaceDictionary(next, copy);
    setHasPreference(true);
    try { localStorage.setItem(HOME_COPY_VERSION, JSON.stringify(next ? { language: next, dictionary: copy } : { original: true })); } catch { /* Storage may be disabled. */ }
  }
  return <LanguageContext.Provider value={{ t: text => active ? dictionary[text] || text : text, ready, hasPreference, language: active ? language : "", direction: active ? direction : "ltr", setTranslation }}>{children}</LanguageContext.Provider>;
}
export const useHomeLanguage = () => useContext(LanguageContext);
const CODES = "aa ab ae af ak am an ar as av ay az ba be bg bh bi bm bn bo br bs ca ce ch co cr cs cu cv cy da de dv dz ee el en eo es et eu fa ff fi fj fo fr fy ga gd gl gn gu gv ha he hi ho hr ht hu hy hz ia id ie ig ii ik io is it iu ja jv ka kg ki kj kk kl km kn ko kr ks ku kv kw ky la lb lg li ln lo lt lu lv mg mh mi mk ml mn mr ms mt my na nb nd ne ng nl nn no nr nv ny oc oj om or os pa pi pl ps pt qu rm rn ro ru rw sa sc sd se sg si sk sl sm sn so sq sr ss st su sv sw ta te tg th ti tk tl tn to tr ts tt tw ty ug uk ur uz ve vi vo wa wo xh yi yo za zh zu".split(" ");
export function HomeLanguagePicker() {
  const { language, ready, hasPreference, setTranslation } = useHomeLanguage();
  const run = useServerFn(translateHomepage);
  const detectCountry = useServerFn(visitorCountry);
  const translateLabels = useServerFn(translateInterface);
  const [localLanguage, setLocalLanguage] = useState("");
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [options, setOptions] = useState<Array<{ code: string; name: string }>>([]);
  const generation = useRef(0);
  useEffect(() => {
    if (!ready) return;
    let cancelled = false;
    async function detect() {
      let country: string | null = null;
      try { country = (await detectCountry()).country; } catch { /* Browser language fallback. */ }
      const selected = preferredLanguage(country, navigator.language);
      if (cancelled) return;
      setLocalLanguage(selected);
      if (!hasPreference) await applyLanguage(selected);
    }
    void detect();
    return () => { cancelled = true; };
  }, [ready]);
  useEffect(() => {
    const english = new Intl.DisplayNames(["en"], { type: "language" });
    setOptions(CODES.map(code => { let native = english.of(code) || code; try { native = new Intl.DisplayNames([code], { type: "language" }).of(code) || native; } catch {} return { code, name: `${native} · ${english.of(code) || code}` }; }));
  }, []);
  async function translate(e: React.FormEvent) {
    e.preventDefault(); if (!target.trim() || busy) return;
    await applyLanguage(target);
  }
  async function applyLanguage(selected: string) {
    const current=++generation.current;
    setBusy(true); setError("");
    setTarget(selected);
    try {
      let copy: Record<string,string> = {};
      try { copy = JSON.parse(localStorage.getItem(`interface-v1-${selected}`) || '{}'); } catch {}
      if (!Object.keys(copy).length) { const result = await run({data:{language:selected}}); copy = result.dictionary; }
      if(current!==generation.current)return;
      setTranslation(selected,copy);
      try{localStorage.setItem(`interface-v1-${selected}`,JSON.stringify(copy));}catch{}
      const missing = catalog.filter(source=>!copy[source]);
      for(let i=0;i<missing.length;i+=50) {
        const result=await translateLabels({data:{language:selected,strings:missing.slice(i,i+50)}});
        if(current!==generation.current)return;
        copy={...copy,...result.dictionary}; setTranslation(selected,copy);
        try{localStorage.setItem(`interface-v1-${selected}`,JSON.stringify(copy));}catch{}
      }
    }
    catch (e) { setError(e instanceof Error ? e.message : "Translation unavailable"); }
    finally { if(current===generation.current)setBusy(false); }
  }
  return <section className="border-b" aria-label="Page language"><form onSubmit={translate} className="mx-auto flex max-w-6xl flex-wrap items-end gap-3 px-4 py-4">
    <div className="min-w-0 flex-1"><Label htmlFor="home-language" className="flex items-center gap-2"><Languages className="h-4 w-4 text-accent" /> Language / اللغة</Label><Input id="home-language" list="world-languages" className="mt-2" value={target} maxLength={80} onChange={e => setTarget(e.target.value)} placeholder="Choose or type your language · اختر لغتك" /><datalist id="world-languages">{options.map(o => <option key={o.code} value={o.code}>{o.name}</option>)}</datalist></div>
    <Button type="submit" disabled={busy || !target.trim()}>{busy ? "Translating… / جارٍ الترجمة…" : "Translate / ترجم"}</Button>
    <Button type="button" variant="outline" disabled={busy} onClick={() => applyLanguage("ar")}>العربية</Button>
    {localLanguage && localLanguage !== "ar" && <Button type="button" variant="outline" disabled={busy} onClick={() => applyLanguage(localLanguage)}>{options.find(o => o.code === localLanguage)?.name || localLanguage}</Button>}
    {language && <Button variant="outline" type="button" onClick={() => { setTranslation("", {}); setTarget(""); }}><RotateCcw className="h-4 w-4" /> Original / الأصل</Button>}
    <div className="w-full text-xs text-muted-foreground" aria-live="polite">{busy ? "Please wait — translating the page." : error ? <span role="alert">{error}</span> : language ? `${language} · AI translation — ترجمة آلية` : "AI translation · ترجمة بالذكاء الاصطناعي"}</div>
  </form></section>;
}