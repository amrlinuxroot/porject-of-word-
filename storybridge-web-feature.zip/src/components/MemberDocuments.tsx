import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Download, Trash2, Upload, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { documentsQuery } from '@/lib/workspace-queries';
import { validateMemberDocument } from '@/lib/member-workspace';

export function MemberDocuments({userId,admin=false}:{userId:string;admin?:boolean}) {
  const qc=useQueryClient();const [busy,setBusy]=useState(false);
  const {data:documents=[],isPending,error}=useQuery(documentsQuery(userId,admin));
  return <section className="space-y-4"><h2 className="text-xl font-semibold">{admin?'Member documents':'Your documents'}</h2>
    {!admin&&<form className="grid gap-4 border-y py-5 sm:grid-cols-2" onSubmit={async e=>{
      e.preventDefault();const form=e.currentTarget;const f=new FormData(form);const file=f.get('file');if(!(file instanceof File))return;
      let path='';let saved=false;setBusy(true);
      try {validateMemberDocument(file,f.get('rights')==='on');path=`${userId}/${crypto.randomUUID()}.${file.name.split('.').pop()?.toLowerCase()}`;
        const {error:ue}=await supabase.storage.from('member-documents').upload(path,file);if(ue)throw ue;
        const {error:ie}=await supabase.from('member_documents').insert({user_id:userId,title:String(f.get('title')).trim(),file_name:file.name,file_path:path,rights_confirmed:true});if(ie)throw ie;saved=true;
        form.reset();await qc.invalidateQueries({queryKey:['member-documents']});toast.success('Document uploaded');
      }catch(e){if(path&&!saved)await supabase.storage.from('member-documents').remove([path]);toast.error(e instanceof Error?e.message:'Upload failed');}finally{setBusy(false);}
    }}><label>Document title<Input name="title" required maxLength={200} disabled={busy}/></label><label>Document file<Input name="file" type="file" accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg" required disabled={busy}/></label>
      <label className="flex items-start gap-2 text-sm sm:col-span-2"><input name="rights" type="checkbox" required disabled={busy}/>I own this document or have permission to upload it for private review.</label>
      <p className="text-sm text-muted-foreground sm:col-span-2">Private to you and administrators. Maximum 20 MB. Files have not been virus-scanned.</p>
      <Button disabled={busy} type="submit"><Upload/>{busy?'Uploading…':'Upload document'}</Button></form>}
    {isPending?<p role="status">Loading documents…</p>:error?<p role="alert">Documents could not be loaded.</p>:!documents.length?<p className="text-muted-foreground">No documents yet.</p>:<div className="divide-y border-y">{documents.map(d=><article key={d.id} className="flex flex-wrap items-center gap-3 py-4"><FileText className="h-5 w-5 shrink-0 text-primary"/><div className="min-w-0 flex-1"><h3 className="break-words font-medium">{d.title}</h3><p className="break-all text-sm text-muted-foreground">{d.file_name} · {new Date(d.created_at).toLocaleDateString()}</p>{admin&&<p className="break-all text-xs text-muted-foreground">Owner: {d.user_id}</p>}</div>
      <Button variant="outline" size="icon" title="Download document" aria-label={`Download ${d.title}`} onClick={async()=>{const {data,error}=await supabase.storage.from('member-documents').download(d.file_path);if(error)return void toast.error(error.message);const url=URL.createObjectURL(data);const a=document.createElement('a');a.href=url;a.download=d.file_name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}}><Download/></Button>
      {!admin&&<Button variant="ghost" size="icon" title="Delete document" aria-label={`Delete ${d.title}`} onClick={async()=>{if(!window.confirm('Delete this document?'))return;const {error}=await supabase.storage.from('member-documents').remove([d.file_path]);if(error)return void toast.error(error.message);const {error:de}=await supabase.from('member_documents').delete().eq('id',d.id);if(de)toast.error(de.message);else qc.invalidateQueries({queryKey:['member-documents']});}}><Trash2/></Button>}
    </article>)}</div>}
  </section>;
}