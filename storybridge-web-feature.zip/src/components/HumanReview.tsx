export function HumanReview({ reviewed, ethics, onReviewed, onEthics }: { reviewed: boolean; ethics: boolean; onReviewed: (value: boolean) => void; onEthics: (value: boolean) => void }) {
  return <div dir="rtl" className="space-y-2 text-sm">
    <label className="flex items-start gap-2"><input type="checkbox" checked={reviewed} onChange={e => onReviewed(e.target.checked)} />راجعت الترجمة بشريًا وتحققت من دقتها وسلامتها الأدبية؛ ليست ترجمة آلية دون إشراف.</label>
    <label className="flex items-start gap-2"><input type="checkbox" checked={ethics} onChange={e => onEthics(e.target.checked)} />ألتزم بأمانة الترجمة وحقوق المؤلف والسرية وأخلاقيات المترجم. المساعدة الآلية لا تعفيني من المسؤولية.</label>
  </div>;
}