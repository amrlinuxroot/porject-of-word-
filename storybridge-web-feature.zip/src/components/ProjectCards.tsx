import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import type { Tables } from "@/integrations/supabase/types";

export function ProjectCards({ projects, languages = [] }: { projects: Tables<"projects">[]; languages?: string[] }) {
  return <div className="grid gap-4 md:grid-cols-2">
    {projects.map((p) => <Link key={p.id} to="/projects/$projectId" params={{ projectId: p.id }} className="min-w-0 rounded-lg border bg-card p-5 shadow-page transition hover:border-primary">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
        <span className="font-mono">{p.project_number}</span>
        <div className="flex flex-wrap gap-2">
          {languages.includes(p.source_language) && languages.includes(p.target_language) && <Badge variant="outline">Your languages</Badge>}
          <Badge variant="secondary" className="capitalize">{p.status}</Badge>
        </div>
      </div>
      <h2 className="mt-2 break-words text-xl font-semibold" dir="auto">{p.title}</h2>
      <p className="text-sm text-muted-foreground" dir="auto">{p.author}</p>
      <p className="mt-3 text-sm">{p.source_language} → {p.target_language} · {p.field} · {p.media_type === "poetry" ? "Poetry" : p.media_type === "film" ? "Film / multimedia" : "Book / text"}</p>
    </Link>)}
  </div>;
}