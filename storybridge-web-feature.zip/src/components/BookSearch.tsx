import { useHomeLanguage } from "@/components/HomeLanguage";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Search, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { aiSearch } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Item = { id: string; kind: "translated" | "free"; title: string; author: string; language: string; description: string };

export function BookSearch() {
  const { t } = useHomeLanguage();
  const [q, setQ] = useState("");
  const [aiIds, setAiIds] = useState<string[] | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const smart = useServerFn(aiSearch);

  const { data: items = [] } = useQuery({
    queryKey: ["search-catalogue"],
    queryFn: async (): Promise<Item[]> => {
      const [p, d] = await Promise.all([
        supabase.from("projects").select("id, title, author, target_language, description").eq("status", "published").limit(100),
        supabase.from("donated_books").select("id, title, author, language, description").eq("status", "approved").limit(100),
      ]);
      return [
        ...(p.data ?? []).map((b) => ({ id: b.id, kind: "translated" as const, title: b.title, author: b.author, language: b.target_language, description: b.description })),
        ...(d.data ?? []).map((b) => ({ id: b.id, kind: "free" as const, title: b.title, author: b.author, language: b.language, description: b.description })),
      ];
    },
  });

  const term = q.trim().toLowerCase();
  const results = aiIds
    ? aiIds.map((id) => items.find((i) => i.id === id)).filter((x): x is Item => !!x)
    : term ? items.filter((i) => `${i.title} ${i.author} ${i.language} ${i.description}`.toLowerCase().includes(term)).slice(0, 8) : [];

  async function runAi() {
    if (!q.trim()) return;
    setBusy(true);
    try {
      const r = await smart({ data: { query: q, catalogue: items } });
      setAiIds(r.ids); setNote(r.note);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Search failed"); }
    finally { setBusy(false); }
  }

  return (
    <div className="w-full">
      <form onSubmit={(e) => { e.preventDefault(); runAi(); }} className="flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
          <Input aria-label={t("Search books")} className="h-11 pl-10 text-base" placeholder={t("Title, author, language — or describe what you need")} value={q}
            onChange={(e) => { setQ(e.target.value); setAiIds(null); setNote(""); }} />
        </div>
        <Button type="submit" size="lg" variant="secondary" disabled={busy || !q.trim()}><Sparkles className="h-4 w-4" /> {busy ? t("Searching…") : t("Ask AI")}</Button>
      </form>
      {note && <p className="mt-2 text-sm text-muted-foreground">{note}</p>}
      {(term || aiIds) && (
        <ul className="mt-3 divide-y rounded-lg border bg-card text-left">
          {results.length === 0 && <li className="p-4 text-sm text-muted-foreground">{t('Nothing found yet. Try "Ask AI", or suggest this book for translation.')}</li>}
          {results.map((r) => (
            <li key={r.id}>
              {r.kind === "translated" ? (
                <Link to="/read/$projectId" params={{ projectId: r.id }} className="block p-3 hover:bg-muted"><Row r={r} /></Link>
              ) : (
                <Link to="/free-library/$bookId" params={{ bookId: r.id }} className="block p-3 hover:bg-muted"><Row r={r} /></Link>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Row({ r }: { r: Item }) {
  const { t } = useHomeLanguage();
  return <><span className="font-semibold">{r.title}</span> <span className="text-sm text-muted-foreground">· {r.author} · {r.language} · {r.kind === "free" ? t("Free library") : t("Translated")}</span></>;
}
