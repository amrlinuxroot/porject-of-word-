import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

const MAX_BYTES = 5 * 1024 ** 3;

// Uploads straight to private storage with XHR so we can show progress.
export function VideoUpload({ projectId, onDone }: { projectId: string; onDone: () => void }) {
  const [pct, setPct] = useState<number | null>(null);

  async function upload(file: File) {
    if (!file.type.startsWith("video/")) return void toast.error("Please choose a video file.");
    if (file.size > MAX_BYTES) return void toast.error("Video is larger than 5 GB.");
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return void toast.error("Please sign in again.");
    const path = `${projectId}/${Date.now()}-${file.name.replace(/[^\w.-]+/g, "_")}`;
    setPct(0);
    const ok = await new Promise<boolean>((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `${import.meta.env['VITE_SUPABASE_URL']}/storage/v1/object/project-videos/${path}`);
      xhr.setRequestHeader("Authorization", `Bearer ${session.access_token}`);
      xhr.setRequestHeader("apikey", import.meta.env['VITE_SUPABASE_PUBLISHABLE_KEY']);
      xhr.setRequestHeader("Content-Type", file.type);
      xhr.upload.onprogress = (e) => e.lengthComputable && setPct(Math.round((e.loaded / e.total) * 100));
      xhr.onload = () => resolve(xhr.status >= 200 && xhr.status < 300);
      xhr.onerror = () => resolve(false);
      xhr.onabort = () => resolve(false);
      xhr.timeout = 600000;
      xhr.ontimeout = () => resolve(false);
      xhr.send(file);
    });
    if (!ok) { setPct(null); return void toast.error("Upload failed. Check your connection and try again."); }
    const { error } = await supabase.from("projects").update({ video_path: path }).eq("id", projectId);
    setPct(null);
    if (error) return void toast.error(error.message);
    toast.success("Video uploaded"); onDone();
  }

  return (
    <div className="space-y-2">
      <Input aria-label="Upload project video" type="file" accept="video/*" disabled={pct !== null} onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
      {pct !== null && <div className="flex items-center gap-3"><Progress value={pct} className="flex-1" /><span className="w-12 text-right text-sm">{pct}%</span></div>}
      {pct === null && <p className="text-xs text-muted-foreground">Up to 5 GB · stored privately for members</p>}
    </div>
  );
}
