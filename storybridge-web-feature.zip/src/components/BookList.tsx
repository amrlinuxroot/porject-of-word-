import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export function BookList({ store }: { store?: boolean }) {
  const { data = [], isLoading } = useQuery({
    queryKey: ["published"],
    queryFn: async () => (await supabase.from("projects").select("*").eq("status", "published").order("created_at", { ascending: false })).data ?? [],
  });
  if (isLoading) return <p className="text-muted-foreground">Loading…</p>;
  if (!data.length) return <p className="rounded-lg border bg-card p-8 text-center text-muted-foreground">No published books yet — they'll appear here once translations are finished.</p>;
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {data.map((b) => (
        <article key={b.id} className="flex flex-col rounded-lg border bg-paper p-5 shadow-page">
          <span className="font-mono text-xs text-muted-foreground">{b.project_number}</span>
          <h2 className="mt-1 text-xl font-semibold">{b.title}</h2>
          <p className="text-sm text-muted-foreground">{b.author} · {b.source_language} → {b.target_language}</p>
          <p className="mt-3 line-clamp-3 flex-1 text-sm">{b.description}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button asChild size="sm"><Link to="/read/$projectId" params={{ projectId: b.id }}>Read free</Link></Button>
            {store && b.google_books_url && <Button asChild size="sm" variant="outline"><a href={b.google_books_url} target="_blank" rel="noreferrer">Google Books</a></Button>}
            {store && b.kdp_url && <Button asChild size="sm" variant="outline"><a href={b.kdp_url} target="_blank" rel="noreferrer">Amazon</a></Button>}
          </div>
        </article>
      ))}
    </div>
  );
}
