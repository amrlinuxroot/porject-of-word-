import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CHARTER_TEXT, STATUS_LABELS } from '@/lib/certified';
import { openCertifiedFile, uploadCertifiedFile } from '@/lib/certified-files';
import { LANGUAGES } from '@/lib/text';

export function CertifiedProfile({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const [authority, setAuthority] = useState('');
  const [country, setCountry] = useState('');
  const [language, setLanguage] = useState('Arabic');
  const [file, setFile] = useState<File | null>(null);
  const [fullName, setFullName] = useState('');
  const [residence, setResidence] = useState('');
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [identityFile,setIdentityFile]=useState<File|null>(null);const [identityName,setIdentityName]=useState('');
  const {data:identity}=useQuery({queryKey:['certified-identity',userId],queryFn:async()=>{const r=await supabase.from('certified_identities').select('*').eq('user_id',userId).maybeSingle();if(r.error)throw r.error;return r.data;}});
  const {data:attribution}=useQuery({queryKey:['attribution',userId],queryFn:async()=>{const r=await supabase.from('work_attribution_preferences').select('*').eq('user_id',userId).maybeSingle();if(r.error)throw r.error;return r.data;}});
  const { data: preferences } = useQuery({ queryKey: ['service-preferences', userId], queryFn: async () => { const r = await supabase.from('translator_service_preferences').select('*').eq('user_id', userId).maybeSingle(); if (r.error) throw r.error; return r.data; } });
  const { data: credentials = [] } = useQuery({ queryKey: ['credentials', userId], queryFn: async () => { const r = await supabase.from('translator_credentials').select('*').eq('user_id', userId); if (r.error) throw r.error; return r.data; } });
  const { data: signature } = useQuery({ queryKey: ['charter', userId], queryFn: async () => { const r = await supabase.from('certified_charter_signatures').select('*').eq('user_id', userId).maybeSingle(); if (r.error) throw r.error; return r.data; } });
  async function upload() {
    if (!file || !authority.trim() || !country.trim()) return void toast.error('أكمل الجهة والبلد وأرفق شهادة الاعتماد');
    setBusy(true);
    try {
      const path = await uploadCertifiedFile(userId, 'credentials', file);
      const { error } = await supabase.from('translator_credentials').insert({ user_id: userId, authority: authority.trim(), country: country.trim(), target_language: language, certificate_path: path });
      if (error) throw error;
      toast.success('أُرسلت شهادة الاعتماد للمراجعة'); await qc.invalidateQueries({ queryKey: ['credentials'] });
    } catch (e) { toast.error(e instanceof Error ? e.message : 'تعذر الإرسال'); } finally { setBusy(false); }
  }
  async function sign() {
    if (!consent || fullName.trim().length < 3 || residence.trim().length < 2) return void toast.error('أدخل اسمك الكامل وبلد إقامتك ووافق على الميثاق');
    setBusy(true);
    const { error } = await supabase.rpc('sign_certified_charter', { _full_name: fullName, _residence_country: residence });
    setBusy(false);
    if (error) return void toast.error(error.message);
    toast.success('تم تسجيل توقيع الميثاق'); qc.invalidateQueries({ queryKey: ['charter'] });
  }
  return <section dir="rtl" className="space-y-5 border-t pt-6">
    <h2 className="text-2xl font-semibold">الاعتماد المهني وميثاق السرية</h2>
    <h3 className="text-xl font-semibold">التحقق من الهوية</h3>
    <p className="text-sm text-muted-foreground">هوية الهاوي اختيارية. لا يظهر اسمك الحقيقي على العمل إلا بعد التحقق منه وموافقتك على نشره؛ دون ذلك تُنسب المشاركة إلى مساهم دون اسم.</p>
    <label className="flex gap-2"><input type="checkbox" checked={attribution?.credit_requested??false} onChange={async e=>{const {error}=await supabase.from('work_attribution_preferences').upsert({user_id:userId,credit_requested:e.target.checked});if(error)toast.error(error.message);else qc.invalidateQueries({queryKey:['attribution']});}}/>أرغب في ذكر اسمي الحقيقي على العمل بعد التحقق من الهوية.</label>
    {identity?<p>{identity.full_name} — {STATUS_LABELS[identity.status]} · {identity.review_note}</p>:<div className="space-y-3"><label className="block">الاسم الكامل كما يظهر في وثيقة الهوية<Input value={identityName} onChange={e=>setIdentityName(e.target.value)}/></label><label className="block">وثيقة الهوية الخاصة بالإدارة<Input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e=>setIdentityFile(e.target.files?.[0]??null)}/></label><Button type="button" disabled={busy} onClick={async()=>{if(!identityFile||identityName.trim().length<3)return void toast.error('أكمل الاسم والهوية');setBusy(true);try{const path=await uploadCertifiedFile(userId,'credentials',identityFile);const {error}=await supabase.from('certified_identities').insert({user_id:userId,full_name:identityName,identity_path:path});if(error)throw error;qc.invalidateQueries({queryKey:['certified-identity']});toast.success('أرسلت الهوية للإدارة');}catch(e){toast.error(e instanceof Error?e.message:'تعذر الإرسال');}finally{setBusy(false);}}}>إرسال الهوية للتحقق</Button></div>}
    <label className="block space-y-2"><span>نوع المشاركة</span><select aria-label="نوع المشاركة" className="w-full rounded-md border bg-background p-2" value={preferences?.work_mode ?? 'volunteer'} onChange={async e => { const { error } = await supabase.from('translator_service_preferences').upsert({ user_id: userId, work_mode: e.target.value }); if (error) toast.error(error.message); else qc.invalidateQueries({ queryKey: ['service-preferences'] }); }}><option value="volunteer">مترجم متبرع</option><option value="paid">مترجم بأجر</option><option value="both">كلاهما</option></select></label>
    <div className="grid gap-3 sm:grid-cols-2">
      <label>السفارة / الجامعة / جهة الاعتماد<Input value={authority} onChange={e => setAuthority(e.target.value)} /></label>
      <label>بلد الاعتراف بالاعتماد<Input value={country} onChange={e => setCountry(e.target.value)} /></label>
      <label>لغة الاعتماد<select className="block w-full rounded-md border bg-background p-2" value={language} onChange={e => setLanguage(e.target.value)}>{LANGUAGES.map(l => <option key={l}>{l}</option>)}</select></label>
      <label>شهادة الاعتماد · PDF / JPG / PNG<Input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e => setFile(e.target.files?.[0] ?? null)} /></label>
    </div>
    <Button type="button" disabled={busy} onClick={upload}>إرسال الاعتماد للإدارة</Button>
    <p className="text-sm text-muted-foreground">الاعتماد مرتبط بالجهة والبلد واللغة؛ رفع شهادة لا يعني قبولها تلقائيًا أو الاعتراف بها عالميًا.</p>
    <ul className="divide-y">{credentials.map(c => <li key={c.id} className="py-3"><span>{c.authority} · {c.country} · {c.target_language} — {STATUS_LABELS[c.status]}</span>{c.review_note && <p className="text-sm text-muted-foreground">{c.review_note}</p>}<Button type="button" size="sm" variant="ghost" onClick={() => openCertifiedFile(c.certificate_path).catch(e => toast.error(e.message))}>شهادتي</Button></li>)}</ul>
    <h3 className="text-xl font-semibold">ميثاق الشرف وسرية الوثائق</h3>
    <p className="leading-loose">{signature?.charter_text ?? CHARTER_TEXT}</p>
    <p className="text-sm text-muted-foreground">الدول المذكورة معلنة من صاحب المشروع؛ الصياغة تحتاج مراجعة قانونية محلية قبل تقديم الخدمة فعليًا.</p>
    {signature ? <p className="border-s-2 border-primary ps-3 text-sm">وقّع {signature.full_name} · بلد الإقامة: {signature.residence_country} · {new Date(signature.signed_at).toLocaleString('ar')} · {signature.charter_version}</p> : <div className="space-y-3">
      <label className="block">الاسم القانوني الكامل للتوقيع<Input value={fullName} onChange={e => setFullName(e.target.value)} /></label>
      <label className="block">بلد الإقامة<Input value={residence} onChange={e => setResidence(e.target.value)} /></label>
      <label className="flex items-start gap-2"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} className="mt-1" />قرأت الميثاق وأوافق على الالتزام به، وأقصد باسمي أعلاه توقيعًا إلكترونيًا.</label>
      <Button type="button" disabled={busy || !consent} onClick={sign}>توقيع الميثاق إلكترونيًا</Button>
    </div>}
  </section>;
}