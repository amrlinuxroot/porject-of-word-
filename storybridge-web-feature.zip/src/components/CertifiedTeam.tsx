import {useQuery,useQueryClient} from '@tanstack/react-query';
import {toast} from 'sonner';
import {supabase} from '@/integrations/supabase/client';
import {Button} from '@/components/ui/button';
import {splitCertifiedRevenue} from '@/lib/certified-revenue';
export function CertifiedTeam({requestId,userId,leadId,quoteCents}:{requestId:string;userId:string;leadId:string|null;quoteCents:number|null}){
 const qc=useQueryClient();const {data:team=[]}=useQuery({queryKey:['certified-team',requestId],queryFn:async()=>{const r=await supabase.from('certified_team').select('*').eq('request_id',requestId);if(r.error)throw r.error;return r.data;}});
 const {data:directory=[]}=useQuery({queryKey:['certified-directory'],queryFn:async()=>{const r=await supabase.rpc('certified_translator_directory');if(r.error)throw r.error;return r.data;}});
 const participants=leadId?[leadId,...team.filter(t=>t.status==='accepted').map(t=>t.user_id)]:[];const split=quoteCents!==null&&participants.length?splitCertifiedRevenue(quoteCents,participants):null;
 return <section className="space-y-3 border-t pt-4"><h3 className="font-semibold">فريق الوثيقة وتقسيم العائد</h3><p className="text-sm text-muted-foreground">التقسيم الافتراضي بالتساوي بين المشاركين المقبولين؛ 5% فقط لتكاليف التشغيل، وليس تأكيدًا باستلام دفعة.</p>{split&&<><p>تكاليف التشغيل: {(split.opsCents/100).toFixed(2)}</p><ul>{split.shares.map(s=><li key={s.userId} className="text-sm">{directory.find(d=>d.user_id===s.userId)?.display_name??(s.userId===leadId?'المترجم المسؤول':'مساعد معتمد')}: {(s.cents/100).toFixed(2)}</li>)}</ul></>}
 {leadId===userId&&<div className="flex flex-wrap gap-2">{directory.filter((d,i,all)=>d.user_id!==userId&&!team.some(t=>t.user_id===d.user_id)&&all.findIndex(x=>x.user_id===d.user_id)===i).map(d=><Button key={d.user_id} size="sm" variant="outline" onClick={async()=>{const {error}=await supabase.rpc('invite_certified_helper',{_request:requestId,_helper:d.user_id});if(error)toast.error(error.message);else{toast.success('أُرسلت دعوة المساعدة');qc.invalidateQueries({queryKey:['certified-team']});}}}>دعوة {d.display_name} · {d.target_language}</Button>)}</div>}
 </section>;
}