import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";

export function MemberActivity() {
  const { user } = useSession();
  useEffect(() => {
    if (!user) return;
    const heartbeat = async () => {
      if (document.visibilityState !== "visible") return;
      const { error } = await supabase.from("member_activity").upsert({ user_id: user.id });
      if (error) console.error("Member activity unavailable", error.message);
    };
    void heartbeat();
    const timer = window.setInterval(heartbeat, 30000);
    document.addEventListener("visibilitychange", heartbeat);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", heartbeat); };
  }, [user?.id]);
  return null;
}