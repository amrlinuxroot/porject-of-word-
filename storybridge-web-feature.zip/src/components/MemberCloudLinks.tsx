import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ExternalLink, Link2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { validateCloudStorageLink, type CloudProvider } from "@/lib/team-sharing";

type CloudLink = {
  id: string;
  user_id: string;
  project_id: string | null;
  provider: CloudProvider;
  label: string;
  url: string;
  visibility: "private" | "team";
  created_at: string;
};

type ProjectChoice = { id: string; title: string };

const providerLabels: Record<CloudProvider, string> = {
  box: "Box",
  google_drive: "Google Drive",
  dropbox: "Dropbox",
  onedrive: "OneDrive",
  other: "Other HTTPS provider",
};

export function MemberCloudLinks({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [visibility, setVisibility] = useState<"private" | "team">("private");
  const [projectId, setProjectId] = useState("");
  const queryKey = ["member-cloud-links", userId];
  const linksQuery = useQuery({
    queryKey,
    queryFn: async () => {
      const membership = await supabase
        .from("collaboration_members")
        .select("project_id")
        .eq("user_id", userId)
        .eq("status", "accepted");
      const owned = await supabase
        .from("collaboration_projects")
        .select("id")
        .eq("owner_id", userId);
      if (membership.error || owned.error) throw membership.error ?? owned.error;
      const projectIds = [
        ...new Set([
          ...(membership.data ?? []).map((row) => row.project_id),
          ...(owned.data ?? []).map((row) => row.id),
        ]),
      ];
      const filters = [`user_id.eq.${userId}`];
      if (projectIds.length)
        filters.push(`and(visibility.eq.team,project_id.in.(${projectIds.join(",")}))`);
      const { data, error } = await supabase
        .from("member_cloud_links")
        .select("*")
        .or(filters.join(","))
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as CloudLink[];
    },
  });
  const projectsQuery = useQuery({
    queryKey: ["member-cloud-link-projects", userId],
    queryFn: async () => {
      const [owned, memberships] = await Promise.all([
        supabase.from("collaboration_projects").select("id,title").eq("owner_id", userId),
        supabase
          .from("collaboration_members")
          .select("project_id")
          .eq("user_id", userId)
          .eq("status", "accepted"),
      ]);
      if (owned.error || memberships.error) throw owned.error ?? memberships.error;
      const ids = [
        ...new Set([
          ...(owned.data ?? []).map((p) => p.id),
          ...(memberships.data ?? []).map((m) => m.project_id),
        ]),
      ];
      if (!ids.length) return [] as ProjectChoice[];
      const { data, error } = await supabase
        .from("collaboration_projects")
        .select("id,title")
        .in("id", ids)
        .order("title");
      if (error) throw error;
      return data as ProjectChoice[];
    },
  });

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    const provider = String(values.get("provider")) as CloudProvider;
    let url: string;
    try {
      url = validateCloudStorageLink(provider, String(values.get("url") ?? ""));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Invalid link");
      return;
    }
    if (visibility === "team" && !projectId) {
      toast.error("Choose the team that should see this link.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("member_cloud_links").insert({
      user_id: userId,
      provider,
      label: String(values.get("label") ?? "").trim(),
      url,
      visibility,
      project_id: visibility === "team" ? projectId : null,
    });
    setBusy(false);
    if (error) return void toast.error(error.message);
    form.reset();
    setVisibility("private");
    setProjectId("");
    await qc.invalidateQueries({ queryKey });
    toast.success("Cloud link saved.");
  }

  async function remove(link: CloudLink) {
    if (
      !window.confirm(
        `Remove “${link.label}”? This only removes the link from Project of Word; it does not delete anything at the external provider.`,
      )
    )
      return;
    const { error } = await supabase
      .from("member_cloud_links")
      .delete()
      .eq("id", link.id)
      .eq("user_id", userId);
    if (error) return void toast.error(error.message);
    await qc.invalidateQueries({ queryKey });
  }

  return (
    <section className="space-y-4 border-t pt-6">
      <div>
        <h2 className="text-xl font-semibold">External cloud-storage links</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Save a link to a folder you control in Box, Google Drive, Dropbox, OneDrive, or another
          HTTPS provider. This does not connect your account or copy files into Project of Word.
        </p>
      </div>
      <form className="grid gap-3 rounded-lg border p-4 sm:grid-cols-2" onSubmit={submit}>
        <label>
          Provider
          <select name="provider" className="mt-1 block w-full rounded-md border bg-background p-2">
            <option value="box">Box</option>
            <option value="google_drive">Google Drive</option>
            <option value="dropbox">Dropbox</option>
            <option value="onedrive">OneDrive</option>
            <option value="other">Other HTTPS provider</option>
          </select>
        </label>
        <label>
          Link name
          <Input
            name="label"
            required
            maxLength={120}
            placeholder="My translation folder"
            disabled={busy}
          />
        </label>
        <label className="sm:col-span-2">
          HTTPS folder or file link
          <Input name="url" type="url" required placeholder="https://…" disabled={busy} />
        </label>
        <label>
          Visibility
          <select
            value={visibility}
            onChange={(e) => setVisibility(e.target.value as "private" | "team")}
            className="mt-1 block w-full rounded-md border bg-background p-2"
          >
            <option value="private">Private — only me</option>
            <option value="team">Share link with a team</option>
          </select>
        </label>
        {visibility === "team" && (
          <label>
            Team
            <select
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              required
              className="mt-1 block w-full rounded-md border bg-background p-2"
            >
              <option value="">Choose a team project</option>
              {(projectsQuery.data ?? []).map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </select>
          </label>
        )}
        <p className="sm:col-span-2 text-sm text-amber-700">
          External provider permissions control who can open the destination. A team-visible link
          does not change its sharing settings at Box or another provider.
        </p>
        <Button type="submit" disabled={busy || projectsQuery.isPending}>
          {busy ? "Saving…" : "Save cloud link"}
        </Button>
      </form>
      {linksQuery.isPending ? (
        <p role="status">Loading cloud links…</p>
      ) : linksQuery.error ? (
        <p role="alert">Cloud links could not be loaded.</p>
      ) : !linksQuery.data?.length ? (
        <p className="text-sm text-muted-foreground">No external links saved.</p>
      ) : (
        <ul className="divide-y border-y">
          {linksQuery.data.map((link) => (
            <li key={link.id} className="flex flex-wrap items-center gap-3 py-3">
              <Link2 className="h-5 w-5 shrink-0 text-primary" />
              <div className="min-w-0 flex-1">
                <p className="font-medium">
                  {link.label}{" "}
                  <span className="text-xs text-muted-foreground">
                    · {providerLabels[link.provider]}
                  </span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {link.visibility === "private"
                    ? "Private"
                    : `Shared with ${projectsQuery.data?.find((p) => p.id === link.project_id)?.title ?? "team project"}`}
                </p>
              </div>
              <Button asChild size="sm" variant="outline">
                <a href={link.url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Open
                </a>
              </Button>
              {link.user_id === userId && (
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  aria-label={`Remove ${link.label}`}
                  title="Remove link"
                  onClick={() => void remove(link)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
