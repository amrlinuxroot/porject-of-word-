import { Link } from '@tanstack/react-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LANGUAGES } from '@/lib/text';
export function Collaborations({ userId, kind }: { userId: string; kind: 'book' | 'software' }) {
  const qc = useQueryClient(); const [open,setOpen] = useState(false); const [busy,setBusy] = useState(false);
  const { data: projects = [] } = useQuery({ queryKey:['collaborations',kind], queryFn:async () => { const r=await supabase.from('collaboration_projects').select('*').eq('kind',kind).order('created_at',{ascending:false}); if(r.error) throw r.error; return r.data; } });
  const { data: members=[] } = useQuery({queryKey:['collaboration-members',userId],queryFn:async()=>{const r=await supabase.from('collaboration_members').select('*');if(r.error)throw r.error;return r.data;}});
  async function create(e:React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f=new FormData(e.currentTarget); setBusy(true);
    const {data,error}=await supabase.from('collaboration_projects').insert({owner_id:userId,kind,title:String(f.get('title')).trim(),lead_author:String(f.get('author')).trim(),field:String(f.get('field')),language:String(f.get('language')),description:String(f.get('description')),needed_roles:String(f.get('roles')),rights_confirmed:f.get('rights')==='on'}).select('id').single();
    setBusy(false);if(error)return void toast.error(error.message); if(data){toast.success('أُنشئ المشروع');qc.invalidateQueries({queryKey:['collaborations']});setOpen(false);}
  }
  return <main dir="rtl" className="mx-auto max-w-5xl space-y-7 px-4 py-10"><h1 className="text-3xl font-semibold">{kind==='book'?'شارك معنا في تأليف كتاب':'قم ببرمجة برنامج معًا'}</h1><div className="flex flex-wrap gap-3"><Button onClick={()=>setOpen(!open)}>{kind==='book'?'اقترح كتابًا وفريقًا':'أنشئ مشروعًا برمجيًا'}</Button>{kind==='software'&&<Button asChild variant="outline"><Link to="/developers">دليل بريد المطورين</Link></Button>}</div>
    {open&&<form onSubmit={create} className="grid gap-4 border-y py-6 sm:grid-cols-2"><label>اسم المشروع<Input name="title" required maxLength={300}/></label><label>{kind==='book'?'المؤلف الأول':'منسق المشروع'}<Input name="author" required/></label><label>المجال<Input name="field" required/></label><label>اللغة<select name="language" className="block w-full rounded-md border bg-background p-2">{LANGUAGES.map(l=><option key={l}>{l}</option>)}</select></label><label className="sm:col-span-2">فكرة المشروع وأهدافه الإنسانية<Textarea name="description" required/></label><label className="sm:col-span-2">الأدوار المطلوبة (بحث، جمع بيانات، تواصل، تطوير…)<Input name="roles" required/></label><label className="flex gap-2 sm:col-span-2"><input name="rights" type="checkbox" required/>أملك حق إنشاء هذا العمل وأوافق على المساهمات المشتركة مع حفظ حقوق المشاركين.</label><Button disabled={busy} type="submit">إنشاء المشروع</Button></form>}
    <div className="grid gap-4 sm:grid-cols-2">{projects.map(p=><article key={p.id} className="rounded-lg border bg-card p-5"><p className="text-xs text-accent">{p.status==='recruiting'?'يبحث عن فريق':p.status==='working'?'قيد العمل':'منشور'} · {p.language}</p><h2 className="mt-2 text-xl font-semibold">{p.title}</h2><p className="mt-2 text-sm">{kind==='book'?'المؤلف الأول':'المنسق'}: {p.lead_author}</p><p className="mt-3 line-clamp-3">{p.description}</p><p className="mt-3 text-sm text-muted-foreground">المطلوب: {p.needed_roles}</p><p className="mt-2 text-sm">{p.owner_id===userId?'مشروعي':members.some(m=>m.project_id===p.id&&m.user_id===userId)?'طلب مشاركتي مسجل':''}</p><Button asChild className="mt-4" variant="outline"><Link to="/collaborate/$projectId" params={{projectId:p.id}}>فتح مساحة العمل</Link></Button></article>)}</div>{!projects.length&&<p className="border-y py-10 text-center text-muted-foreground">لا توجد مشاريع بعد.</p>}
  </main>;
}