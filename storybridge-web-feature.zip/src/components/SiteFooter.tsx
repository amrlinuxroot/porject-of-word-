import { useHomeLanguage } from "@/components/HomeLanguage";
import { Link } from "@tanstack/react-router";
import { FOUNDERS } from "@/lib/founders";

export function SiteFooter() {
  const { t } = useHomeLanguage();
  return (
    <footer className="border-t bg-paper">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-sm text-muted-foreground md:flex-row md:items-center">
        <span className="font-display text-base text-foreground">Project of Word · مشروع كلمة</span>
        <span className="md:ml-4">{t("An idea by")} {FOUNDERS.map((f) => f.en).join(", ")}</span>
        <nav className="flex gap-4 md:ml-auto">
          <Link to="/about" className="hover:text-primary">{t("About")}</Link>
          <Link to="/contact" className="hover:text-primary">{t("Contact")}</Link>
          <Link to="/donate" className="hover:text-primary">{t("Donate")}</Link>
        </nav>
      </div>
    </footer>
  );
}
