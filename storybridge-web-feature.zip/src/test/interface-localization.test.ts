import { parse } from '@babel/parser';
import { readdirSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { interfaceLocalization } from '../../scripts/interface-localization.mjs';

const parseTsx = (code: string) => parse(code, { sourceType: 'module', plugins: ['typescript', 'jsx'] });

describe('Interface localization compilation', () => {
  it.each(['Use "quoted" label', String.raw`Path C:\users\uploads`, 'العربية · Français'])('compiles option labels containing %s', (label) => {
    const code = `export const View = () => <select><option>${label}</option></select>`;
    const result = interfaceLocalization().transform(code, '/project/src/routes/example.tsx');
    expect(result).not.toBeNull();
    if (!result) throw new Error('Expected transformed option');
    expect(() => parseTsx(result.code)).not.toThrow();
  });

  const files = (dir: string): string[] => readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const path = resolve(dir, entry.name);
    return entry.isDirectory() ? files(path) : path.endsWith('.tsx') ? [path] : [];
  });

  it.each([...files(resolve('src/routes')), ...files(resolve('src/components'))])('compiles the localized source of %s', (file) => {
    const code = readFileSync(file, 'utf8');
    const result = interfaceLocalization().transform(code, file);
    expect(() => parseTsx(result?.code ?? code)).not.toThrow();
  });
});