export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18";
  };
  public: {
    Tables: {
      admin_inbox: {
        Row: {
          attachment_name: string;
          attachment_path: string;
          created_at: string;
          external_url: string;
          id: string;
          message: string;
          scan_status: string;
          sender_id: string;
          subject: string;
        };
        Insert: {
          attachment_name?: string;
          attachment_path?: string;
          created_at?: string;
          external_url?: string;
          id?: string;
          message: string;
          scan_status?: string;
          sender_id: string;
          subject: string;
        };
        Update: {
          attachment_name?: string;
          attachment_path?: string;
          created_at?: string;
          external_url?: string;
          id?: string;
          message?: string;
          scan_status?: string;
          sender_id?: string;
          subject?: string;
        };
        Relationships: [
          {
            foreignKeyName: "admin_inbox_sender_id_fkey";
            columns: ["sender_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      book_suggestions: {
        Row: {
          admin_note: string;
          ai_contribution_percent: number | null;
          author: string;
          author_wants_royalty: boolean;
          created_at: string;
          declaration: boolean;
          description: string;
          field: string;
          has_copyright: string;
          id: string;
          kind: string;
          original_language: string;
          permission: string;
          proof_link: string;
          proof_note: string;
          rights_holder_email: string;
          rights_holder_name: string;
          source_link: string;
          source_text: string;
          status: string;
          submitter_email: string;
          submitter_name: string;
          submitter_role: string;
          target_languages: string;
          title: string;
        };
        Insert: {
          admin_note?: string;
          ai_contribution_percent?: number | null;
          author?: string;
          author_wants_royalty?: boolean;
          created_at?: string;
          declaration: boolean;
          description?: string;
          field?: string;
          has_copyright: string;
          id?: string;
          kind?: string;
          original_language?: string;
          permission: string;
          proof_link?: string;
          proof_note?: string;
          rights_holder_email?: string;
          rights_holder_name?: string;
          source_link?: string;
          source_text?: string;
          status?: string;
          submitter_email: string;
          submitter_name: string;
          submitter_role?: string;
          target_languages?: string;
          title: string;
        };
        Update: {
          admin_note?: string;
          ai_contribution_percent?: number | null;
          author?: string;
          author_wants_royalty?: boolean;
          created_at?: string;
          declaration?: boolean;
          description?: string;
          field?: string;
          has_copyright?: string;
          id?: string;
          kind?: string;
          original_language?: string;
          permission?: string;
          proof_link?: string;
          proof_note?: string;
          rights_holder_email?: string;
          rights_holder_name?: string;
          source_link?: string;
          source_text?: string;
          status?: string;
          submitter_email?: string;
          submitter_name?: string;
          submitter_role?: string;
          target_languages?: string;
          title?: string;
        };
        Relationships: [];
      };
      certified_applications: {
        Row: {
          created_at: string;
          request_id: string;
          translator_id: string;
        };
        Insert: {
          created_at?: string;
          request_id: string;
          translator_id: string;
        };
        Update: {
          created_at?: string;
          request_id?: string;
          translator_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "certified_applications_request_id_fkey";
            columns: ["request_id"];
            isOneToOne: false;
            referencedRelation: "certified_requests";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "certified_applications_translator_id_fkey";
            columns: ["translator_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      certified_charter_signatures: {
        Row: {
          charter_text: string;
          charter_version: string;
          full_name: string;
          jurisdictions: string;
          residence_country: string;
          signed_at: string;
          user_id: string;
        };
        Insert: {
          charter_text: string;
          charter_version?: string;
          full_name: string;
          jurisdictions?: string;
          residence_country: string;
          signed_at?: string;
          user_id: string;
        };
        Update: {
          charter_text?: string;
          charter_version?: string;
          full_name?: string;
          jurisdictions?: string;
          residence_country?: string;
          signed_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "certified_charter_signatures_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      certified_identities: {
        Row: {
          created_at: string;
          full_name: string;
          identity_path: string;
          review_note: string;
          status: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          full_name: string;
          identity_path: string;
          review_note?: string;
          status?: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          full_name?: string;
          identity_path?: string;
          review_note?: string;
          status?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "certified_identities_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      certified_requests: {
        Row: {
          admin_note: string;
          assigned_to: string | null;
          authority: string;
          consent: boolean;
          country: string;
          created_at: string;
          currency: string;
          delivery_ethics_accepted: boolean;
          delivery_human_reviewed: boolean;
          delivery_path: string;
          document_kind: string;
          document_path: string;
          id: string;
          notes: string;
          quote_accepted: boolean;
          quote_cents: number | null;
          requester_id: string;
          source_language: string;
          status: string;
          target_language: string;
          work_mode: string;
        };
        Insert: {
          admin_note?: string;
          assigned_to?: string | null;
          authority: string;
          consent?: boolean;
          country: string;
          created_at?: string;
          currency?: string;
          delivery_ethics_accepted?: boolean;
          delivery_human_reviewed?: boolean;
          delivery_path?: string;
          document_kind: string;
          document_path: string;
          id?: string;
          notes?: string;
          quote_accepted?: boolean;
          quote_cents?: number | null;
          requester_id: string;
          source_language: string;
          status?: string;
          target_language: string;
          work_mode?: string;
        };
        Update: {
          admin_note?: string;
          assigned_to?: string | null;
          authority?: string;
          consent?: boolean;
          country?: string;
          created_at?: string;
          currency?: string;
          delivery_ethics_accepted?: boolean;
          delivery_human_reviewed?: boolean;
          delivery_path?: string;
          document_kind?: string;
          document_path?: string;
          id?: string;
          notes?: string;
          quote_accepted?: boolean;
          quote_cents?: number | null;
          requester_id?: string;
          source_language?: string;
          status?: string;
          target_language?: string;
          work_mode?: string;
        };
        Relationships: [
          {
            foreignKeyName: "certified_requests_assigned_to_fkey";
            columns: ["assigned_to"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "certified_requests_requester_id_fkey";
            columns: ["requester_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      certified_team: {
        Row: {
          request_id: string;
          status: string;
          user_id: string;
          weight: number;
        };
        Insert: {
          request_id: string;
          status?: string;
          user_id: string;
          weight?: number;
        };
        Update: {
          request_id?: string;
          status?: string;
          user_id?: string;
          weight?: number;
        };
        Relationships: [
          {
            foreignKeyName: "certified_team_request_id_fkey";
            columns: ["request_id"];
            isOneToOne: false;
            referencedRelation: "certified_requests";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "certified_team_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      collaboration_contributions: {
        Row: {
          content: string;
          created_at: string;
          id: string;
          project_id: string;
          title: string;
          user_id: string;
        };
        Insert: {
          content: string;
          created_at?: string;
          id?: string;
          project_id: string;
          title: string;
          user_id: string;
        };
        Update: {
          content?: string;
          created_at?: string;
          id?: string;
          project_id?: string;
          title?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "collaboration_contributions_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "collaboration_projects";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "collaboration_contributions_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      collaboration_members: {
        Row: {
          contribution_role: string;
          created_at: string;
          credit_name: string;
          project_id: string;
          status: string;
          user_id: string;
        };
        Insert: {
          contribution_role: string;
          created_at?: string;
          credit_name: string;
          project_id: string;
          status?: string;
          user_id: string;
        };
        Update: {
          contribution_role?: string;
          created_at?: string;
          credit_name?: string;
          project_id?: string;
          status?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "collaboration_members_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "collaboration_projects";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "collaboration_members_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      collaboration_projects: {
        Row: {
          created_at: string;
          description: string;
          field: string;
          id: string;
          kind: string;
          language: string;
          lead_author: string;
          manuscript: string;
          needed_roles: string;
          owner_id: string;
          publication_audio: string;
          publication_digital: string;
          publication_print: string;
          publication_video: string;
          repository_url: string;
          rights_confirmed: boolean;
          status: string;
          title: string;
        };
        Insert: {
          created_at?: string;
          description?: string;
          field?: string;
          id?: string;
          kind: string;
          language: string;
          lead_author: string;
          manuscript?: string;
          needed_roles?: string;
          owner_id: string;
          publication_audio?: string;
          publication_digital?: string;
          publication_print?: string;
          publication_video?: string;
          repository_url?: string;
          rights_confirmed?: boolean;
          status?: string;
          title: string;
        };
        Update: {
          created_at?: string;
          description?: string;
          field?: string;
          id?: string;
          kind?: string;
          language?: string;
          lead_author?: string;
          manuscript?: string;
          needed_roles?: string;
          owner_id?: string;
          publication_audio?: string;
          publication_digital?: string;
          publication_print?: string;
          publication_video?: string;
          repository_url?: string;
          rights_confirmed?: boolean;
          status?: string;
          title?: string;
        };
        Relationships: [
          {
            foreignKeyName: "collaboration_projects_owner_id_fkey";
            columns: ["owner_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      direct_messages: {
        Row: {
          content: string;
          created_at: string;
          id: string;
          recipient_id: string;
          sender_id: string;
        };
        Insert: {
          content: string;
          created_at?: string;
          id?: string;
          recipient_id: string;
          sender_id: string;
        };
        Update: {
          content?: string;
          created_at?: string;
          id?: string;
          recipient_id?: string;
          sender_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "direct_messages_recipient_id_fkey";
            columns: ["recipient_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "direct_messages_sender_id_fkey";
            columns: ["sender_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      donated_books: {
        Row: {
          ai_contribution_percent: number | null;
          author: string;
          content: string;
          created_at: string;
          description: string;
          ethics_accepted: boolean;
          field: string;
          human_reviewed: boolean;
          id: string;
          language: string;
          original_language: string;
          status: string;
          submitted_by: string;
          title: string;
          translator_name: string;
        };
        Insert: {
          ai_contribution_percent?: number | null;
          author?: string;
          content: string;
          created_at?: string;
          description?: string;
          ethics_accepted?: boolean;
          field?: string;
          human_reviewed?: boolean;
          id?: string;
          language: string;
          original_language?: string;
          status?: string;
          submitted_by: string;
          title: string;
          translator_name?: string;
        };
        Update: {
          ai_contribution_percent?: number | null;
          author?: string;
          content?: string;
          created_at?: string;
          description?: string;
          ethics_accepted?: boolean;
          field?: string;
          human_reviewed?: boolean;
          id?: string;
          language?: string;
          original_language?: string;
          status?: string;
          submitted_by?: string;
          title?: string;
          translator_name?: string;
        };
        Relationships: [];
      };
      donations: {
        Row: {
          amount_cents: number;
          created_at: string;
          donor_name: string | null;
          id: string;
        };
        Insert: {
          amount_cents: number;
          created_at?: string;
          donor_name?: string | null;
          id?: string;
        };
        Update: {
          amount_cents?: number;
          created_at?: string;
          donor_name?: string | null;
          id?: string;
        };
        Relationships: [];
      };
      mailbox: {
        Row: {
          content: string;
          created_at: string;
          ethics_accepted: boolean;
          human_reviewed: boolean;
          id: string;
          note: string;
          page_number: number;
          project_number: string;
          sender_id: string;
          status: string;
        };
        Insert: {
          content: string;
          created_at?: string;
          ethics_accepted?: boolean;
          human_reviewed?: boolean;
          id?: string;
          note?: string;
          page_number: number;
          project_number: string;
          sender_id: string;
          status?: string;
        };
        Update: {
          content?: string;
          created_at?: string;
          ethics_accepted?: boolean;
          human_reviewed?: boolean;
          id?: string;
          note?: string;
          page_number?: number;
          project_number?: string;
          sender_id?: string;
          status?: string;
        };
        Relationships: [];
      };
      meetings: {
        Row: {
          created_at: string;
          created_by: string;
          id: string;
          meet_link: string | null;
          starts_at: string;
          topic: string;
          translator_id: string;
        };
        Insert: {
          created_at?: string;
          created_by: string;
          id?: string;
          meet_link?: string | null;
          starts_at: string;
          topic: string;
          translator_id: string;
        };
        Update: {
          created_at?: string;
          created_by?: string;
          id?: string;
          meet_link?: string | null;
          starts_at?: string;
          topic?: string;
          translator_id?: string;
        };
        Relationships: [];
      };
      member_activity: {
        Row: {
          last_seen: string;
          user_id: string;
        };
        Insert: {
          last_seen?: string;
          user_id: string;
        };
        Update: {
          last_seen?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_activity_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      member_contacts: {
        Row: {
          created_at: string;
          description: string;
          developer_opt_in: boolean;
          email: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          description?: string;
          developer_opt_in?: boolean;
          email: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          description?: string;
          developer_opt_in?: boolean;
          email?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_contacts_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      member_documents: {
        Row: {
          created_at: string;
          file_name: string;
          file_path: string;
          id: string;
          rights_confirmed: boolean;
          title: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          file_name: string;
          file_path: string;
          id?: string;
          rights_confirmed?: boolean;
          title: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          file_name?: string;
          file_path?: string;
          id?: string;
          rights_confirmed?: boolean;
          title?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_documents_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      member_privacy: {
        Row: {
          chat_audience: string;
          email_audience: string;
          user_id: string;
        };
        Insert: {
          chat_audience?: string;
          email_audience?: string;
          user_id: string;
        };
        Update: {
          chat_audience?: string;
          email_audience?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_privacy_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      member_tasks: {
        Row: {
          created_at: string;
          description: string;
          due_date: string | null;
          id: string;
          priority: string;
          status: string;
          title: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          description?: string;
          due_date?: string | null;
          id?: string;
          priority?: string;
          status?: string;
          title: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          description?: string;
          due_date?: string | null;
          id?: string;
          priority?: string;
          status?: string;
          title?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_tasks_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      messages: {
        Row: {
          content: string;
          created_at: string;
          id: string;
          sender_id: string;
        };
        Insert: {
          content: string;
          created_at?: string;
          id?: string;
          sender_id: string;
        };
        Update: {
          content?: string;
          created_at?: string;
          id?: string;
          sender_id?: string;
        };
        Relationships: [];
      };
      notifications: {
        Row: {
          created_at: string;
          id: string;
          link: string | null;
          message: string;
          read: boolean;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          link?: string | null;
          message: string;
          read?: boolean;
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          link?: string | null;
          message?: string;
          read?: boolean;
          user_id?: string;
        };
        Relationships: [];
      };
      organization_verifications: {
        Row: {
          certificate_paths: string[];
          country: string;
          created_at: string;
          id: string;
          identity_path: string;
          organization_name: string;
          organization_type: string;
          representative_name: string;
          review_note: string;
          reviewed_at: string | null;
          status: string;
          user_id: string;
        };
        Insert: {
          certificate_paths: string[];
          country: string;
          created_at?: string;
          id?: string;
          identity_path: string;
          organization_name: string;
          organization_type: string;
          representative_name: string;
          review_note?: string;
          reviewed_at?: string | null;
          status?: string;
          user_id: string;
        };
        Update: {
          certificate_paths?: string[];
          country?: string;
          created_at?: string;
          id?: string;
          identity_path?: string;
          organization_name?: string;
          organization_type?: string;
          representative_name?: string;
          review_note?: string;
          reviewed_at?: string | null;
          status?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "organization_verifications_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      pages: {
        Row: {
          end_time: string;
          id: string;
          original_text: string;
          page_number: number;
          project_id: string;
          start_time: string;
        };
        Insert: {
          end_time?: string;
          id?: string;
          original_text: string;
          page_number: number;
          project_id: string;
          start_time?: string;
        };
        Update: {
          end_time?: string;
          id?: string;
          original_text?: string;
          page_number?: number;
          project_id?: string;
          start_time?: string;
        };
        Relationships: [
          {
            foreignKeyName: "pages_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "projects";
            referencedColumns: ["id"];
          },
        ];
      };
      poetry_comments: {
        Row: {
          author_id: string;
          content: string;
          created_at: string;
          id: string;
          post_id: string;
        };
        Insert: {
          author_id: string;
          content: string;
          created_at?: string;
          id?: string;
          post_id: string;
        };
        Update: {
          author_id?: string;
          content?: string;
          created_at?: string;
          id?: string;
          post_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "poetry_comments_author_id_fkey";
            columns: ["author_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "poetry_comments_post_id_fkey";
            columns: ["post_id"];
            isOneToOne: false;
            referencedRelation: "poetry_posts";
            referencedColumns: ["id"];
          },
        ];
      };
      poetry_posts: {
        Row: {
          author_id: string;
          content: string;
          created_at: string;
          id: string;
          language: string;
          rights_confirmed: boolean;
          title: string;
        };
        Insert: {
          author_id: string;
          content: string;
          created_at?: string;
          id?: string;
          language?: string;
          rights_confirmed?: boolean;
          title: string;
        };
        Update: {
          author_id?: string;
          content?: string;
          created_at?: string;
          id?: string;
          language?: string;
          rights_confirmed?: boolean;
          title?: string;
        };
        Relationships: [
          {
            foreignKeyName: "poetry_posts_author_id_fkey";
            columns: ["author_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      poetry_sessions: {
        Row: {
          created_at: string;
          description: string;
          host_id: string;
          id: string;
          meeting_url: string;
          starts_at: string;
          title: string;
        };
        Insert: {
          created_at?: string;
          description?: string;
          host_id: string;
          id?: string;
          meeting_url: string;
          starts_at: string;
          title: string;
        };
        Update: {
          created_at?: string;
          description?: string;
          host_id?: string;
          id?: string;
          meeting_url?: string;
          starts_at?: string;
          title?: string;
        };
        Relationships: [
          {
            foreignKeyName: "poetry_sessions_host_id_fkey";
            columns: ["host_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          bio: string;
          contributor_role: string;
          country: string;
          created_at: string;
          display_name: string;
          expertise: string;
          fields: string[];
          id: string;
          institution: string;
          languages: string[];
          notify_email: string;
          organization_website: string;
          registration_type: string;
          source_languages: string[];
          study_level: string;
          survey_completed: boolean;
          target_languages: string[];
        };
        Insert: {
          bio?: string;
          contributor_role?: string;
          country?: string;
          created_at?: string;
          display_name?: string;
          expertise?: string;
          fields?: string[];
          id: string;
          institution?: string;
          languages?: string[];
          notify_email?: string;
          organization_website?: string;
          registration_type?: string;
          source_languages?: string[];
          study_level?: string;
          survey_completed?: boolean;
          target_languages?: string[];
        };
        Update: {
          bio?: string;
          contributor_role?: string;
          country?: string;
          created_at?: string;
          display_name?: string;
          expertise?: string;
          fields?: string[];
          id?: string;
          institution?: string;
          languages?: string[];
          notify_email?: string;
          organization_website?: string;
          registration_type?: string;
          source_languages?: string[];
          study_level?: string;
          survey_completed?: boolean;
          target_languages?: string[];
        };
        Relationships: [];
      };
      project_members: {
        Row: {
          joined_at: string;
          project_id: string;
          user_id: string;
        };
        Insert: {
          joined_at?: string;
          project_id: string;
          user_id: string;
        };
        Update: {
          joined_at?: string;
          project_id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "project_members_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "projects";
            referencedColumns: ["id"];
          },
        ];
      };
      projects: {
        Row: {
          ai_contribution_percent: number | null;
          author: string;
          author_royalty_percent: number;
          created_at: string;
          created_by: string;
          description: string;
          field: string;
          google_books_url: string | null;
          id: string;
          kdp_url: string | null;
          media_type: string;
          ops_percent: number;
          project_number: string;
          source_language: string;
          source_link: string;
          status: Database["public"]["Enums"]["project_status"];
          target_language: string;
          title: string;
          total_revenue_cents: number;
          video_path: string;
          video_url: string;
        };
        Insert: {
          ai_contribution_percent?: number | null;
          author?: string;
          author_royalty_percent?: number;
          created_at?: string;
          created_by: string;
          description?: string;
          field?: string;
          google_books_url?: string | null;
          id?: string;
          kdp_url?: string | null;
          media_type?: string;
          ops_percent?: number;
          project_number?: string;
          source_language: string;
          source_link?: string;
          status?: Database["public"]["Enums"]["project_status"];
          target_language: string;
          title: string;
          total_revenue_cents?: number;
          video_path?: string;
          video_url?: string;
        };
        Update: {
          ai_contribution_percent?: number | null;
          author?: string;
          author_royalty_percent?: number;
          created_at?: string;
          created_by?: string;
          description?: string;
          field?: string;
          google_books_url?: string | null;
          id?: string;
          kdp_url?: string | null;
          media_type?: string;
          ops_percent?: number;
          project_number?: string;
          source_language?: string;
          source_link?: string;
          status?: Database["public"]["Enums"]["project_status"];
          target_language?: string;
          title?: string;
          total_revenue_cents?: number;
          video_path?: string;
          video_url?: string;
        };
        Relationships: [];
      };
      site_settings: {
        Row: {
          key: string;
          updated_at: string;
          value: string;
        };
        Insert: {
          key: string;
          updated_at?: string;
          value?: string;
        };
        Update: {
          key?: string;
          updated_at?: string;
          value?: string;
        };
        Relationships: [];
      };
      translations: {
        Row: {
          content: string;
          created_at: string;
          ethics_accepted: boolean;
          human_reviewed: boolean;
          id: string;
          is_selected: boolean;
          page_id: string;
          translator_id: string;
        };
        Insert: {
          content: string;
          created_at?: string;
          ethics_accepted?: boolean;
          human_reviewed?: boolean;
          id?: string;
          is_selected?: boolean;
          page_id: string;
          translator_id: string;
        };
        Update: {
          content?: string;
          created_at?: string;
          ethics_accepted?: boolean;
          human_reviewed?: boolean;
          id?: string;
          is_selected?: boolean;
          page_id?: string;
          translator_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "translations_page_id_fkey";
            columns: ["page_id"];
            isOneToOne: false;
            referencedRelation: "pages";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "translations_translator_id_fkey";
            columns: ["translator_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      translator_credentials: {
        Row: {
          authority: string;
          certificate_path: string;
          country: string;
          created_at: string;
          id: string;
          review_note: string;
          status: string;
          target_language: string;
          user_id: string;
        };
        Insert: {
          authority: string;
          certificate_path: string;
          country: string;
          created_at?: string;
          id?: string;
          review_note?: string;
          status?: string;
          target_language: string;
          user_id: string;
        };
        Update: {
          authority?: string;
          certificate_path?: string;
          country?: string;
          created_at?: string;
          id?: string;
          review_note?: string;
          status?: string;
          target_language?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "translator_credentials_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      translator_service_preferences: {
        Row: {
          user_id: string;
          work_mode: string;
        };
        Insert: {
          user_id: string;
          work_mode?: string;
        };
        Update: {
          user_id?: string;
          work_mode?: string;
        };
        Relationships: [
          {
            foreignKeyName: "translator_service_preferences_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      user_roles: {
        Row: {
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
      votes: {
        Row: {
          created_at: string;
          translation_id: string;
          voter_id: string;
        };
        Insert: {
          created_at?: string;
          translation_id: string;
          voter_id: string;
        };
        Update: {
          created_at?: string;
          translation_id?: string;
          voter_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "votes_translation_id_fkey";
            columns: ["translation_id"];
            isOneToOne: false;
            referencedRelation: "translations";
            referencedColumns: ["id"];
          },
        ];
      };
      work_attribution_preferences: {
        Row: {
          credit_requested: boolean;
          user_id: string;
        };
        Insert: {
          credit_requested?: boolean;
          user_id: string;
        };
        Update: {
          credit_requested?: boolean;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "work_attribution_preferences_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      team_files: {
        Row: {
          content_type: string;
          created_at: string;
          file_name: string;
          file_path: string;
          file_size: number;
          id: string;
          is_shared: boolean;
          project_id: string;
          rights_confirmed: boolean;
          title: string;
          uploader_id: string;
        };
        Insert: {
          content_type: string;
          created_at?: string;
          file_name: string;
          file_path: string;
          file_size: number;
          id?: string;
          is_shared?: boolean;
          project_id: string;
          rights_confirmed?: boolean;
          title: string;
          uploader_id: string;
        };
        Update: {
          is_shared?: boolean;
        };
        Relationships: [
          {
            foreignKeyName: "team_files_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "collaboration_projects";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "team_files_uploader_id_fkey";
            columns: ["uploader_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      member_cloud_links: {
        Row: {
          created_at: string;
          id: string;
          label: string;
          project_id: string | null;
          provider: string;
          url: string;
          user_id: string;
          visibility: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          label: string;
          project_id?: string | null;
          provider: string;
          url: string;
          user_id: string;
          visibility?: string;
        };
        Update: {
          label?: string;
          project_id?: string | null;
          provider?: string;
          url?: string;
          visibility?: string;
        };
        Relationships: [
          {
            foreignKeyName: "member_cloud_links_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "collaboration_projects";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "member_cloud_links_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      accept_certified_helper: {
        Args: { _request: string };
        Returns: undefined;
      };
      accept_certified_job: { Args: { _request: string }; Returns: undefined };
      accept_certified_quote: { Args: { _request: string }; Returns: undefined };
      can_apply_certified: {
        Args: { _request: string; _user: string };
        Returns: boolean;
      };
      can_message_member: { Args: { _recipient: string }; Returns: boolean };
      can_view_member_email: { Args: { _owner: string }; Returns: boolean };
      certified_access: {
        Args: { _request: string; _user: string };
        Returns: boolean;
      };
      certified_opportunities: {
        Args: never;
        Returns: {
          authority: string;
          country: string;
          document_kind: string;
          eligible: boolean;
          id: string;
          source_language: string;
          target_language: string;
          work_mode: string;
        }[];
      };
      certified_qualified: {
        Args: { _request: string; _user: string };
        Returns: boolean;
      };
      certified_translator_directory: {
        Args: never;
        Returns: {
          authority: string;
          country: string;
          display_name: string;
          target_language: string;
          user_id: string;
        }[];
      };
      developer_contact_directory: {
        Args: never;
        Returns: {
          description: string;
          display_name: string;
          email: string;
          user_id: string;
        }[];
      };
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"];
          _user_id: string;
        };
        Returns: boolean;
      };
      invite_certified_helper: {
        Args: { _helper: string; _request: string };
        Returns: undefined;
      };
      list_admins: {
        Args: never;
        Returns: {
          display_name: string;
          email: string;
          user_id: string;
        }[];
      };
      member_classification_counts: {
        Args: never;
        Returns: {
          country: string;
          members: number;
          registration_type: string;
          source_language: string;
          target_language: string;
        }[];
      };
      my_notification_email: { Args: never; Returns: string };
      public_contact_directory: {
        Args: never;
        Returns: {
          description: string;
          display_name: string;
          email: string;
          user_id: string;
        }[];
      };
      select_best_translations: {
        Args: { _project_id: string };
        Returns: number;
      };
      set_admin_by_email: {
        Args: { _email: string; _make_admin: boolean };
        Returns: string;
      };
      sign_certified_charter: {
        Args: { _full_name: string; _residence_country: string };
        Returns: undefined;
      };
      submit_certified_delivery: {
        Args: { _path: string; _request: string };
        Returns: undefined;
      };
      submit_reviewed_certified_delivery: {
        Args: {
          _ethics_accepted: boolean;
          _human_reviewed: boolean;
          _path: string;
          _request: string;
        };
        Returns: undefined;
      };
      verified_work_name: { Args: { _user: string }; Returns: string };
    };
    Enums: {
      app_role: "admin" | "translator";
      project_status: "translating" | "voting" | "published";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "translator"],
      project_status: ["translating", "voting", "published"],
    },
  },
} as const;
