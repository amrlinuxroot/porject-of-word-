import { createFileRoute } from "@tanstack/react-router";
import { BookList } from "@/components/BookList";

export const Route = createFileRoute("/library")({
  head: () => ({
    meta: [
      { title: "Library — Project of Word" },
      { name: "description", content: "Read volunteer-translated books for free." },
      { property: "og:title", content: "Library — Project of Word" },
      { property: "og:description", content: "Read volunteer-translated books for free." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-4xl font-semibold">Library</h1>
      <p className="mb-8 mt-2 text-muted-foreground">Finished translations, free to read.</p>
      <BookList />
    </div>
  ),
});
