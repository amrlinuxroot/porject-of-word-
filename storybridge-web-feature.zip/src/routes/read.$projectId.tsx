import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/read/$projectId")({
  head: () => ({
    meta: [
      { title: "Reader — Project of Word" },
      { name: "description", content: "Read a translated book page by page alongside the original." },
      { property: "og:title", content: "Reader — Project of Word" },
      { property: "og:description", content: "Read a translated book alongside the original." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Reader,
});

function Reader() {
  const { projectId } = Route.useParams();
  const [i, setI] = useState(0);
  const [showOriginal, setShowOriginal] = useState(false);
  const [size, setSize] = useState(18);
  const { data } = useQuery({
    queryKey: ["read", projectId],
    queryFn: async () => {
      const { data: project } = await supabase.from("projects").select("*").eq("id", projectId).maybeSingle();
      const { data: pages } = await supabase.from("pages").select("id, page_number, original_text, translations(content, is_selected)").eq("project_id", projectId).order("page_number");
      return { project, pages: pages ?? [] };
    },
  });
  if (!data) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  if (!data.project) return <div className="p-10 text-center text-muted-foreground">This book isn't published yet.</div>;
  const page = data.pages[i];
  const tr = page?.translations.find((t) => t.is_selected);

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <p className="font-mono text-xs text-muted-foreground">{data.project.project_number}</p>
      <h1 className="text-4xl font-semibold">{data.project.title}</h1>
      <p className="text-muted-foreground">{data.project.author} · translated into {data.project.target_language} by volunteers</p>
      <div className="mt-6 flex items-center gap-3">
        <Button size="sm" variant="outline" onClick={() => setShowOriginal(!showOriginal)}>{showOriginal ? "Hide" : "Show"} original</Button>
        <Button size="sm" variant="outline" aria-label="Smaller text" onClick={() => setSize(Math.max(14, size - 2))}>A−</Button>
        <Button size="sm" variant="outline" aria-label="Larger text" onClick={() => setSize(Math.min(30, size + 2))}>A+</Button>
        <label className="ml-auto flex items-center gap-2 text-sm text-muted-foreground">Page
          <select className="h-9 rounded-md border bg-background px-2" value={i} onChange={(e) => setI(Number(e.target.value))}>
            {data.pages.map((p, n) => <option key={p.id} value={n}>{p.page_number}</option>)}
          </select> of {data.pages.length}</label>
      </div>
      {page && (
        <div className={`mt-4 grid gap-6 ${showOriginal ? "md:grid-cols-2" : ""}`}>
          {showOriginal && <article className="rounded-lg border bg-card p-8 text-muted-foreground whitespace-pre-wrap leading-relaxed">{page.original_text}</article>}
          <article dir="auto" style={{ fontSize: size }} className="rounded-lg border bg-paper p-8 font-display leading-loose whitespace-pre-wrap shadow-page">
            {tr?.content ?? <span className="text-muted-foreground">This page has no selected translation yet.</span>}
          </article>
        </div>
      )}
      <div className="mt-6 flex justify-between">
        <Button variant="outline" disabled={i === 0} onClick={() => setI(i - 1)}>Previous</Button>
        <Button disabled={i >= data.pages.length - 1} onClick={() => setI(i + 1)}>Next</Button>
      </div>
    </div>
  );
}
