import { useEffect } from "react";
import { useSession } from "@/lib/use-session";
import { memberDestination } from "@/lib/projects";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { FileText, Languages, Vote, HeartHandshake, GraduationCap, Film, PenLine } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Button } from "@/components/ui/button";
import { BookSearch } from "@/components/BookSearch";
import { SuggestDialog } from "@/components/SuggestDialog";
import { useHomeLanguage } from "@/components/HomeLanguage";
import { MISSION } from "@/lib/home-copy";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Project of Word — Find, read and translate books together" },
      { name: "description", content: "Search translated books, suggest a book or film to translate, and join volunteers worldwide. All proceeds go to translators and authors." },
      { property: "og:title", content: "Project of Word — Find, read and translate books together" },
      { property: "og:description", content: "A global charity for collaborative translation of books, study books and films." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const steps = [
  { icon: FileText, title: "Suggest a work", body: "Books, study books or films — always with the rights holder's permission." },
  { icon: Languages, title: "Translate together", body: "Volunteers matched by language and field translate page by page or scene by scene." },
  { icon: Vote, title: "Vote for the best", body: "The community votes; winners are notified the moment they're selected." },
  { icon: HeartHandshake, title: "Publish & share", body: "Google Books, Amazon KDP and our free reader. Proceeds go to translators — and the author, if they wish." },
];

const audiences = [
  { icon: GraduationCap, title: "Students", body: "Translate the science and study books your university or school uses, and help classmates everywhere." },
  { icon: PenLine, title: "Writers & publishers", body: "Bring your book to new languages. You can receive a share of the translated book's sales." },
  { icon: Film, title: "Films & multimedia", body: "Subtitle documentaries, lectures and films with time-coded segments and ready SRT files." },
];

function Index() {
  const { t, language, direction } = useHomeLanguage();
  const { user, ready } = useSession();
  const navigate = useNavigate();
  useEffect(() => {
    if (!ready || !user) return;
    const destination = memberDestination(sessionStorage.getItem("postAuth"));
    sessionStorage.removeItem("postAuth");
    navigate({ to: destination, replace: true });
  }, [ready, user, navigate]);
  if (ready && user) return <p className="p-10 text-center" role="status">Opening your projects…</p>;
  return (
    <div lang={language || "en"} dir={direction}>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 md:grid-cols-2 md:py-16">
        <div>
          <p className="mb-4 text-sm font-medium uppercase tracking-widest text-accent">{t("Project of Word · مشروع كلمة")}</p>
          <h1 className="text-4xl font-semibold leading-tight md:text-5xl">{t("Find a book. Or help it find a new language.")}</h1>
          <div className="mt-6"><BookSearch /></div>
          <div className="mt-6 flex flex-wrap gap-3">
            <SuggestDialog trigger={<Button size="lg">{t("Suggest a book or film")}</Button>} />
            <Button asChild size="lg" variant="outline"><Link to="/library">{t("Browse the library")}</Link></Button>
            <Button asChild size="lg" variant="ghost"><Link to="/auth">{t("Join us")}</Link></Button>
          </div>
        </div>
        <img src={hero} alt={t("An open book releasing lines of many scripts like birds")} width={1536} height={1024} className="w-full rounded-lg shadow-page" />
      </section>
      <section className="border-t bg-paper" aria-labelledby="mission-title" lang={language || "ar"} dir={language ? direction : "rtl"}>
        <div className="mx-auto max-w-4xl px-4 py-12 md:py-16">
          <p className="mb-3 text-sm font-medium text-accent">{t(MISSION.eyebrow)}</p>
          <h2 id="mission-title" className="text-3xl font-semibold leading-relaxed">{t(MISSION.title)}</h2>
          <div className="mt-6 space-y-5 text-lg leading-loose">{MISSION.paragraphs.map(p => <p key={p}>{t(p)}</p>)}</div>
          <p className="mt-7 border-s-2 border-accent ps-4 text-xl font-semibold leading-relaxed">{t(MISSION.closing)}</p>
          <Button asChild size="lg" className="mt-6"><Link to="/auth">{t(MISSION.join)}</Link></Button>
        </div>
      </section>
      <section className="border-t bg-paper">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <div key={t(s.title)}>
              <div className="mb-3 flex items-center gap-3">
                <span className="font-display text-3xl text-accent">{i + 1}</span>
                <s.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">{t(s.title)}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{t(s.body)}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-14 md:grid-cols-3">
        {audiences.map((a) => (
          <div key={t(a.title)} className="rounded-lg border bg-card p-6">
            <a.icon className="h-6 w-6 text-accent" />
            <h3 className="mt-3 text-lg font-semibold">{t(a.title)}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{t(a.body)}</p>
          </div>
        ))}
      </section>
      <section className="border-t bg-paper">
        <div className="mx-auto max-w-6xl px-4 py-14 text-center">
          <h2 className="text-3xl font-semibold">{t("Support the work")}</h2>
          <p className="mx-auto mt-3 max-w-lg text-muted-foreground">{t("We keep no profit. Donations fund servers, editing and outreach so more knowledge crosses more borders.")}</p>
          <Button asChild className="mt-6" variant="secondary"><Link to="/donate">{t("Donate")}</Link></Button>
        </div>
      </section>
    </div>
  );
}
