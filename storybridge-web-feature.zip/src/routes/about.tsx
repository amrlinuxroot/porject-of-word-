import { createFileRoute } from "@tanstack/react-router";
import { FOUNDERS } from "@/lib/founders";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Project of Word" },
      { name: "description", content: "Project of Word is a global charity connecting volunteer translators, students, writers and publishers. Meet the founders." },
      { property: "og:title", content: "About — Project of Word" },
      { property: "og:description", content: "A global charity making translation and understanding between people easier." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14">
      <p className="text-sm font-medium uppercase tracking-widest text-accent">Project of Word · مشروع كلمة</p>
      <h1 className="mt-2 text-4xl font-semibold">About the project</h1>
      <p className="mt-5 text-lg text-muted-foreground">
        A global charity that makes translation and communication between people easier. Volunteers, students, writers and publishers work together on books, study books and films — always with the rights holder's permission. We keep no profit: sales pay the translators, cover operating costs and, if they wish, reward the author.
      </p>
      <p dir="rtl" className="mt-4 text-lg text-muted-foreground">
        مشروع عالمي خيري لتسهيل الترجمة والتواصل بين الناس. لا تحتفظ المنظمة بأي أرباح.
      </p>
      <h2 className="mt-12 text-2xl font-semibold">Founders · المؤسسون</h2>
      <ul className="mt-4 grid gap-3 sm:grid-cols-3">
        {FOUNDERS.map((f) => (
          <li key={f.en} className="rounded-lg border bg-card p-5 text-center">
            <div dir="rtl" className="font-display text-xl">{f.ar}</div>
            <div className="mt-1 text-sm text-muted-foreground">{f.en}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
