import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { authorRoyaltyCents, distributeRevenue, formatMoney, MAX_ACTIVE_PROJECTS } from "@/lib/text";
import { SubtitlePreview } from "@/components/SubtitlePreview";
import { VideoUpload } from "@/components/VideoUpload";

export const Route = createFileRoute("/_authenticated/projects/$projectId")({
  head: () => ({ meta: [{ title: "Project — Project of Word" }, { name: "description", content: "Translation project pages and progress." }, { property: "og:title", content: "Project — Project of Word" }, { property: "og:description", content: "Translation project pages and progress." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: ProjectPage,
});

function ProjectPage() {
  const { projectId } = Route.useParams();
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["project", projectId],
    queryFn: async () => {
      const { data: project } = await supabase.from("projects").select("*").eq("id", projectId).single();
      const { data: pages } = await supabase.from("pages").select("id, page_number, original_text, start_time, end_time, translations(content, id, translator_id, is_selected, profiles(display_name))").eq("project_id", projectId).order("page_number");
      const { data: members } = await supabase.from("project_members").select("user_id").eq("project_id", projectId);
      const { data: mine } = await supabase.from("project_members").select("project_id, projects(status)").eq("user_id", user.id);
      const myActive = (mine ?? []).filter((m) => m.projects?.status !== "published").length;
      return { project, pages: pages ?? [], members: members ?? [], myActive };
    },
  });
  const videoPath = data?.project?.video_path ?? "";
  const { data: videoUrl } = useQuery({
    queryKey: ["video-url", videoPath], enabled: !!videoPath,
    queryFn: async () => (await supabase.storage.from("project-videos").createSignedUrl(videoPath, 3600)).data?.signedUrl ?? null,
  });
  const [form, setForm] = useState<{ google: string; kdp: string; revenue: string; ops: string } | null>(null);
  if (!data?.project) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  const { project, pages, members, myActive } = data;
  const joined = members.some((m) => m.user_id === user.id);
  const isOwner = project.created_by === user.id;
  const f = form ?? { google: project.google_books_url ?? "", kdp: project.kdp_url ?? "", revenue: String(project.total_revenue_cents / 100), ops: String(project.ops_percent) };

  const selectedBy: Record<string, number> = {};
  const names: Record<string, string> = {};
  for (const p of pages) for (const t of p.translations) {
    names[t.translator_id] = t.profiles?.display_name ?? "Translator";
    if (t.is_selected) selectedBy[t.translator_id] = (selectedBy[t.translator_id] ?? 0) + 1;
  }
  const opsCents = Math.round((project.total_revenue_cents * project.ops_percent) / 100);
  const authorCents = authorRoyaltyCents(project.total_revenue_cents, project.ops_percent, project.author_royalty_percent);
  const dist = { opsCents, shares: distributeRevenue(project.total_revenue_cents - opsCents - authorCents, 0, selectedBy).shares };
  const isFilm = project.media_type === "film";
  async function toggleJoin() {
    const { error } = joined
      ? await supabase.from("project_members").delete().eq("project_id", projectId).eq("user_id", user.id)
      : await supabase.from("project_members").insert({ project_id: projectId, user_id: user.id });
    if (error) return void toast.error(error.message.includes("at most 5") ? `You can join at most ${MAX_ACTIVE_PROJECTS} active projects at a time.` : error.message);
    toast.success(joined ? "You left this project" : "You joined this project"); refresh();
  }
  const segments = pages.map((p) => ({ start: p.start_time, end: p.end_time, text: p.translations.find((t) => t.is_selected)?.content ?? p.original_text }));
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["project", projectId] });
    qc.invalidateQueries({ queryKey: ["my-memberships", user.id] });
    qc.invalidateQueries({ queryKey: ["projects"] });
  };

  async function setStatus(status: "translating" | "voting" | "published") {
    const { error } = await supabase.from("projects").update({ status }).eq("id", projectId);
    if (error) toast.error(error.message); else { toast.success(`Status: ${status}`); refresh(); }
  }
  async function selectWinners() {
    const { data: n, error } = await supabase.rpc("select_best_translations", { _project_id: projectId });
    if (error) return void toast.error(error.message);
    toast.success(`${n} winning translations selected — translators notified`);
    refresh();
  }
  async function saveDistribution() {
    const { error } = await supabase.from("projects").update({
      google_books_url: f.google || null, kdp_url: f.kdp || null,
      total_revenue_cents: Math.round(Number(f.revenue || 0) * 100),
      ops_percent: Math.min(100, Math.max(0, Number(f.ops || 0))),
    }).eq("id", projectId);
    if (error) toast.error(error.message); else { toast.success("Saved"); setForm(null); refresh(); }
  }

  const selectedCount = pages.filter((p) => p.translations.some((t) => t.is_selected)).length;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
        <span className="font-mono">{project.project_number}</span>
        <Badge variant="secondary" className="capitalize">{project.status}</Badge>
        <span>{project.source_language} → {project.target_language} · {project.field}</span>
      </div>
      <h1 className="mt-2 text-4xl font-semibold">{project.title}</h1>
      <p className="text-muted-foreground">{project.author}</p>
      {project.description && <p className="mt-4 max-w-2xl">{project.description}</p>}
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <Button size="sm" variant={joined ? "outline" : "default"} onClick={toggleJoin}>{joined ? "Leave project" : "Join this project"}</Button>
        <span className="text-sm text-muted-foreground">{members.length} member{members.length === 1 ? "" : "s"} · you're in {myActive}/{MAX_ACTIVE_PROJECTS} active projects</span>
        {project.video_url && <Button size="sm" variant="outline" asChild><a href={project.video_url} target="_blank" rel="noreferrer">Watch video</a></Button>}
        {project.source_link && <Button size="sm" variant="outline" asChild><a href={project.source_link} target="_blank" rel="noreferrer">Full file</a></Button>}
        {isFilm && <SubtitlePreview segments={segments} fileName={`${project.project_number}-${project.target_language}`} />}
      </div>

      {isFilm && (videoUrl || isOwner) && (
        <div className="mt-6 max-w-3xl space-y-2">
          {videoUrl && <video src={videoUrl} controls className="w-full rounded-lg border bg-muted" />}
          {isOwner && <VideoUpload projectId={projectId} onDone={() => refresh()} />}
        </div>
      )}
      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
        <section>
          <h2 className="mb-3 text-xl font-semibold">{isFilm ? "Segments" : project.media_type === "poetry" ? "Poems" : "Pages"} <span className="text-sm font-normal text-muted-foreground">({selectedCount}/{pages.length} selected)</span></h2>
          <div className="divide-y rounded-lg border bg-card">
            {pages.map((p) => (
              <Link key={p.id} to="/pages/$pageId" params={{ pageId: p.id }} className="flex items-center gap-4 p-4 hover:bg-muted">
                <span className="w-10 font-display text-2xl text-accent">{p.page_number}</span>
                <span className="line-clamp-1 flex-1 text-sm text-muted-foreground">{isFilm && <span className="mr-2 font-mono text-xs">{p.start_time}</span>}{p.original_text}</span>
                <span className="text-xs">{p.translations.length} translation{p.translations.length === 1 ? "" : "s"}</span>
                {p.translations.some((t) => t.is_selected) && <CheckCircle2 className="h-4 w-4 text-success" />}
              </Link>
            ))}
          </div>
        </section>

        <aside className="space-y-6">
          {isOwner && (
            <div className="rounded-lg border bg-card p-5">
              <h3 className="font-semibold">Manage</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => setStatus("translating")}>Translating</Button>
                <Button size="sm" variant="outline" onClick={() => setStatus("voting")}>Open voting</Button>
                <Button size="sm" onClick={selectWinners}>Select winners</Button>
                <Button size="sm" variant="secondary" onClick={() => setStatus("published")}>Publish</Button>
              </div>
            </div>
          )}
          <div className="rounded-lg border bg-card p-5">
            <h3 className="font-semibold">Revenue distribution</h3>
            <p className="mt-1 text-xs text-muted-foreground">{project.ops_percent}% covers operations{project.author_royalty_percent > 0 ? `, ${project.author_royalty_percent}% of the rest goes to the author` : ""}; the rest is split by selected pages. The charity keeps no profit.</p>
            <dl className="mt-3 space-y-1 text-sm">
              <div className="flex justify-between"><dt>Total sales</dt><dd>{formatMoney(project.total_revenue_cents)}</dd></div>
              <div className="flex justify-between"><dt>Operations</dt><dd>{formatMoney(dist.opsCents)}</dd></div>
              {authorCents > 0 && <div className="flex justify-between"><dt>Author</dt><dd>{formatMoney(authorCents)}</dd></div>}
              {dist.shares.map((s) => (
                <div key={s.translatorId} className="flex justify-between"><dt>{names[s.translatorId]} · {s.pages} pg</dt><dd>{formatMoney(s.cents)}</dd></div>
              ))}
            </dl>
            {isOwner && (
              <div className="mt-4 space-y-2 border-t pt-4">
                <div><Label>Total sales ($)</Label><Input type="number" value={f.revenue} onChange={(e) => setForm({ ...f, revenue: e.target.value })} /></div>
                <div><Label>Operations %</Label><Input type="number" value={f.ops} onChange={(e) => setForm({ ...f, ops: e.target.value })} /></div>
                <div><Label>Google Books link</Label><Input value={f.google} onChange={(e) => setForm({ ...f, google: e.target.value })} /></div>
                <div><Label>Amazon KDP link</Label><Input value={f.kdp} onChange={(e) => setForm({ ...f, kdp: e.target.value })} /></div>
                <Button size="sm" onClick={saveDistribution}>Save</Button>
              </div>
            )}
          </div>
          {project.status === "published" && (
            <Button asChild variant="outline" className="w-full"><Link to="/read/$projectId" params={{ projectId }}>Open reader</Link></Button>
          )}
        </aside>
      </div>
    </div>
  );
}
