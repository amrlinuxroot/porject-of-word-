import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { CalendarDays, Feather, Trash2, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LANGUAGES } from "@/lib/text";

export const Route = createFileRoute("/_authenticated/poets")({
  head: () => ({ meta: [
    { title: "Poets’ gathering — Project of Word" }, { name: "description", content: "Share poems, discuss translation and join poetry readings with members worldwide." },
    { property: "og:title", content: "Poets’ gathering — Project of Word" }, { property: "og:description", content: "A members’ meeting place for poetry, discussion and readings." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }), component: Poets,
});

function Poets() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [poem, setPoem] = useState({ title: "", content: "", language: "Arabic", rights: false });
  const [session, setSession] = useState({ title: "", description: "", starts: "", url: "" });
  const [comment, setComment] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const { data, isPending, error } = useQuery({
    queryKey: ["poets", user.id],
    queryFn: async () => {
      const [posts, comments, sessions] = await Promise.all([
        supabase.from("poetry_posts").select("*, profiles(display_name)").order("created_at", { ascending: false }).limit(100),
        supabase.from("poetry_comments").select("*, profiles(display_name)").order("created_at").limit(1000),
        supabase.from("poetry_sessions").select("*, profiles(display_name)").order("starts_at").gte("starts_at", new Date().toISOString()),
      ]);
      if (posts.error || comments.error || sessions.error) throw posts.error ?? comments.error ?? sessions.error;
      return { posts: posts.data ?? [], comments: comments.data ?? [], sessions: sessions.data ?? [] };
    },
  });
  async function share(e: React.FormEvent) {
    e.preventDefault();
    if (!poem.rights || !poem.title.trim() || !poem.content.trim()) return;
    setBusy(true);
    const { error } = await supabase.from("poetry_posts").insert({ author_id: user.id, title: poem.title.trim(), content: poem.content.trim(), language: poem.language, rights_confirmed: poem.rights });
    setBusy(false);
    if (error) return void toast.error(error.message);
    setPoem({ ...poem, title: "", content: "", rights: false });
    qc.invalidateQueries({ queryKey: ["poets"] }); toast.success("Poem shared");
  }
  async function schedule(e: React.FormEvent) {
    e.preventDefault();
    const starts = new Date(session.starts);
    if (!session.title.trim() || !Number.isFinite(starts.getTime())) return;
    if (!session.url.startsWith("https://")) return void toast.error("Use an https meeting link.");
    setBusy(true);
    const { error } = await supabase.from("poetry_sessions").insert({ host_id: user.id, title: session.title.trim(), description: session.description, starts_at: starts.toISOString(), meeting_url: session.url });
    setBusy(false);
    if (error) return void toast.error(error.message);
    setSession({ title: "", description: "", starts: "", url: "" });
    qc.invalidateQueries({ queryKey: ["poets"] }); toast.success("Poetry session scheduled");
  }
  async function reply(postId: string, e: React.FormEvent) {
    e.preventDefault();
    const content = comment[postId]?.trim(); if (!content) return;
    const { error } = await supabase.from("poetry_comments").insert({ post_id: postId, author_id: user.id, content });
    if (error) return void toast.error(error.message);
    setComment({ ...comment, [postId]: "" }); qc.invalidateQueries({ queryKey: ["poets"] });
  }
  async function remove(table: "poetry_posts" | "poetry_comments" | "poetry_sessions", id: string) {
    if (!window.confirm(table === "poetry_sessions" ? "Cancel this poetry session?" : "Delete this contribution?")) return;
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["poets"] });
  }
  return <div className="mx-auto max-w-6xl px-4 py-10">
    <div className="mb-8 flex flex-wrap items-center justify-between gap-4"><h1 className="flex items-center gap-3 text-3xl font-semibold"><Feather className="h-7 w-7 shrink-0 text-accent" /> ملتقى الشعراء</h1><Button asChild variant="outline"><Link to="/explore">Explore translation projects</Link></Button></div>
    <Tabs defaultValue="poems"><TabsList><TabsTrigger value="poems">Poems & discussion · القصائد</TabsTrigger><TabsTrigger value="sessions">Poetry sessions · الجلسات</TabsTrigger></TabsList>
      {error && <p role="alert" className="py-4">Could not load the gathering. Please refresh.</p>}
      <TabsContent value="poems" className="mt-6">
        <div className="grid items-start gap-8 lg:grid-cols-[1fr_340px]">
          <section className="min-w-0 space-y-6">{isPending && <p role="status">Loading poems…</p>}{data?.posts.length === 0 && <p className="border-y py-12 text-center text-muted-foreground">No poems shared yet.</p>}
            {data?.posts.map((p) => <article key={p.id} className="min-w-0 rounded-lg border bg-card p-5">
              <div className="flex items-start justify-between gap-3"><div><h2 className="break-words text-2xl font-semibold" dir="auto">{p.title}</h2><p className="mt-1 text-xs text-muted-foreground">{p.profiles?.display_name || "Poet"} · {p.language} · {new Date(p.created_at).toLocaleDateString()}</p></div>{p.author_id === user.id && <Button variant="ghost" size="icon" aria-label="Delete poem" title="Delete poem" onClick={() => remove("poetry_posts", p.id)}><Trash2 className="h-4 w-4" /></Button>}</div>
              <div className="my-6 whitespace-pre-wrap break-words font-display text-lg leading-loose" dir="auto">{p.content}</div>
              <div className="space-y-3 border-t pt-4">{data.comments.filter((c) => c.post_id === p.id).map((c) => <div key={c.id} className="flex items-start gap-3"><div className="min-w-0 flex-1"><p className="text-xs text-muted-foreground">{c.profiles?.display_name || "Member"}</p><p className="whitespace-pre-wrap break-words text-sm" dir="auto">{c.content}</p></div>{c.author_id === user.id && <Button variant="ghost" size="icon" aria-label="Delete comment" title="Delete comment" onClick={() => remove("poetry_comments", c.id)}><Trash2 className="h-4 w-4" /></Button>}</div>)}
                <form onSubmit={(e) => reply(p.id, e)} className="flex gap-2"><Input aria-label={`Comment on ${p.title}`} placeholder="Discuss this poem…" value={comment[p.id] ?? ""} onChange={(e) => setComment({ ...comment, [p.id]: e.target.value })} dir="auto" required /><Button type="submit" variant="outline" size="icon" aria-label="Send comment" title="Send comment"><Send className="h-4 w-4" /></Button></form>
              </div>
            </article>)}
          </section>
          <form onSubmit={share} className="space-y-4 border-t pt-4 lg:border-t-0 lg:pt-0"><h2 className="text-xl font-semibold">Share a poem · انشر قصيدة</h2><div><Label htmlFor="poem-title">Title</Label><Input id="poem-title" required value={poem.title} onChange={(e) => setPoem({ ...poem, title: e.target.value })} /></div><div><Label>Language</Label><Select value={poem.language} onValueChange={(language) => setPoem({ ...poem, language })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{LANGUAGES.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent></Select></div><div><Label htmlFor="poem-content">Poem</Label><Textarea id="poem-content" rows={10} required dir="auto" value={poem.content} onChange={(e) => setPoem({ ...poem, content: e.target.value })} /></div><div className="flex items-start gap-2"><Checkbox id="poem-rights" checked={poem.rights} onCheckedChange={(rights) => setPoem({ ...poem, rights: rights === true })} /><Label htmlFor="poem-rights" className="text-sm leading-relaxed">I wrote this poem or have permission to share it here. Sharing is not permission to translate or publish elsewhere.</Label></div><Button type="submit" disabled={busy || !poem.rights}>Share poem</Button></form>
        </div>
      </TabsContent>
      <TabsContent value="sessions" className="mt-6"><div className="grid items-start gap-8 lg:grid-cols-[1fr_340px]">
        <section className="space-y-4">{isPending && <p role="status">Loading sessions…</p>}{data?.sessions.length === 0 && <p className="border-y py-12 text-center text-muted-foreground">No upcoming poetry sessions.</p>}{data?.sessions.map((s) => <article key={s.id} className="rounded-lg border bg-card p-5"><div className="flex justify-between gap-3"><h2 className="break-words text-xl font-semibold" dir="auto">{s.title}</h2>{s.host_id === user.id && <Button variant="ghost" size="icon" aria-label="Cancel session" title="Cancel session" onClick={() => remove("poetry_sessions", s.id)}><Trash2 className="h-4 w-4" /></Button>}</div><p className="mt-2 flex items-center gap-2 text-sm"><CalendarDays className="h-4 w-4" />{new Date(s.starts_at).toLocaleString()}</p><p className="mt-1 text-xs text-muted-foreground">Host: {s.profiles?.display_name || "Member"}</p><p className="mt-3 whitespace-pre-wrap break-words" dir="auto">{s.description}</p><Button asChild className="mt-4" variant="outline"><a href={s.meeting_url} target="_blank" rel="noreferrer">Join poetry session</a></Button></article>)}</section>
        <form onSubmit={schedule} className="space-y-4"><h2 className="text-xl font-semibold">Host a reading · نظّم جلسة</h2><div><Label htmlFor="session-title">Title</Label><Input id="session-title" required value={session.title} onChange={(e) => setSession({ ...session, title: e.target.value })} /></div><div><Label htmlFor="session-description">Description</Label><Textarea id="session-description" value={session.description} onChange={(e) => setSession({ ...session, description: e.target.value })} /></div><div><Label htmlFor="session-starts">Date & time (your local time)</Label><Input id="session-starts" type="datetime-local" required value={session.starts} onChange={(e) => setSession({ ...session, starts: e.target.value })} /></div><div><Label htmlFor="session-url">Meeting link</Label><Input id="session-url" type="url" placeholder="https://" required value={session.url} onChange={(e) => setSession({ ...session, url: e.target.value })} /></div><Button type="submit" disabled={busy}>Schedule session</Button></form>
      </div></TabsContent>
    </Tabs>
  </div>;
}