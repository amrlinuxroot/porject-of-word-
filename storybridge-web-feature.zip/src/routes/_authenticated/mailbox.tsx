import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { assembleBook, checkCompleteness } from "@/lib/mailbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { HumanReview } from "@/components/HumanReview";

export const Route = createFileRoute("/_authenticated/mailbox")({
  head: () => ({ meta: [{ title: "Mailbox — Project of Word" }, { name: "description", content: "Send translated pages with book and page number." }, { property: "og:title", content: "Mailbox — Project of Word" }, { property: "og:description", content: "Send translated pages with book and page number." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Mailbox,
});

function Mailbox() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [f, setF] = useState({ project: "", page: "", content: "", note: "" });
  const [reviewed,setReviewed]=useState(false); const [ethics,setEthics]=useState(false);
  const { data: isAdmin = false } = useQuery({
    queryKey: ["is-admin", user.id],
    queryFn: async () => (await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" })).data ?? false,
  });
  const { data: mail = [] } = useQuery({
    queryKey: ["mailbox"],
    queryFn: async () => (await supabase.from("mailbox").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: projects = [] } = useQuery({
    queryKey: ["project-page-counts"],
    queryFn: async () => (await supabase.from("projects").select("project_number, title, pages(count)")).data ?? [],
  });

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const page = parseInt(f.page, 10);
    if (!f.project.trim() || !page || page < 1 || !f.content.trim()) return void toast.error("Book number, page number and translation are required");
    if (!reviewed || !ethics) return void toast.error('أكد المراجعة البشرية وأخلاقيات الترجمة');
    const { error } = await supabase.from("mailbox").insert({ sender_id: user.id, project_number: f.project.trim().toUpperCase(), page_number: page, content: f.content, note: f.note, human_reviewed: reviewed, ethics_accepted: ethics });
    if (error) return void toast.error(error.message);
    toast.success("Sent"); setF({ project: f.project, page: String(page + 1), content: "", note: "" });
    qc.invalidateQueries({ queryKey: ["mailbox"] });
  }
  async function setStatus(id: string, status: "accepted" | "rejected") {
    const { error } = await supabase.from("mailbox").update({ status }).eq("id", id);
    if (error) toast.error(error.message); else qc.invalidateQueries({ queryKey: ["mailbox"] });
  }
  function download(num: string) {
    const pages = mail.filter((m) => m.project_number === num && m.status === "accepted");
    const blob = new Blob([assembleBook(pages)], { type: "text/plain" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${num}.txt`; a.click();
  }

  const byProject = [...new Set(mail.map((m) => m.project_number))];
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-semibold">Mailbox</h1>
      <p className="text-muted-foreground">Send each translated page with its book number and page number. We check every book arrives complete.</p>
      <form onSubmit={send} className="mt-6 grid gap-3 rounded-lg border bg-card p-5 sm:grid-cols-2">
        <div><Label>Book number</Label><Input placeholder="TR-1001" value={f.project} onChange={(e) => setF({ ...f, project: e.target.value })} /></div>
        <div><Label>Page number</Label><Input type="number" min={1} value={f.page} onChange={(e) => setF({ ...f, page: e.target.value })} /></div>
        <div className="sm:col-span-2"><Label>Translation</Label><Textarea rows={6} value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} /></div>
        <div className="sm:col-span-2"><Label>Note (optional)</Label><Input value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></div>
        <Button type="submit" className="sm:col-span-2">Send page</Button>
        <div className="sm:col-span-2"><HumanReview reviewed={reviewed} ethics={ethics} onReviewed={setReviewed} onEthics={setEthics}/></div>
      </form>

      {isAdmin && byProject.length > 0 && (
        <section className="mt-8">
          <h2 className="text-xl font-semibold">Book completeness</h2>
          <div className="mt-3 space-y-2">
            {byProject.map((num) => {
              const proj = projects.find((p) => p.project_number === num);
              const total = (proj?.pages as unknown as { count: number }[] | undefined)?.[0]?.count ?? 0;
              const accepted = mail.filter((m) => m.project_number === num && m.status === "accepted").map((m) => m.page_number);
              const { missing, complete } = checkCompleteness(total, accepted);
              return (
                <div key={num} className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
                  <div className="flex-1">
                    <div className="font-semibold">{num} {proj ? `· ${proj.title}` : "· unknown book number"}</div>
                    <div className="text-sm text-muted-foreground">
                      {total === 0 ? "No page count known" : complete ? `All ${total} pages accepted` : `${total - missing.length}/${total} accepted · missing: ${missing.slice(0, 20).join(", ")}${missing.length > 20 ? "…" : ""}`}
                    </div>
                  </div>
                  {complete && <Badge>Complete</Badge>}
                  <Button size="sm" variant="outline" disabled={!accepted.length} onClick={() => download(num)}>Assemble book</Button>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <h2 className="mt-8 text-xl font-semibold">{isAdmin ? "All received pages" : "Your sent pages"}</h2>
      <div className="mt-3 space-y-2">
        {mail.length === 0 && <p className="rounded-lg border bg-card p-6 text-center text-muted-foreground">Nothing yet.</p>}
        {mail.map((m) => (
          <div key={m.id} className="rounded-lg border bg-card p-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-sm">{m.project_number} · p.{m.page_number}</span>
              <Badge variant={m.status === "accepted" ? "default" : m.status === "rejected" ? "destructive" : "secondary"}>{m.status}</Badge>
              <span className="ml-auto text-xs text-muted-foreground">{new Date(m.created_at).toLocaleString()}</span>
            </div>
            <p className="mt-2 line-clamp-3 whitespace-pre-wrap text-sm">{m.content}</p>
            {m.note && <p className="mt-1 text-xs text-muted-foreground">Note: {m.note}</p>}
            {isAdmin && m.status === "received" && (
              <div className="mt-2 flex gap-2"><Button size="sm" onClick={() => setStatus(m.id, "accepted")}>Accept</Button><Button size="sm" variant="outline" onClick={() => setStatus(m.id, "rejected")}>Reject</Button></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
