import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Audience } from "@/lib/communication";

export const Route = createFileRoute("/_authenticated/privacy")({
  head: () => ({ meta: [{ title: "Privacy settings — Project of Word" }, { name: "description", content: "Control who can view your contact email and send private chat messages." }, { property: "og:title", content: "Privacy settings — Project of Word" }, { property: "og:description", content: "Choose your email and private chat audiences." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }), component: Privacy,
});
const audiences = [{ id: "everyone", label: "الجميع، بمن فيهم الزوار" }, { id: "members", label: "الأعضاء المسجلون" }, { id: "admins", label: "الإدارة فقط" }, { id: "none", label: "لا أحد" }] as const;
function Privacy() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [emailAudience, setEmailAudience] = useState<Audience>("none");
  const [chatAudience, setChatAudience] = useState<Exclude<Audience, "everyone">>("members");
  const [busy, setBusy] = useState(false);
  const { data, isPending, error } = useQuery({ queryKey: ["member-privacy", user.id], queryFn: async () => {
    const { data, error } = await supabase.from("member_privacy").select("email_audience,chat_audience").eq("user_id", user.id).maybeSingle();
    if (error) throw error;
    if (data) return data;
    return { email_audience: "none", chat_audience: "members" };
  }});
  useEffect(() => {
    if (!data) return;
    const emailValue = audiences.find(a => a.id === data.email_audience)?.id ?? "none";
    setEmailAudience(emailValue);
    setChatAudience(data.chat_audience === "admins" || data.chat_audience === "none" ? data.chat_audience : "members");
  }, [data]);
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const { error } = await supabase.from("member_privacy").upsert({ user_id: user.id, email_audience: emailAudience, chat_audience: chatAudience });
    setBusy(false);
    if (error) return void toast.error(error.message);
    await Promise.all([qc.invalidateQueries({ queryKey: ["member-privacy"] }), qc.invalidateQueries({ queryKey: ["public-contacts"] }), qc.invalidateQueries({ queryKey: ["can-message"] }), qc.invalidateQueries({ queryKey: ["online-members"] })]);
    toast.success("تم حفظ إعدادات الخصوصية");
  }
  return <div className="mx-auto max-w-2xl px-4 py-10" dir="rtl"><h1 className="mb-8 flex items-center gap-3 text-3xl font-semibold"><ShieldCheck className="h-7 w-7 text-primary" /> إعدادات الخصوصية</h1>
    {isPending ? <p role="status">جارٍ التحميل…</p> : error ? <p role="alert">تعذر تحميل إعدادات الخصوصية.</p> : <form onSubmit={save} className="space-y-7">
      <div><Label htmlFor="email-audience">من يمكنه رؤية بريدي في دليل التواصل؟</Label><Select value={emailAudience} onValueChange={v => { const next = audiences.find(a => a.id === v); if (next) setEmailAudience(next.id); }}><SelectTrigger id="email-audience" className="mt-2"><SelectValue /></SelectTrigger><SelectContent>{audiences.map(a => <SelectItem key={a.id} value={a.id}>{a.label}</SelectItem>)}</SelectContent></Select></div>
      <div><Label htmlFor="chat-audience">من يمكنه إرسال رسائل خاصة إليّ؟</Label><Select value={chatAudience} onValueChange={v => { if (v === "members" || v === "admins" || v === "none") setChatAudience(v); }}><SelectTrigger id="chat-audience" className="mt-2"><SelectValue /></SelectTrigger><SelectContent>{audiences.filter(a => a.id !== "everyone").map(a => <SelectItem key={a.id} value={a.id}>{a.label}</SelectItem>)}</SelectContent></Select></div>
      <p className="text-sm text-muted-foreground">البريد المخصص للإشعارات غير ظاهر في الدليل. الرسائل السابقة تبقى لدى طرفي المحادثة.</p>
      <Button type="submit" disabled={busy}>{busy ? "جارٍ الحفظ…" : "حفظ الخصوصية"}</Button>
    </form>}
  </div>;
}