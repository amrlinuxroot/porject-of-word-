import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CONTRIBUTOR_ROLES, FIELDS, LANGUAGES } from "@/lib/text";
import { CertifiedProfile } from "@/components/CertifiedProfile";
import { MemberClassification } from '@/components/MemberClassification';

export const Route = createFileRoute("/_authenticated/survey")({
  head: () => ({ meta: [{ title: "Translator survey — Project of Word" }, { name: "description", content: "Tell us your languages and expertise." }, { property: "og:title", content: "Translator survey — Project of Word" }, { property: "og:description", content: "Tell us your languages and expertise." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Survey,
});

const LEVELS = ["Student / beginner", "Experienced volunteer", "Professional translator", "Subject-matter expert"];

function Chips({ options, value, onChange }: { options: string[]; value: string[]; onChange: (v: string[]) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => {
        const on = value.includes(o);
        return (
          <button type="button" key={o} onClick={() => onChange(on ? value.filter((x) => x !== o) : [...value, o])}
            className={`rounded-full border px-3 py-1 text-sm transition ${on ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-primary"}`}>
            {o}
          </button>
        );
      })}
    </div>
  );
}

function Survey() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [langs, setLangs] = useState<string[]>([]);
  const [fields, setFields] = useState<string[]>([]);
  const [level, setLevel] = useState("");
  const [bio, setBio] = useState("");
  const [role, setRole] = useState("translator");
  const [institution, setInstitution] = useState("");
  const [studyLevel, setStudyLevel] = useState("");
  const [notifyEmail, setNotifyEmail] = useState(user.email ?? "");

  useEffect(() => {
    supabase.from("profiles").select("id,display_name,languages,fields,expertise,bio,contributor_role,institution,study_level").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (!data) return;
      setName(data.display_name); setLangs(data.languages); setFields(data.fields); setLevel(data.expertise); setBio(data.bio);
      setRole(data.contributor_role); setInstitution(data.institution); setStudyLevel(data.study_level);
    });
    supabase.rpc("my_notification_email").then(({ data }) => { if (data) setNotifyEmail(data); });
  }, [user.id]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (langs.length < 2) return void toast.error("Pick at least two languages you can work between.");
    if (!fields.length || !level) return void toast.error("Pick your fields and expertise level.");
    const { error } = await supabase.from("profiles").update({ display_name: name, languages: langs, fields, expertise: level, bio, contributor_role: role, institution, study_level: studyLevel, notify_email: notifyEmail, survey_completed: true }).eq("id", user.id);
    if (error) return void toast.error(error.message);
    toast.success("Profile saved");
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="mx-auto max-w-2xl space-y-8 px-4 py-10"><MemberClassification userId={user.id}/><form onSubmit={save} className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold">Your profile</h1>
        <p className="mt-2 text-muted-foreground">This helps us match you with the right projects.</p>
      </div>
      <div className="space-y-2"><Label>I am a…</Label><Chips options={CONTRIBUTOR_ROLES.map((r) => r.label)} value={[CONTRIBUTOR_ROLES.find((r) => r.id === role)?.label ?? ""]} onChange={(v) => setRole(CONTRIBUTOR_ROLES.find((r) => r.label === v[v.length - 1])?.id ?? role)} /></div>
      {(role === "student" || role === "researcher") && (
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>University / school</Label><Input value={institution} onChange={(e) => setInstitution(e.target.value)} /></div>
          <div><Label>Level & major</Label><Input placeholder="e.g. Bachelor, Medicine" value={studyLevel} onChange={(e) => setStudyLevel(e.target.value)} /></div>
        </div>
      )}
      {(role === "publisher" || role === "writer" || role === "poet") && <div><Label>Publisher / pen name</Label><Input value={institution} onChange={(e) => setInstitution(e.target.value)} /></div>}
      <div><Label>Email for project updates</Label><Input type="email" required value={notifyEmail} onChange={(e) => setNotifyEmail(e.target.value)} /></div>
      <div><Label>Display name</Label><Input value={name} onChange={(e) => setName(e.target.value)} required /></div>
      <div className="space-y-2"><Label>Languages you speak fluently</Label><Chips options={LANGUAGES} value={langs} onChange={setLangs} /></div>
      <div className="space-y-2"><Label>Fields of study</Label><Chips options={FIELDS} value={fields} onChange={setFields} /></div>
      <div className="space-y-2"><Label>Expertise level</Label><Chips options={LEVELS} value={level ? [level] : []} onChange={(v) => setLevel(v[v.length - 1] ?? "")} /></div>
      <div><Label>Short bio</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Background, degrees, past translations…" /></div>
      <Button type="submit" size="lg">Save profile</Button>
      <CertifiedProfile userId={user.id} />
    </form></div>
  );
}
