import { createFileRoute } from '@tanstack/react-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { CertifiedProfile } from '@/components/CertifiedProfile';
import { DOCUMENT_KINDS, STATUS_LABELS } from '@/lib/certified';
import { openCertifiedFile, uploadCertifiedFile } from '@/lib/certified-files';
import { LANGUAGES } from '@/lib/text';
import { HumanReview } from '@/components/HumanReview';
import { CertifiedTeam } from '@/components/CertifiedTeam';
export const Route = createFileRoute('/_authenticated/certified-work')({
  head: () => ({ meta: [{ title: 'طلبات الوثائق المعتمدة — مشروع كلمة' }, { name: 'description', content: 'طلباتك الخاصة وفرص الترجمة المعتمدة وميثاق السرية.' }, { property: 'og:title', content: 'طلبات الوثائق المعتمدة — مشروع كلمة' }, { property: 'og:description', content: 'إرسال الوثائق للإدارة والمشاركة الآمنة في الترجمة.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] }),
  component: CertifiedWork,
});
function CertifiedWork() {
  const { user } = Route.useRouteContext(); const qc = useQueryClient();
  const [kind, setKind] = useState<keyof typeof DOCUMENT_KINDS>('academic');
  const [source, setSource] = useState('Arabic'); const [target, setTarget] = useState('English');
  const [country, setCountry] = useState(''); const [authority, setAuthority] = useState('');
  const [notes, setNotes] = useState(''); const [mode, setMode] = useState('paid');
  const [consent, setConsent] = useState(false); const [file, setFile] = useState<File | null>(null); const [busy, setBusy] = useState(false);
  const [reviewed,setReviewed]=useState(false); const [ethics,setEthics]=useState(false);
  const {data:teamInvites=[]}=useQuery({queryKey:['my-team-invites',user.id],queryFn:async()=>{const r=await supabase.from('certified_team').select('*').eq('user_id',user.id);if(r.error)throw r.error;return r.data;}});
  const { data: requests = [], error: requestError } = useQuery({ queryKey: ['my-certified-requests', user.id], queryFn: async () => { const r = await supabase.from('certified_requests').select('*').order('created_at', { ascending: false }); if (r.error) throw r.error; return r.data; } });
  const { data: opportunities = [], error: opportunityError } = useQuery({ queryKey: ['certified-opportunities', user.id], queryFn: async () => { const r = await supabase.rpc('certified_opportunities'); if (r.error) throw r.error; return r.data; } });
  const { data: applications = [] } = useQuery({ queryKey: ['my-certified-applications', user.id], queryFn: async () => { const r = await supabase.from('certified_applications').select('*').eq('translator_id', user.id); if (r.error) throw r.error; return r.data; } });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); if (!file || !consent || source === target) return void toast.error('أرفق الوثيقة ووافق على مشاركتها مع الإدارة ومترجم معتمد واختر لغتين مختلفتين');
    setBusy(true);
    try { const path = await uploadCertifiedFile(user.id, 'requests', file); const { error } = await supabase.from('certified_requests').insert({ requester_id: user.id, document_kind: kind, source_language: source, target_language: target, country: country.trim(), authority: authority.trim(), notes, work_mode: mode, document_path: path, consent }); if (error) throw error; toast.success('وصل طلبك إلى الإدارة'); qc.invalidateQueries({ queryKey: ['my-certified-requests'] }); }
    catch (e) { toast.error(e instanceof Error ? e.message : 'تعذر إرسال الطلب'); } finally { setBusy(false); }
  }
  return <main dir="rtl" className="mx-auto max-w-4xl space-y-10 px-4 py-10">
    <h1 className="text-3xl font-semibold">الوثائق والترجمة المعتمدة</h1>
    <section><h2 className="mb-5 text-2xl font-semibold">طلب ترجمة وثيقة</h2><form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
      <label>نوع الوثيقة<select className="block w-full rounded-md border bg-background p-2" value={kind} onChange={e => setKind(e.target.value as keyof typeof DOCUMENT_KINDS)}>{Object.entries(DOCUMENT_KINDS).map(([k,v]) => <option value={k} key={k}>{v}</option>)}</select></label>
      <label>نوع الخدمة<select className="block w-full rounded-md border bg-background p-2" value={mode} onChange={e => setMode(e.target.value)}><option value="paid">ترجمة بأجر</option><option value="volunteer">طلب ترجمة تطوعية</option></select></label>
      <label>اللغة الأصلية<select className="block w-full rounded-md border bg-background p-2" value={source} onChange={e => setSource(e.target.value)}>{LANGUAGES.map(l => <option key={l}>{l}</option>)}</select></label>
      <label>اللغة المطلوبة<select className="block w-full rounded-md border bg-background p-2" value={target} onChange={e => setTarget(e.target.value)}>{LANGUAGES.map(l => <option key={l}>{l}</option>)}</select></label>
      <label>بلد تقديم الوثيقة<Input required value={country} onChange={e => setCountry(e.target.value)} /></label>
      <label>الجهة المستقبلة (سفارة / جامعة / غيرها)<Input required value={authority} onChange={e => setAuthority(e.target.value)} /></label>
      <label className="sm:col-span-2">الوثيقة · PDF / JPG / PNG · حتى 20 ميغابايت<Input type="file" required accept=".pdf,.jpg,.jpeg,.png" onChange={e => setFile(e.target.files?.[0] ?? null)} /></label>
      <label className="sm:col-span-2">ملاحظات خاصة للإدارة<Textarea value={notes} onChange={e => setNotes(e.target.value)} /></label>
      <label className="flex items-start gap-2 sm:col-span-2"><input type="checkbox" required checked={consent} onChange={e => setConsent(e.target.checked)} className="mt-1" />لدي تفويض قانوني لتقديم الوثيقة، وأوافق على اطلاع الإدارة والمترجم المعتمد المكلّف عليها لغرض الترجمة فقط.</label>
      <Button disabled={busy} type="submit">{busy ? 'جارٍ الإرسال…' : 'إرسال إلى الإدارة'}</Button>
    </form></section>
    <section className="border-t pt-7"><h2 className="text-2xl font-semibold">طلباتي والأعمال المسندة إليّ</h2>{requestError && <p role="alert">تعذر تحميل الطلبات</p>}{!requests.length && <p className="mt-4 text-muted-foreground">لا توجد طلبات متاحة بعد.</p>}<div className="mt-4 space-y-4">{requests.map(r => <article key={r.id} className="rounded-lg border bg-card p-4">
      <h3 className="font-semibold">{DOCUMENT_KINDS[r.document_kind as keyof typeof DOCUMENT_KINDS]} · {r.source_language} ← {r.target_language}</h3><p className="mt-2 text-sm">{r.authority} · {r.country} · {STATUS_LABELS[r.status]}</p>
      {r.quote_cents !== null && <p className="mt-2">السعر المقترح: {(r.quote_cents / 100).toFixed(2)} {r.currency} · {r.quote_accepted ? 'وافق العميل' : 'بانتظار موافقة العميل'}</p>}
      {r.admin_note && <p className="mt-2">{r.admin_note}</p>}
      <div className="mt-3 flex flex-wrap gap-2"><Button variant="outline" size="sm" onClick={() => openCertifiedFile(r.document_path).catch(e => toast.error(e.message))}>الوثيقة الأصلية</Button>
      {r.requester_id === user.id && r.quote_cents !== null && !r.quote_accepted && ['pending','open'].includes(r.status) && <Button size="sm" onClick={async () => { const { error } = await supabase.rpc('accept_certified_quote', { _request: r.id }); if (error) toast.error(error.message); else { toast.success('سُجلت موافقتك على السعر؛ لم يُخصم أي مبلغ'); qc.invalidateQueries({ queryKey: ['my-certified-requests'] }); } }}>الموافقة على السعر</Button>}
      {r.delivery_path && <Button size="sm" variant="outline" onClick={() => openCertifiedFile(r.delivery_path).catch(e => toast.error(e.message))}>الترجمة النهائية</Button>}</div>
      {r.assigned_to&&<CertifiedTeam requestId={r.id} userId={user.id} leadId={r.assigned_to} quoteCents={r.quote_cents}/>}
      {r.assigned_to === user.id && r.status === 'assigned' && <div className="mt-4 space-y-3"><HumanReview reviewed={reviewed} ethics={ethics} onReviewed={setReviewed} onEthics={setEthics}/><label className="block text-sm">رفع الترجمة للإدارة<Input type="file" disabled={!reviewed||!ethics} accept=".pdf,.jpg,.jpeg,.png" onChange={async e => { const f = e.target.files?.[0]; if (!f || !reviewed || !ethics) return; try { const path = await uploadCertifiedFile(user.id,'deliveries',f); const { error } = await supabase.rpc('submit_reviewed_certified_delivery',{ _request: r.id,_path: path,_human_reviewed:reviewed,_ethics_accepted:ethics }); if (error) throw error; qc.invalidateQueries({ queryKey: ['my-certified-requests'] }); toast.success('أُرسلت الترجمة'); } catch(e) { toast.error(e instanceof Error ? e.message : 'تعذر الرفع'); } }} /></label></div>}
    </article>)}</div></section>
    <section className="border-t pt-7"><h2 className="text-2xl font-semibold">فرص المعتمدين ودعوات المساعدة</h2>{opportunityError&&<p role="alert">تعذر تحميل الفرص</p>}<div className="mt-4 space-y-3">{opportunities.map(o=>{const invite=teamInvites.some(t=>t.request_id===o.id&&t.status==='invited');return <article key={o.id} className="rounded-lg border bg-card p-4"><h3 className="font-semibold">{DOCUMENT_KINDS[o.document_kind as keyof typeof DOCUMENT_KINDS]} · {o.target_language}</h3><p>{o.country} · {o.authority}</p><Button className="mt-3" onClick={async()=>{const {error}=invite?await supabase.rpc('accept_certified_helper',{_request:o.id}):await supabase.rpc('accept_certified_job',{_request:o.id});if(error)toast.error(error.message);else{toast.success(invite?'انضممت إلى فريق الوثيقة':'قُبل العمل وأُسند إليك أولًا');qc.invalidateQueries({queryKey:['my-certified-requests']});qc.invalidateQueries({queryKey:['certified-opportunities']});qc.invalidateQueries({queryKey:['my-team-invites']});}}}>{invite?'قبول دعوة المساعدة':'قبول العمل — الأولوية لأول قبول مؤهل'}</Button></article>;})}</div>{!opportunities.length&&<p className="mt-4 text-muted-foreground">لا توجد فرص مطابقة بعد التحقق من الهوية والاعتماد.</p>}</section>
    <CertifiedProfile userId={user.id} />
  </main>;
}