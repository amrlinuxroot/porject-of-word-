import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Feather, FolderOpen } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ProjectCards } from "@/components/ProjectCards";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LANGUAGES, FIELDS } from "@/lib/text";

export const Route = createFileRoute("/_authenticated/explore")({
  head: () => ({ meta: [
    { title: "Explore translation projects — Project of Word" },
    { name: "description", content: "Choose poetry, literature, scientific or multimedia translation projects worldwide." },
    { property: "og:title", content: "Explore translation projects — Project of Word" },
    { property: "og:description", content: "Find your next collaborative translation project." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Explore,
});

function Explore() {
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState("all");
  const [language, setLanguage] = useState("all");
  const [field, setField] = useState("all");
  const [status, setStatus] = useState("all");
  const { data: projects = [], isPending, error } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
  const results = projects.filter((p) => (kind === "all" || p.media_type === kind) && (language === "all" || p.target_language === language) && (field === "all" || p.field === field) && (status === "all" || p.status === status) && `${p.title} ${p.author} ${p.project_number} ${p.description}`.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  return <div className="mx-auto max-w-6xl px-4 py-10">
    <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
      <h1 className="text-3xl font-semibold">Explore projects · استكشاف المشاريع</h1>
      <Button asChild variant="outline"><Link to="/technical">Science & code · علم وتقنية</Link></Button>
      <div className="flex flex-wrap gap-2"><Button asChild variant="outline"><Link to="/dashboard"><FolderOpen className="h-4 w-4" /> My projects</Link></Button><Button asChild variant="outline"><Link to="/poets"><Feather className="h-4 w-4" /> Poets’ gathering</Link></Button></div>
    </div>
    <div className="relative mb-4"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input aria-label="Search projects" className="pl-10" placeholder="Title, author or project number…" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
    <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <div><Label>Type</Label><Select value={kind} onValueChange={setKind}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{([["all", "All works"], ["book", "Books / text"], ["poetry", "Poetry / الشعر"], ["film", "Films / multimedia"]] as const).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent></Select></div>
      <div><Label>Target language</Label><Select value={language} onValueChange={setLanguage}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All languages</SelectItem>{LANGUAGES.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent></Select></div>
      <div><Label>Field</Label><Select value={field} onValueChange={setField}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All fields</SelectItem>{FIELDS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent></Select></div>
      <div><Label>Status</Label><Select value={status} onValueChange={setStatus}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{["all", "translating", "voting", "published"].map((l) => <SelectItem key={l} value={l}>{l === "all" ? "All stages" : l}</SelectItem>)}</SelectContent></Select></div>
    </div>
    {isPending ? <p role="status">Loading projects…</p> : error ? <p role="alert">Could not load projects. Please refresh.</p> : <><p className="mb-4 text-sm text-muted-foreground">{results.length} projects</p><ProjectCards projects={results} />{!results.length && <p className="border-y py-12 text-center text-muted-foreground">No matching projects.</p>}</>}
  </div>;
}