import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { DEFAULT_SETTINGS, SETTING_LABELS, useSettings, type SettingKey } from "@/lib/settings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { OnlineMembers } from "@/components/OnlineMembers";
import { CertifiedAdmin } from "@/components/CertifiedAdmin";
import { AdminInbox } from '@/components/AdminInbox';
import { MemberClassificationCounts } from '@/components/MemberClassification';
import { OrganizationVerificationAdmin } from '@/components/OrganizationVerification';
import { MemberDocuments } from '@/components/MemberDocuments';

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — Project of Word" }, { name: "description", content: "Site settings, admin team and book approvals." }, { property: "og:title", content: "Admin — Project of Word" }, { property: "og:description", content: "Site settings, admin team and book approvals." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Admin,
});

function Admin() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const settings = useSettings();
  const [form, setForm] = useState(settings);
  const [email, setEmail] = useState("");
  useEffect(() => setForm(settings), [JSON.stringify(settings)]); // eslint-disable-line react-hooks/exhaustive-deps

  const { data: isAdmin, isLoading } = useQuery({
    queryKey: ["is-admin", user.id],
    queryFn: async () => (await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" })).data ?? false,
  });
  const { data: admins = [] } = useQuery({ queryKey: ["admins"], enabled: !!isAdmin, queryFn: async () => (await supabase.rpc("list_admins")).data ?? [] });
  const { data: pending = [] } = useQuery({
    queryKey: ["pending-books"], enabled: !!isAdmin,
    queryFn: async () => (await supabase.from("donated_books").select("id, title, author, language, translator_name, description, ai_contribution_percent").eq("status", "pending").order("created_at")).data ?? [],
  });

  const { data: suggestions = [] } = useQuery({
    queryKey: ["suggestions"], enabled: !!isAdmin,
    queryFn: async () => (await supabase.from("book_suggestions").select("*").eq("status", "pending").order("created_at")).data ?? [],
  });

  if (isLoading) return <p className="p-10 text-center text-muted-foreground">Loading…</p>;
  if (!isAdmin) return <p className="p-10 text-center text-muted-foreground">Admins only.</p>;

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    const rows = (Object.keys(DEFAULT_SETTINGS) as SettingKey[]).map((key) => ({ key, value: form[key].trim(), updated_at: new Date().toISOString() }));
    const { error } = await supabase.from("site_settings").upsert(rows);
    if (error) return void toast.error(error.message);
    toast.success("Saved"); qc.invalidateQueries({ queryKey: ["site-settings"] });
  }
  async function setAdmin(target: string, make: boolean) {
    const { error } = await supabase.rpc("set_admin_by_email", { _email: target, _make_admin: make });
    if (error) return void toast.error(error.message);
    toast.success(make ? "Admin added" : "Admin removed"); setEmail(""); qc.invalidateQueries({ queryKey: ["admins"] });
  }
  async function review(id: string, status: "approved" | "rejected") {
    const { error } = await supabase.from("donated_books").update({ status }).eq("id", id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["pending-books"] });
  }

  async function reviewSuggestion(id: string, status: "approved" | "rejected") {
    const { error } = await supabase.from("book_suggestions").update({ status }).eq("id", id);
    if (error) return void toast.error(error.message);
    toast.success(status === "approved" ? "Approved — create the project from Submit a text" : "Rejected");
    qc.invalidateQueries({ queryKey: ["suggestions"] });
  }

  return (
    <div className="mx-auto max-w-4xl space-y-10 px-4 py-10">
      <h1 className="text-3xl font-semibold">Admin control panel</h1>
      <nav className="flex flex-wrap gap-2" aria-label="Admin controls">
        <Button asChild variant="outline"><a href="#admin-team">Manage administrators</a></Button>
        <Button asChild variant="outline"><a href="#member-documents">Member documents</a></Button>
        <Button asChild variant="outline"><Link to="/inbox">Your inbox</Link></Button>
        <Button asChild variant="outline"><Link to="/tasks">Task manager</Link></Button>
      </nav>
      <section id="admin-team" className="scroll-mt-20 border-y py-6">
        <h2 className="text-xl font-semibold">Admin team</h2>
        <form onSubmit={(e)=>{e.preventDefault();if(email.trim())setAdmin(email.trim(),true);}} className="mt-4 flex flex-wrap gap-2">
          <Input aria-label="Member email to promote" type="email" required placeholder="Email of a registered member" value={email} onChange={e=>setEmail(e.target.value)} className="min-w-0 flex-1"/>
          <Button type="submit">Add admin</Button>
        </form>
        <ul className="mt-4 divide-y">{admins.map(a=><li key={a.user_id} className="flex flex-wrap items-center gap-3 py-3"><span className="min-w-0 flex-1 break-words">{a.display_name||'Administrator'} <span className="break-all text-sm text-muted-foreground">{a.email}</span></span>{a.user_id!==user.id&&<Button size="sm" variant="outline" onClick={()=>{if(window.confirm('Remove administrator access?'))setAdmin(a.email,false);}}>Remove admin</Button>}</li>)}</ul>
      </section>
      <div id="member-documents" className="scroll-mt-20"><MemberDocuments userId={user.id} admin/></div>
      <OnlineMembers userId={user.id} />
      <CertifiedAdmin userId={user.id} />
      <AdminInbox />
      <MemberClassificationCounts />
      <OrganizationVerificationAdmin userId={user.id} />

      <section>
        <h2 className="text-xl font-semibold">Suggested works — check the rights</h2>
        <div className="mt-3 space-y-3">
          {suggestions.length === 0 && <p className="rounded-lg border bg-card p-6 text-center text-muted-foreground">No suggestions waiting.</p>}
          {suggestions.map((s) => (
            <div key={s.id} className="rounded-lg border bg-card p-4 text-sm">
              <div className="font-semibold">{s.title} <span className="font-normal text-muted-foreground">· {s.kind} · {s.author} · {s.original_language} → {s.target_languages}</span></div>
              {s.description && <p className="mt-1">{s.description}</p>}
              <p className="mt-2">AI contribution (submitter disclosure): {s.ai_contribution_percent ?? 'Not declared'}%</p>
              <dl className="mt-2 grid gap-1 sm:grid-cols-2">
                <div><dt className="inline text-muted-foreground">Copyright: </dt><dd className="inline">{s.has_copyright}</dd></div>
                <div><dt className="inline text-muted-foreground">Permission: </dt><dd className="inline">{s.permission}</dd></div>
                <div><dt className="inline text-muted-foreground">Rights holder: </dt><dd className="inline">{s.rights_holder_name || "—"} {s.rights_holder_email}</dd></div>
                <div><dt className="inline text-muted-foreground">Author wants royalty: </dt><dd className="inline">{s.author_wants_royalty ? "Yes" : "No"}</dd></div>
                <div><dt className="inline text-muted-foreground">From: </dt><dd className="inline">{s.submitter_name} ({s.submitter_role}) <a className="text-primary" href={`mailto:${s.submitter_email}`}>{s.submitter_email}</a></dd></div>
              </dl>
              {s.proof_note && <p className="mt-2 italic">“{s.proof_note}”</p>}
              <div className="mt-3 flex flex-wrap gap-2">
                {s.proof_link && <Button size="sm" variant="outline" asChild><a href={s.proof_link} target="_blank" rel="noreferrer">Open proof</a></Button>}
                {s.source_link && <Button size="sm" variant="outline" asChild><a href={s.source_link} target="_blank" rel="noreferrer">Open file</a></Button>}
                {s.source_text && <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(s.source_text); toast.success("Text copied"); }}>Copy attached text</Button>}
                <Button size="sm" onClick={() => reviewSuggestion(s.id, "approved")}>Approve</Button>
                <Button size="sm" variant="outline" onClick={() => reviewSuggestion(s.id, "rejected")}>Reject</Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold">Contact, links & book storage</h2>
        <form onSubmit={saveSettings} className="mt-3 grid gap-3 rounded-lg border bg-card p-5 sm:grid-cols-2">
          {(Object.keys(DEFAULT_SETTINGS) as SettingKey[]).map((k) => (
            <div key={k}><Label>{SETTING_LABELS[k]}</Label><Input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} /></div>
          ))}
          <Button type="submit" className="sm:col-span-2">Save</Button>
        </form>
      </section>

      <section>
        <h2 className="text-xl font-semibold">Donated books waiting for approval</h2>
        <div className="mt-3 space-y-2">
          {pending.length === 0 && <p className="rounded-lg border bg-card p-6 text-center text-muted-foreground">Nothing waiting.</p>}
          {pending.map((b) => (
            <div key={b.id} className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
              <div className="flex-1"><div className="font-semibold">{b.title}</div><div className="text-sm text-muted-foreground">{b.author} · {b.language} · translated by {b.translator_name || "—"} · AI: {b.ai_contribution_percent ?? 'Not declared'}%</div></div>
              <Button size="sm" variant="outline" asChild><a href={`/free-library/${b.id}`} target="_blank" rel="noreferrer">Read</a></Button>
              <Button size="sm" onClick={() => review(b.id, "approved")}>Approve</Button>
              <Button size="sm" variant="outline" onClick={() => review(b.id, "rejected")}>Reject</Button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
