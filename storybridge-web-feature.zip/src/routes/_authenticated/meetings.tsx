import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Video } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/meetings")({
  head: () => ({ meta: [{ title: "Meetings — Project of Word" }, { name: "description", content: "Google Meet appointments with translators." }, { property: "og:title", content: "Meetings — Project of Word" }, { property: "og:description", content: "Google Meet appointments with translators." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Meetings,
});

const ORGANIZER = "amrlinuxroot@gmail.com";

function calendarUrl(topic: string, start: Date, link: string | null) {
  const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const end = new Date(start.getTime() + 60 * 60 * 1000);
  const p = new URLSearchParams({ action: "TEMPLATE", text: topic, dates: `${fmt(start)}/${fmt(end)}`, details: link ? `Google Meet: ${link}` : "", add: ORGANIZER });
  return `https://calendar.google.com/calendar/render?${p}`;
}

function Meetings() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [form, setForm] = useState({ translator: "", topic: "", when: "", link: "" });
  const { data: isAdmin = false } = useQuery({
    queryKey: ["is-admin", user.id],
    queryFn: async () => (await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" })).data ?? false,
  });
  const { data: translators = [] } = useQuery({
    queryKey: ["translators"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("profiles").select("id, display_name").order("display_name")).data ?? [],
  });
  const { data: meetings = [] } = useQuery({
    queryKey: ["meetings"],
    queryFn: async () => {
      const { data } = await supabase.from("meetings").select("*").order("starts_at");
      const ids = [...new Set((data ?? []).map((m) => m.translator_id))];
      const { data: profs } = ids.length ? await supabase.from("profiles").select("id, display_name").in("id", ids) : { data: [] };
      const names = Object.fromEntries((profs ?? []).map((p) => [p.id, p.display_name || "Translator"]));
      return (data ?? []).map((m) => ({ ...m, name: names[m.translator_id] ?? "Translator" }));
    },
  });

  async function create(e: React.FormEvent) {
    e.preventDefault();
    if (!form.translator || !form.topic || !form.when) return void toast.error("Fill translator, topic and time");
    const { error } = await supabase.from("meetings").insert({
      translator_id: form.translator, created_by: user.id, topic: form.topic,
      starts_at: new Date(form.when).toISOString(), meet_link: form.link || null,
    });
    if (error) return void toast.error(error.message);
    toast.success("Meeting scheduled — translator notified");
    setForm({ translator: "", topic: "", when: "", link: "" });
    qc.invalidateQueries({ queryKey: ["meetings"] });
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-semibold">Meetings</h1>
      <p className="text-muted-foreground">Video appointments over Google Meet.</p>

      {isAdmin && (
        <form onSubmit={create} className="mt-6 grid gap-3 rounded-lg border bg-card p-5 sm:grid-cols-2">
          <div><Label>Translator</Label>
            <select className="h-10 w-full rounded-md border bg-background px-3" value={form.translator} onChange={(e) => setForm({ ...form, translator: e.target.value })}>
              <option value="">Choose…</option>
              {translators.filter((t) => t.id !== user.id).map((t) => <option key={t.id} value={t.id}>{t.display_name || "Translator"}</option>)}
            </select>
          </div>
          <div><Label>Topic</Label><Input value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} /></div>
          <div><Label>Date & time</Label><Input type="datetime-local" value={form.when} onChange={(e) => setForm({ ...form, when: e.target.value })} /></div>
          <div><Label>Google Meet link</Label>
            <div className="flex gap-2">
              <Input placeholder="https://meet.google.com/…" value={form.link} onChange={(e) => setForm({ ...form, link: e.target.value })} />
              <Button type="button" variant="outline" asChild><a href="https://meet.google.com/new" target="_blank" rel="noreferrer">New</a></Button>
            </div>
          </div>
          <Button type="submit" className="sm:col-span-2">Schedule meeting</Button>
        </form>
      )}

      <div className="mt-6 space-y-3">
        {meetings.length === 0 && <p className="rounded-lg border bg-card p-6 text-center text-muted-foreground">No meetings scheduled.</p>}
        {meetings.map((m) => (
          <div key={m.id} className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
            <div className="flex-1">
              <div className="font-semibold">{m.topic}</div>
              <div className="text-sm text-muted-foreground">{new Date(m.starts_at).toLocaleString()} · {m.name}</div>
            </div>
            {m.meet_link && <Button size="sm" asChild><a href={m.meet_link} target="_blank" rel="noreferrer"><Video className="h-4 w-4" /> Join</a></Button>}
            <Button size="sm" variant="outline" asChild><a href={calendarUrl(m.topic, new Date(m.starts_at), m.meet_link)} target="_blank" rel="noreferrer">Add to calendar</a></Button>
          </div>
        ))}
      </div>
    </div>
  );
}
