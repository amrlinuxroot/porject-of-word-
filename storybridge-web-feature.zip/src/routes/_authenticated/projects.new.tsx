import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FIELDS, LANGUAGES, parseSegments, splitIntoPages } from "@/lib/text";
import { splitPoems } from "@/lib/projects";
import { useSettings } from "@/lib/settings";
import { aiContributionPercent } from "@/lib/ai-disclosure";

export const Route = createFileRoute("/_authenticated/projects/new")({
  head: () => ({ meta: [{ title: "Submit a text — Project of Word" }, { name: "description", content: "Submit a text for translation." }, { property: "og:title", content: "Submit a text — Project of Word" }, { property: "og:description", content: "Submit a text for translation." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: NewProject,
});

function Pick({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div><Label>{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger><SelectValue placeholder="Choose…" /></SelectTrigger>
        <SelectContent>{options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
      </Select>
    </div>
  );
}

function NewProject() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const [f, setF] = useState({ title: "", author: "", description: "", field: "Literary", source_language: "", target_language: "", media_type: "book", video_url: "", source_link: "", author_royalty_percent: 0 });
  const settings = useSettings();
  const [text, setText] = useState("");
  const [aiPercent, setAiPercent] = useState("");
  const [busy, setBusy] = useState(false);
  const isFilm = f.media_type === "film";
  const segments = isFilm ? parseSegments(text) : [];
  const pages = isFilm ? segments.map((s) => s.text) : f.media_type === "poetry" ? splitPoems(text) : splitIntoPages(text);

  async function onFile(file: File) {
    setText(await file.text());
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!f.source_language || !f.target_language) return void toast.error("Choose both languages.");
    if (!pages.length) return void toast.error("Add the text to translate.");
    let percent: number | null = null;
    if (f.media_type === 'book') { try { percent = aiContributionPercent(aiPercent); } catch(e) { return void toast.error(e instanceof Error ? e.message : 'أدخل نسبة الذكاء الاصطناعي'); } }
    setBusy(true);
    const { data: proj, error } = await supabase.from("projects").insert({ ...f, ai_contribution_percent: percent, created_by: user.id }).select().single();
    if (error || !proj) { setBusy(false); return void toast.error(error?.message ?? "Failed"); }
    const { error: e2 } = await supabase.from("pages").insert(pages.map((t, i) => ({ project_id: proj.id, page_number: i + 1, original_text: t, start_time: segments[i]?.start ?? "", end_time: segments[i]?.end ?? "" })));
    setBusy(false);
    if (e2) return void toast.error(e2.message);
    toast.success(`Project ${proj.project_number} created`);
    navigate({ to: "/projects/$projectId", params: { projectId: proj.id } });
  }

  return (
    <form onSubmit={submit} className="mx-auto max-w-3xl space-y-5 px-4 py-10">
      <h1 className="text-3xl font-semibold">Submit a text</h1>
      <div className="flex flex-wrap gap-2">
        {([["book", "Book / text"], ["film", "Film / multimedia"], ["poetry", "Poetry / الشعر"]] as const).map(([id, label]) => (
          <Button key={id} type="button" variant={f.media_type === id ? "default" : "outline"} onClick={() => setF({ ...f, media_type: id, field: id === "poetry" ? "Poetry" : f.field })}>{label}</Button>
        ))}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><Label>Title</Label><Input required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
        <div><Label>Original author</Label><Input value={f.author} onChange={(e) => setF({ ...f, author: e.target.value })} /></div>
        <Pick label="From" value={f.source_language} onChange={(v) => setF({ ...f, source_language: v })} options={LANGUAGES} />
        <Pick label="Into" value={f.target_language} onChange={(v) => setF({ ...f, target_language: v })} options={LANGUAGES} />
        <Pick label="Field" value={f.field} onChange={(v) => setF({ ...f, field: v })} options={FIELDS} />
      </div>
      {isFilm && <div><Label>Video link (YouTube, Vimeo, Drive…)</Label><Input type="url" value={f.video_url} onChange={(e) => setF({ ...f, video_url: e.target.value })} /></div>}
      <div>
        <Label>Link to the full file on external storage</Label>
        <Input type="url" placeholder="https://" value={f.source_link} onChange={(e) => setF({ ...f, source_link: e.target.value })} />
        <p className="mt-1 text-xs text-muted-foreground">{settings.storage_note} {settings.storage_url && <a className="text-primary" href={settings.storage_url} target="_blank" rel="noreferrer">Open our {settings.storage_provider} folder</a>}</p>
      </div>
      <div><Label>Author royalty % (if the author asked for a share)</Label><Input type="number" min={0} max={50} value={f.author_royalty_percent} onChange={(e) => setF({ ...f, author_royalty_percent: Math.min(50, Math.max(0, Number(e.target.value))) })} /></div>
      <div><Label>Description</Label><Textarea value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
      {f.media_type === 'book' && <div><Label htmlFor="project-ai">نسبة مشاركة الذكاء الاصطناعي في الكتاب (%) — إفصاح مقدم العمل</Label><Input id="project-ai" required type="number" min={0} max={100} step={1} value={aiPercent} onChange={e => setAiPercent(e.target.value)} /></div>}
      <div className="space-y-2">
        <Label>Text</Label>
        <Input type="file" accept=".txt,.md,.srt,.vtt,.tex,.py,.js,.ts,.tsx,.jsx,.java,.c,.cpp,.h,.css,.html,.json,.sql,.rs,.go,.yaml,.yml,text/plain" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
        <Textarea rows={12} value={text} onChange={(e) => setText(e.target.value)} placeholder={isFilm ? "Paste or upload the original subtitles (.srt): 00:00:01,000 --> 00:00:04,000 then the line" : f.media_type === "poetry" ? "Paste poems with their original line breaks. Put --- between poems." : "Paste the text, or upload a .txt file. Put --- on its own line to force a page break."} />
        <p className="text-sm text-muted-foreground">Will be split into <strong>{pages.length}</strong> {isFilm ? "subtitle segment" : f.media_type === "poetry" ? "poem" : "page"}{pages.length === 1 ? "" : "s"}.</p>
      </div>
      <Button type="submit" size="lg" disabled={busy}>Create project</Button>
    </form>
  );
}
