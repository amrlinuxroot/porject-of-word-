import { createFileRoute } from "@tanstack/react-router";
import { MemberDocuments } from "@/components/MemberDocuments";
import { MemberCloudLinks } from "@/components/MemberCloudLinks";
import { documentsQuery } from "@/lib/workspace-queries";
export const Route = createFileRoute("/_authenticated/documents")({
  head: () => ({
    meta: [
      { title: "Documents — Project of Word" },
      {
        name: "description",
        content: "Your private documents and uploads for administrative review.",
      },
      { property: "og:title", content: "Documents — Project of Word" },
      { property: "og:description", content: "Manage private documents in your member workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(documentsQuery(context.user.id)),
  component: Documents,
});
function Documents() {
  const { user } = Route.useRouteContext();
  return (
    <main className="mx-auto max-w-4xl space-y-6 px-4 py-10">
      <h1 className="text-3xl font-semibold">Documents</h1>
      <MemberDocuments userId={user.id} />
      <MemberCloudLinks userId={user.id} />
    </main>
  );
}
