import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { TeamFiles } from "@/components/TeamFiles";

export const Route = createFileRoute("/_authenticated/collaborate/$projectId")({
  head: () => ({
    meta: [
      { title: "مساحة التأليف والتطوير — مشروع كلمة" },
      {
        name: "description",
        content: "أعمال الفريق ومساهماته وملفاته وأسماء المشاركين وقنوات النشر.",
      },
      { property: "og:title", content: "مساحة الفريق — مشروع كلمة" },
      { property: "og:description", content: "تعاون إنساني في التأليف والتطوير ومشاركة الملفات." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Workspace,
});

function Workspace() {
  const { user } = Route.useRouteContext();
  const { projectId } = Route.useParams();
  const qc = useQueryClient();
  const { data, error } = useQuery({
    queryKey: ["collaboration", projectId, user.id],
    queryFn: async () => {
      const [project, members, contributions] = await Promise.all([
        supabase.from("collaboration_projects").select("*").eq("id", projectId).single(),
        supabase.from("collaboration_members").select("*").eq("project_id", projectId),
        supabase
          .from("collaboration_contributions")
          .select("*")
          .eq("project_id", projectId)
          .order("created_at"),
      ]);
      if (project.error || members.error || contributions.error)
        throw project.error ?? members.error ?? contributions.error;
      return { project: project.data, members: members.data, contributions: contributions.data };
    },
  });

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["collaboration", projectId] });
    void qc.invalidateQueries({ queryKey: ["collaborations"] });
  };

  if (error)
    return (
      <p role="alert" className="p-10">
        تعذر تحميل مساحة العمل.
      </p>
    );
  if (!data) return <p className="p-10">جارٍ التحميل…</p>;

  const { project, members, contributions } = data;
  const owner = project.owner_id === user.id;
  const mine = members.find((member) => member.user_id === user.id);
  const accepted = owner || mine?.status === "accepted";

  return (
    <main dir="rtl" className="mx-auto max-w-5xl space-y-7 px-4 py-10">
      <p className="text-accent">
        مشروع كلمة · {project.kind === "book" ? "تأليف جماعي" : "برمجة مشتركة"}
      </p>
      <h1 className="text-3xl font-semibold">{project.title}</h1>
      <p className="whitespace-pre-wrap">{project.description}</p>
      <p>الأدوار المطلوبة: {project.needed_roles}</p>

      <section className="border-t pt-5">
        <h2 className="text-2xl font-semibold">أسماء المشاركين</h2>
        <p className="mt-3">
          {project.kind === "book" ? "المؤلف الأول" : "المنسق"}: {project.lead_author}
        </p>
        <ul>
          {members
            .filter((member) => member.status === "accepted")
            .map((member) => (
              <li key={member.user_id} className="mt-2">
                {member.credit_name} — {member.contribution_role}
              </li>
            ))}
        </ul>
      </section>

      {!owner && !mine && project.status === "recruiting" && (
        <form
          className="grid gap-3 border-t pt-5 sm:grid-cols-2"
          onSubmit={async (event) => {
            event.preventDefault();
            const values = new FormData(event.currentTarget);
            const { error: insertError } = await supabase.from("collaboration_members").insert({
              project_id: projectId,
              user_id: user.id,
              credit_name: String(values.get("name")),
              contribution_role: String(values.get("role")),
            });
            if (insertError) toast.error(insertError.message);
            else {
              toast.success("وصل طلب مشاركتك");
              refresh();
            }
          }}
        >
          <label>
            اسمي في العمل
            <Input name="name" required />
          </label>
          <label>
            دوري المقترح
            <Input name="role" required />
          </label>
          <Button type="submit">أرغب في المشاركة</Button>
        </form>
      )}
      {mine && (
        <p>
          حالة مشاركتي:{" "}
          {mine.status === "applied"
            ? "بانتظار المنسق"
            : mine.status === "accepted"
              ? "مقبول"
              : "غير مقبول"}
        </p>
      )}

      {owner && (
        <section className="space-y-3 border-t pt-5">
          <h2 className="text-xl font-semibold">طلبات الفريق</h2>
          {members
            .filter((member) => member.status === "applied")
            .map((member) => (
              <div key={member.user_id} className="flex flex-wrap items-center gap-3">
                <span>
                  {member.credit_name} · {member.contribution_role}
                </span>
                {(["accepted", "declined"] as const).map((status) => (
                  <Button
                    key={status}
                    size="sm"
                    variant={status === "accepted" ? "default" : "outline"}
                    onClick={async () => {
                      const { error: updateError } = await supabase
                        .from("collaboration_members")
                        .update({ status })
                        .eq("project_id", projectId)
                        .eq("user_id", member.user_id);
                      if (updateError) toast.error(updateError.message);
                      else refresh();
                    }}
                  >
                    {status === "accepted" ? "قبول" : "رفض"}
                  </Button>
                ))}
              </div>
            ))}
        </section>
      )}

      {accepted && (
        <section className="space-y-4 border-t pt-5">
          <h2 className="text-2xl font-semibold">مساهمات الفريق</h2>
          <form
            className="space-y-3"
            onSubmit={async (event) => {
              event.preventDefault();
              const form = event.currentTarget;
              const values = new FormData(form);
              const { error: insertError } = await supabase
                .from("collaboration_contributions")
                .insert({
                  project_id: projectId,
                  user_id: user.id,
                  title: String(values.get("title")),
                  content: String(values.get("content")),
                });
              if (insertError) toast.error(insertError.message);
              else {
                form.reset();
                refresh();
              }
            }}
          >
            <label className="block">
              عنوان المساهمة
              <Input name="title" required />
            </label>
            <label className="block">
              الفصل / البيانات / الشيفرة / الملاحظات
              <Textarea name="content" required rows={7} />
            </label>
            <Button type="submit">إضافة مساهمة</Button>
          </form>
          {contributions.map((contribution) => (
            <article key={contribution.id} className="rounded-lg border bg-card p-4">
              <h3 className="font-semibold">{contribution.title}</h3>
              <p className="text-sm text-muted-foreground">
                {contribution.user_id === project.owner_id
                  ? project.lead_author
                  : members.find((member) => member.user_id === contribution.user_id)?.credit_name}
              </p>
              <pre className="mt-3 whitespace-pre-wrap break-words font-sans text-sm">
                {contribution.content}
              </pre>
            </article>
          ))}
        </section>
      )}

      {accepted && <TeamFiles projectId={projectId} userId={user.id} isOwner={owner} />}

      {owner && (
        <form
          className="space-y-4 border-t pt-5"
          onSubmit={async (event) => {
            event.preventDefault();
            const values = new FormData(event.currentTarget);
            const changes = {
              manuscript: String(values.get("manuscript")),
              status: String(values.get("status")),
              publication_digital: String(values.get("digital")),
              publication_audio: String(values.get("audio")),
              publication_print: String(values.get("print")),
              publication_video: String(values.get("video")),
              repository_url: String(values.get("repo")),
            };
            const { error: updateError } = await supabase
              .from("collaboration_projects")
              .update(changes)
              .eq("id", projectId);
            if (updateError) toast.error(updateError.message);
            else {
              toast.success("حُفظ العمل وقنوات النشر");
              refresh();
            }
          }}
        >
          <h2 className="text-2xl font-semibold">العمل المجمع والنشر باسم مشروع كلمة</h2>
          <label className="block">
            المسودة النهائية
            <Textarea name="manuscript" defaultValue={project.manuscript} rows={10} />
          </label>
          <label className="block">
            حالة المشروع
            <select
              name="status"
              defaultValue={project.status}
              className="block w-full rounded-md border bg-background p-2"
            >
              <option value="recruiting">تكوين فريق</option>
              <option value="working">قيد العمل</option>
              <option value="published">منشور</option>
            </select>
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              ["digital", "رابط النشر الإلكتروني", project.publication_digital],
              ["audio", "رابط الكتاب المسموع", project.publication_audio],
              ["print", "رابط النسخة المطبوعة", project.publication_print],
              ["video", "رابط العمل المرئي", project.publication_video],
              ["repo", "رابط مستودع البرنامج", project.repository_url],
            ].map(([name, label, value]) => (
              <label key={name}>
                {label}
                <Input type="url" name={name} defaultValue={value} />
              </label>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            روابط النشر تُضاف بعد نشر العمل لدى المنصات؛ لا يتم النشر الخارجي تلقائيًا.
          </p>
          <Button type="submit">حفظ المسودة والنشر</Button>
        </form>
      )}

      {project.status === "published" && (
        <section className="border-t pt-5">
          <h2 className="text-2xl font-semibold">العمل المنشور · مشروع كلمة</h2>
          <article className="mt-4 whitespace-pre-wrap">{project.manuscript}</article>
          <div className="mt-4 flex flex-wrap gap-3">
            {[
              ["إلكتروني", project.publication_digital],
              ["مسموع", project.publication_audio],
              ["مطبوع", project.publication_print],
              ["مرئي", project.publication_video],
              ["المستودع", project.repository_url],
            ]
              .filter(([, url]) => url)
              .map(([label, url]) => (
                <Button key={label} asChild variant="outline">
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    {label}
                  </a>
                </Button>
              ))}
          </div>
        </section>
      )}
    </main>
  );
}
