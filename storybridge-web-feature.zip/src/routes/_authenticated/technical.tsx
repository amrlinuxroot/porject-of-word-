import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Code2, FlaskConical, Plus, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { TECHNICAL_FIELDS } from "@/lib/text";
import { ProjectCards } from "@/components/ProjectCards";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/_authenticated/technical")({
  head: () => ({ meta: [{ title: "Science, technology & code — Project of Word" }, { name: "description", content: "Collaborative scientific, technical, computer science, AI and code translation." }, { property: "og:title", content: "Science, technology & code — Project of Word" }, { property: "og:description", content: "Scientific documents, computer languages, AI and code explanation projects." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Technical,
});
const labels: Record<string, string> = { Technical: "تقنية", Scientific: "علمية", "Computer science": "علوم الحاسوب", "Artificial intelligence": "الذكاء الاصطناعي", "Scientific documents": "ملفات علمية", "Programming / code": "أكواد برمجية" };
function Technical() {
  const [field, setField] = useState("all");
  const [search, setSearch] = useState("");
  const { data: projects = [], isPending, error } = useQuery({ queryKey: ["technical-projects"], queryFn: async () => {
    const { data, error } = await supabase.from("projects").select("*").in("field", TECHNICAL_FIELDS).order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  }});
  const results = projects.filter(p => (field === "all" || p.field === field) && `${p.title} ${p.description} ${p.project_number}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="mx-auto max-w-6xl space-y-6 px-4 py-10">
    <div dir="rtl" className="flex flex-wrap items-center justify-between gap-4"><h1 className="flex items-center gap-3 text-3xl font-semibold"><FlaskConical className="h-7 w-7 shrink-0 text-primary" /> الترجمة العلمية والتقنية</h1><Code2 className="h-8 w-8 text-accent" /></div>
    <div className="flex flex-wrap gap-2"><Button asChild><Link to="/projects/new"><Plus className="h-4 w-4" /> مشروع جديد</Link></Button><Button asChild variant="outline"><Link to="/ai-tools"><Sparkles className="h-4 w-4" /> المسرد وشرح الأكواد</Link></Button></div>
    <Tabs value={field} onValueChange={setField}><TabsList className="h-auto flex-wrap justify-start"><TabsTrigger value="all">الكل</TabsTrigger>{TECHNICAL_FIELDS.map(f => <TabsTrigger key={f} value={f}>{labels[f]}</TabsTrigger>)}</TabsList></Tabs>
    <Input aria-label="بحث المشاريع التقنية" placeholder="عنوان المشروع أو رقمه" dir="auto" value={search} onChange={e => setSearch(e.target.value)} />
    {isPending ? <p role="status">جارٍ التحميل…</p> : error ? <p role="alert">تعذر تحميل المشاريع.</p> : <><p className="text-sm text-muted-foreground">{results.length} مشاريع</p><ProjectCards projects={results} />{!results.length && <p className="border-y py-12 text-center text-muted-foreground">لا توجد مشاريع في هذا المجال بعد.</p>}</>}
  </div>;
}