import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/chat")({
  validateSearch: (search: Record<string, unknown>) => ({ member: typeof search['member'] === "string" && /^[0-9a-f-]{36}$/i.test(search['member']) ? search['member'] : undefined }),
  head: () => ({ meta: [{ title: "Team chat — Project of Word" }, { name: "description", content: "Chat with the translation team." }, { property: "og:title", content: "Team chat — Project of Word" }, { property: "og:description", content: "Chat with the translation team." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Chat,
});

function Chat() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const { member } = Route.useSearch();
  const { data: canMessage = false, isPending: checkingPermission } = useQuery({ queryKey: ["can-message", user.id, member], enabled: !!member, refetchInterval: 10000, queryFn: async () => {
    const { data, error } = await supabase.rpc("can_message_member", { _recipient: member ?? "" });
    if (error) throw error;
    return data;
  }});
  const { data: recipient } = useQuery({ queryKey: ["chat-recipient", member], enabled: !!member, queryFn: async () => (await supabase.from("profiles").select("display_name").eq("id", member ?? "").single()).data });
  const { data: conversations = [] } = useQuery({ queryKey: ["direct-conversations", user.id], refetchInterval: 4000, queryFn: async () => {
    const { data, error } = await supabase.from("direct_messages").select("sender_id,recipient_id").order("created_at", { ascending: false }).limit(200);
    if (error) throw error;
    const ids = [...new Set((data ?? []).map(m => m.sender_id === user.id ? m.recipient_id : m.sender_id))];
    if (!ids.length) return [];
    return (await supabase.from("profiles").select("id,display_name").in("id", ids)).data ?? [];
  }});
  const { data: msgs = [] } = useQuery({
    queryKey: ["messages", user.id, member],
    refetchInterval: 4000,
    queryFn: async () => {
      const query = member ? supabase.from("direct_messages").select("*").or(`and(sender_id.eq.${user.id},recipient_id.eq.${member}),and(sender_id.eq.${member},recipient_id.eq.${user.id})`) : supabase.from("messages").select("*");
      const { data, error } = await query.order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      const rows = (data ?? []).reverse();
      const ids = [...new Set(rows.map((m) => m.sender_id))];
      const { data: profs } = ids.length ? await supabase.from("profiles").select("id, display_name").in("id", ids) : { data: [] };
      const names = Object.fromEntries((profs ?? []).map((p) => [p.id, p.display_name || "Translator"]));
      return rows.map((m) => ({ ...m, name: names[m.sender_id] ?? "Translator" }));
    },
  });
  async function send(e: React.FormEvent) {
    e.preventDefault();
    const content = text.trim();
    if (!content) return;
    if (member && !canMessage) return void toast.error("لا تسمح إعدادات العضو باستقبال رسائل منك.");
    const { error } = member ? await supabase.from("direct_messages").insert({ sender_id: user.id, recipient_id: member, content }) : await supabase.from("messages").insert({ sender_id: user.id, content });
    if (error) return void toast.error(error.message);
    setText("");
    qc.invalidateQueries({ queryKey: ["messages"] });
    qc.invalidateQueries({ queryKey: ["direct-conversations"] });
  }
  return (
    <div className="mx-auto flex h-[calc(100vh-3.5rem)] max-w-3xl flex-col px-4 py-6">
      <h1 className="text-3xl font-semibold">{member ? `Private chat · ${recipient?.display_name || "Member"}` : "Team chat"}</h1>
      <Button asChild variant="link" className="self-start"><Link to="/privacy">إعدادات خصوصية الدردشة</Link></Button>
      <nav className="mt-3 flex flex-wrap gap-2"><Button asChild size="sm" variant={!member ? "default" : "outline"}><Link to="/chat" search={{ member: undefined }}>Team chat</Link></Button>{conversations.map(c => <Button asChild key={c.id} size="sm" variant={member === c.id ? "default" : "outline"}><Link to="/chat" search={{ member: c.id }}>{c.display_name}</Link></Button>)}</nav>
      <div className="mt-4 flex-1 space-y-3 overflow-y-auto rounded-lg border bg-card p-4" dir="auto">
        {msgs.length === 0 && <p className="text-center text-muted-foreground">No messages yet. Say hello.</p>}
        {msgs.map((m) => (
          <div key={m.id} className={m.sender_id === user.id ? "ml-auto max-w-[80%] rounded-lg bg-primary p-3 text-primary-foreground" : "max-w-[80%] rounded-lg bg-muted p-3"}>
            <div className="text-xs opacity-75">{m.name} · {new Date(m.created_at).toLocaleString()}</div>
            <div className="whitespace-pre-wrap">{m.content}</div>
          </div>
        ))}
      </div>
      {member && !checkingPermission && !canMessage && <p role="status" className="mt-3 text-sm text-muted-foreground">لا تسمح إعدادات هذا العضو باستقبال رسائل منك.</p>}
      <form onSubmit={send} className="mt-3 flex gap-2">
        <Input value={text} maxLength={2000} onChange={(e) => setText(e.target.value)} placeholder="Write a message…" dir="auto" />
        <Button type="submit" disabled={!!member && (!canMessage || checkingPermission)}>Send</Button>
      </form>
    </div>
  );
}
