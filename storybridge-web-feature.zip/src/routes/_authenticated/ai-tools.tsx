import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Sparkles, Copy } from "lucide-react";
import { aiAssist } from "@/lib/ai.functions";
import { FIELDS, LANGUAGES } from "@/lib/text";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TechnicalKind } from "@/lib/technical";

export const Route = createFileRoute("/_authenticated/ai-tools")({
  head: () => ({ meta: [{ title: "AI helper — Project of Word" }, { name: "description", content: "AI glossary, quality check and first drafts for translators." }, { property: "og:title", content: "AI helper — Project of Word" }, { property: "og:description", content: "AI glossary, quality check and first drafts for translators." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: AiTools,
});

const TOOLS = [
  { id: "glossary", label: "Glossary & context notes" },
  { id: "check", label: "Check my translation" },
  { id: "consistency", label: "Terminology consistency" },
  { id: "draft", label: "First draft" },
  { id: "code", label: "ترجمة تعليقات الكود وشرحه" },
  { id: "explain", label: "شرح نص علمي / تقني" },
  { id: "technical", label: "ترجمة وشرح علمي / تقني / برمجي" },
] as const;

function AiTools() {
  const run = useServerFn(aiAssist);
  const [mode, setMode] = useState<(typeof TOOLS)[number]["id"]>("glossary");
  const [f, setF] = useState({ original: "", translation: "", glossary: "", otherPages: "", field: "Literary", source: "English", target: "Arabic" });
  const [out, setOut] = useState("");
  const [busy, setBusy] = useState(false);
  const [kind, setKind] = useState<TechnicalKind>("scientific");
  const [codeLanguage, setCodeLanguage] = useState("");

  async function go() {
    setBusy(true); setOut("");
    try { setOut((await run({ data: { mode, ...f, kind, codeLanguage } })).text); }
    catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
    finally { setBusy(false); }
  }
  const sel = "h-10 w-full rounded-md border bg-background px-3";
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="flex items-center gap-2 text-3xl font-semibold"><Sparkles className="h-6 w-6 text-accent" /> AI helper</h1>
      <p className="text-muted-foreground">AI suggestions to support — never replace — human translators.</p>
      <div className="mt-6 flex flex-wrap gap-2">
        {TOOLS.map((t) => <Button key={t.id} variant={mode === t.id ? "default" : "outline"} onClick={() => setMode(t.id)}>{t.label}</Button>)}
      </div>
      {mode === "technical" && <div className="mt-5 grid gap-3 sm:grid-cols-2" dir="rtl"><div><Label htmlFor="technical-kind">نوع المحتوى</Label><Select value={kind} onValueChange={v => { if (v === "scientific" || v === "technical" || v === "code") setKind(v); }}><SelectTrigger id="technical-kind"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="scientific">نص علمي</SelectItem><SelectItem value="technical">نص تقني</SelectItem><SelectItem value="code">مقطع برمجي</SelectItem></SelectContent></Select></div>{kind === "code" && <div><Label htmlFor="code-language">لغة البرمجة</Label><Input id="code-language" dir="ltr" value={codeLanguage} maxLength={80} onChange={e => setCodeLanguage(e.target.value)} placeholder="Python, JavaScript…" /></div>}</div>}
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <div><Label>Field</Label><select className={sel} value={f.field} onChange={(e) => setF({ ...f, field: e.target.value })}>{FIELDS.map((x) => <option key={x}>{x}</option>)}</select></div>
        <div><Label>From</Label><select className={sel} value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })}>{LANGUAGES.map((x) => <option key={x}>{x}</option>)}</select></div>
        <div><Label>To</Label><select className={sel} value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })}>{LANGUAGES.map((x) => <option key={x}>{x}</option>)}</select></div>
      </div>
      <Label className="mt-4 block">{mode === "code" || (mode === "technical" && kind === "code") ? "Source code / الكود الأصلي" : "Original text"}</Label>
      <Textarea rows={8} value={f.original} onChange={(e) => setF({ ...f, original: e.target.value })} />
      {mode === "technical" && <><Label className="mt-4 block">المصطلحات المعتمدة (اختياري)</Label><Textarea value={f.glossary} rows={4} onChange={e => setF({ ...f, glossary: e.target.value })} placeholder="neural network = شبكة عصبية" /></>}
      {(mode === "check" || mode === "consistency") && (<><Label className="mt-4 block">Your translated page</Label><Textarea rows={8} value={f.translation} onChange={(e) => setF({ ...f, translation: e.target.value })} /></>)}
      {mode === "consistency" && (<>
        <Label className="mt-4 block">Approved glossary (one term per line, e.g. "cell = خلية")</Label>
        <Textarea rows={6} value={f.glossary} onChange={(e) => setF({ ...f, glossary: e.target.value })} />
        <Label className="mt-4 block">Other translated pages of the book</Label>
        <Textarea rows={8} value={f.otherPages} onChange={(e) => setF({ ...f, otherPages: e.target.value })} />
      </>)}
      <Button className="mt-4" onClick={go} disabled={busy || !f.original.trim()}>{busy ? "Working…" : "Run"}</Button>
      {out && (
        <div className="mt-6 rounded-lg border bg-paper p-5 shadow-page">
          <div className="mb-2 flex justify-end"><Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(out); toast.success("Copied"); }}><Copy className="h-4 w-4" /> Copy</Button></div>
          <Label htmlFor="ai-result">مسودة للمراجعة</Label><Textarea id="ai-result" rows={16} className="mt-2" dir="auto" value={out} onChange={e => setOut(e.target.value)} />
        </div>
      )}
    </div>
  );
}
