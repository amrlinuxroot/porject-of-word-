import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus, MessagesSquare, Compass, Feather } from "lucide-react";
import { useSettings } from "@/lib/settings";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ProjectCards } from "@/components/ProjectCards";
import { personalProjects } from "@/lib/projects";
import { MemberClassification } from '@/components/MemberClassification';

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "My projects — Project of Word" }, { name: "description", content: "Your joined and created translation projects." }, { property: "og:title", content: "My projects — Project of Word" }, { property: "og:description", content: "Your personal translation workspace." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = Route.useRouteContext();
  const { data: profile } = useQuery({
    queryKey: ["profile", user.id],
    queryFn: async () => (await supabase.from("profiles").select("id,display_name,languages,survey_completed").eq("id", user.id).single()).data,
  });
  const settings = useSettings();
  const { data: projects = [], isPending: loading, error: projectError } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: joinedIds = [], isPending: joining, error: membershipError } = useQuery({
    queryKey: ["my-memberships", user.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("project_members").select("project_id").eq("user_id", user.id);
      if (error) throw error;
      return (data ?? []).map((m) => m.project_id);
    },
  });
  const mine = personalProjects(projects, user.id, joinedIds);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <MemberClassification userId={user.id}/>
      <div className="mb-6 flex flex-wrap items-center gap-3 rounded-lg border bg-card p-4">
        <MessagesSquare className="h-5 w-5 text-primary" />
        <p className="flex-1 text-sm">New here? Meet other translators on our Discord server — optional, just if you'd like to talk.</p>
        <Button asChild size="sm" variant="outline"><a href={settings.discord_url} target="_blank" rel="noreferrer">Join Discord</a></Button>
      </div>
      {profile && !profile.survey_completed && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-accent bg-card p-4">
          <p>Complete the translator survey so we can match you to projects.</p>
          <Button asChild size="sm"><Link to="/survey">Take survey</Link></Button>
        </div>
      )}
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold">My projects · أعمالي</h1>
          <p className="text-muted-foreground">{mine.filter((p) => p.status !== "published").length} active · {mine.filter((p) => p.status === "published").length} published</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline"><Link to="/survey">My profile</Link></Button>
          <Button asChild><Link to="/projects/new"><Plus className="h-4 w-4" /> New project</Link></Button>
        </div>
      </div>
      <div className="mb-6 flex flex-wrap gap-2">
        <Button asChild variant="outline"><Link to="/inbox">Your inbox</Link></Button>
        <Button asChild variant="outline"><Link to="/documents">Upload documents</Link></Button>
        <Button asChild variant="outline"><Link to="/tasks">Task manager</Link></Button>
        <Button asChild><Link to="/authoring">شارك معنا في تأليف كتاب</Link></Button>
        <Button asChild variant="outline"><Link to="/programming">قم ببرمجة برنامج معًا</Link></Button>
        <Button asChild variant="outline"><Link to="/certified-work">خدمات الوثائق المعتمدة</Link></Button>
        <Button asChild variant="outline"><Link to="/explore"><Compass className="h-4 w-4" /> Explore projects · استكشاف المشاريع</Link></Button>
        <Button asChild variant="outline"><Link to="/poets"><Feather className="h-4 w-4" /> Poets’ gathering · ملتقى الشعراء</Link></Button>
      </div>
      {(loading || joining) ? <p role="status">Loading your projects…</p> : projectError || membershipError ? <p role="alert">Could not load your projects. Please refresh.</p> : mine.length === 0 ? <div className="border-y py-12 text-center"><h2 className="text-xl font-semibold">No projects joined yet</h2><Button asChild className="mt-4"><Link to="/explore">Choose a project</Link></Button></div> : <ProjectCards projects={mine} languages={profile?.languages ?? []} />}

    </div>
  );
}
