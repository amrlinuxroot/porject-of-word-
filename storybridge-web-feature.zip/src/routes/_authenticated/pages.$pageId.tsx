import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Sparkles, ThumbsUp, Trophy } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { aiAssist } from "@/lib/ai.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { HumanReview } from "@/components/HumanReview";

export const Route = createFileRoute("/_authenticated/pages/$pageId")({
  head: () => ({ meta: [{ title: "Translate page — Project of Word" }, { name: "description", content: "Translate and vote on a page." }, { property: "og:title", content: "Translate page — Project of Word" }, { property: "og:description", content: "Translate and vote on a page." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: PageView,
});

function PageView() {
  const { pageId } = Route.useParams();
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["page", pageId],
    queryFn: async () => {
      const { data: page } = await supabase.from("pages").select("*, projects(id, title, project_number, status, target_language, source_language, field, media_type)").eq("id", pageId).single();
      const { data: trs } = await supabase.from("translations").select("*, profiles(display_name, expertise), votes(voter_id)").eq("page_id", pageId).order("created_at");
      let neighbours = "";
      if (page) {
        const { data: near } = await supabase.from("pages").select("page_number, start_time, original_text").eq("project_id", page.project_id).gte("page_number", page.page_number - 2).lte("page_number", page.page_number + 2).order("page_number");
        neighbours = (near ?? []).filter((n) => n.page_number !== page.page_number).map((n) => `[${n.start_time}] ${n.original_text}`).join("\n");
      }
      return { page, trs: trs ?? [], neighbours };
    },
  });
  const mine = data?.trs.find((t) => t.translator_id === user.id);
  const [draft, setDraft] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [aiUsed, setAiUsed] = useState(false);
  const [reviewed,setReviewed]=useState(false); const [ethics,setEthics]=useState(false);
  const ai = useServerFn(aiAssist);
  useEffect(() => { if (mine) setDraft(mine.content); }, [mine?.id]);
  if (!data?.page) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  const { page, trs } = data;
  const proj = page.projects;
  if (!proj) return <p role="alert" className="p-10">Project not found.</p>;
  const refresh = () => qc.invalidateQueries({ queryKey: ["page", pageId] });

  async function save() {
    if (!draft.trim()) return;
    if (!reviewed || !ethics) return void toast.error('أكد المراجعة البشرية وأخلاقيات الترجمة');
    const { error } = mine
      ? await supabase.from("translations").update({ content: draft, human_reviewed: reviewed, ethics_accepted: ethics }).eq("id", mine.id)
      : await supabase.from("translations").insert({ page_id: pageId, translator_id: user.id, content: draft, human_reviewed: reviewed, ethics_accepted: ethics });
    if (error) toast.error(error.message); else { toast.success("Translation saved"); refresh(); }
  }
  async function aiDraft() {
    setAiBusy(true);
    try {
      const r = await ai({ data: { mode: "subtitle", original: page.original_text, otherPages: data?.neighbours ?? '', field: proj.field, source: proj.source_language, target: proj.target_language } });
      setDraft(r.text.trim()); setAiUsed(true); setReviewed(false); setEthics(false);
      toast.success("AI draft ready — review and edit it before submitting");
    } catch (e) { toast.error(e instanceof Error ? e.message : "AI failed"); }
    finally { setAiBusy(false); }
  }
  async function vote(id: string, voted: boolean) {
    const { error } = voted
      ? await supabase.from("votes").delete().eq("translation_id", id).eq("voter_id", user.id)
      : await supabase.from("votes").insert({ translation_id: id, voter_id: user.id });
    if (error) toast.error(error.message); else refresh();
  }

  const sorted = [...trs].sort((a, b) => b.votes.length - a.votes.length);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <Link to="/projects/$projectId" params={{ projectId: proj.id }} className="inline-flex items-center gap-1 text-sm text-primary"><ArrowLeft className="h-4 w-4" /> {proj.project_number} · {proj.title}</Link>
      <h1 className="mt-2 text-3xl font-semibold">{proj.media_type === "film" ? `Segment ${page.page_number}` : `Page ${page.page_number}`}</h1>
      {proj.media_type === "film" && <p className="font-mono text-sm text-muted-foreground">{page.start_time} → {page.end_time}</p>}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="rounded-lg border bg-paper p-6 shadow-page">
          <h2 className="mb-3 text-xs font-medium uppercase tracking-widest text-muted-foreground">Original</h2>
          <p className="whitespace-pre-wrap font-display text-lg leading-relaxed">{page.original_text}</p>
        </section>
        <section className="space-y-4">
          {proj.status !== "published" && (
            <div className="rounded-lg border bg-card p-4">
              <h2 className="mb-2 text-xs font-medium uppercase tracking-widest text-muted-foreground">Your translation ({proj.target_language})</h2>
              <Textarea aria-label="Your translation" rows={8} value={draft} onChange={(e) => { setDraft(e.target.value); setReviewed(false); }} disabled={mine?.is_selected} />
              <HumanReview reviewed={reviewed} ethics={ethics} onReviewed={setReviewed} onEthics={setEthics}/>
              {aiUsed && <p className="mt-1 text-xs text-accent">AI draft — please check and correct it. Only your reviewed version is submitted for voting.</p>}
              <div className="mt-2 flex flex-wrap gap-2">
                <Button size="sm" onClick={save} disabled={mine?.is_selected || aiBusy}>{mine ? "Update" : "Submit"} translation</Button>
                {proj.media_type === "film" && <Button size="sm" variant="outline" onClick={aiDraft} disabled={aiBusy || mine?.is_selected}><Sparkles className="h-4 w-4" /> {aiBusy ? "Drafting…" : "AI draft"}</Button>}
              </div>
            </div>
          )}
          <h2 className="text-lg font-semibold">Translations ({trs.length})</h2>
          {sorted.map((t) => {
            const voted = t.votes.some((v) => v.voter_id === user.id);
            const own = t.translator_id === user.id;
            return (
              <div key={t.id} className={`rounded-lg border bg-card p-4 ${t.is_selected ? "border-success" : ""}`}>
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="font-medium">{t.profiles?.display_name}{own && " (you)"} <span className="text-muted-foreground">· {t.profiles?.expertise}</span></span>
                  {t.is_selected && <span className="flex items-center gap-1 text-success"><Trophy className="h-4 w-4" /> Selected</span>}
                </div>
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{t.content}</p>
                <Button aria-label={voted ? 'Remove vote' : 'Vote for translation'} size="sm" variant={voted ? "default" : "outline"} className="mt-3" disabled={own} onClick={() => vote(t.id, voted)}>
                  <ThumbsUp className="h-4 w-4" /> {t.votes.length}
                </Button>
              </div>
            );
          })}
        </section>
      </div>
    </div>
  );
}
