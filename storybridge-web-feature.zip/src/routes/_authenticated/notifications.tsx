import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications — Project of Word" }, { name: "description", content: "Your selection notices." }, { property: "og:title", content: "Notifications — Project of Word" }, { property: "og:description", content: "Your selection notices." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Notifications,
});

function Notifications() {
  const qc = useQueryClient();
  const { data = [] } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => (await supabase.from("notifications").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  useEffect(() => {
    if (data.some((n) => !n.read)) {
      supabase.from("notifications").update({ read: true }).eq("read", false).then(() => qc.invalidateQueries({ queryKey: ["unread"] }));
    }
  }, [data, qc]);
  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-3xl font-semibold">Notifications</h1>
      {data.length === 0 && <p className="mt-6 text-muted-foreground">Nothing yet. You'll hear here the moment one of your translations is selected.</p>}
      <ul className="mt-6 space-y-3">
        {data.map((n) => (
          <li key={n.id} className={`rounded-lg border bg-card p-4 ${n.read ? "" : "border-accent"}`}>
            {n.link ? <a href={n.link} className="hover:text-primary">{n.message}</a> : n.message}
            <div className="mt-1 text-xs text-muted-foreground">{new Date(n.created_at).toLocaleString()}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
