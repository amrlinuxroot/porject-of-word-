import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useSettings } from "@/lib/settings";


export const Route = createFileRoute("/donate")({
  head: () => ({
    meta: [
      { title: "Donate — Project of Word" },
      { name: "description", content: "Support volunteer translation. Donations fund operations only." },
      { property: "og:title", content: "Donate — Project of Word" },
      { property: "og:description", content: "Support volunteer translation worldwide." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Donate,
});

function Donate() {
  const [amount, setAmount] = useState(25);
  const IBAN = useSettings().iban.split(" ").join("").trim();
  return (
    <div className="mx-auto max-w-xl px-4 py-14">
      <h1 className="text-4xl font-semibold">Support the work</h1>
      <p className="mt-3 text-muted-foreground">Your gift covers servers, editing and outreach. Translators are paid from book sales; the charity keeps no profit.</p>
      <div className="mt-8 rounded-lg border bg-card p-6 shadow-page">
        <div className="grid grid-cols-4 gap-2">
          {[10, 25, 50, 100].map((a) => (
            <Button key={a} variant={a === amount ? "default" : "outline"} onClick={() => setAmount(a)}>{'$'}{a}</Button>
          ))}
        </div>
        <Button className="mt-5 w-full" size="lg" disabled>{`Donate $${amount} — card payments coming soon`}</Button>
      </div>
      <div className="mt-6 rounded-lg border bg-card p-6" dir="auto">
        <h2 className="text-xl font-semibold">Bank transfer · تحويل بنكي</h2>
        <p className="mt-2 text-sm text-muted-foreground">Send your donation directly to our bank account.</p>
        <div className="mt-4 flex items-center justify-between gap-3 rounded-md bg-muted p-3">
          <code className="font-mono text-sm sm:text-base" dir="ltr">{Array.from({ length: Math.ceil(IBAN.length / 4) }, (_, i) => IBAN.slice(i * 4, i * 4 + 4)).join(" ")}</code>
          <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(IBAN); toast.success("IBAN copied"); }}>Copy</Button>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">IBAN · Reference: "Donation"</p>
      </div>
    </div>
  );
}
