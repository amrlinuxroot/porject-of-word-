import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Mail, Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { useSettings } from "@/lib/settings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/email-directory")({
  head: () => ({ meta: [{ title: "Public email directory — Project of Word" }, { name: "description", content: "Public contact details voluntarily shared by Project of Word members." }, { property: "og:title", content: "Public email directory — Project of Word" }, { property: "og:description", content: "Find the team and members who choose to share their email." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: EmailDirectory,
});
function EmailDirectory() {
  const { user } = useSession();
  const settings = useSettings();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [email, setEmail] = useState("");
  const [description, setDescription] = useState("");
  const [consent, setConsent] = useState(false);
  const [developer,setDeveloper]=useState(false);
  const [busy, setBusy] = useState(false);
  const { data: contacts = [], isPending, error } = useQuery({ queryKey: ["public-contacts", user?.id], refetchInterval: 15000, queryFn: async () => {
    const { data, error } = await supabase.rpc("public_contact_directory");
    if (error) throw error;
    return data ?? [];
  }});
  const { data: own } = useQuery({ queryKey: ["own-contact", user?.id], enabled: !!user, queryFn: async () => (await supabase.from("member_contacts").select("email").eq("user_id", user?.id ?? "").maybeSingle()).data });
  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !consent) return;
    setBusy(true);
    const { error } = await supabase.from("member_contacts").upsert({ user_id: user.id, email: email.trim(), description: description.trim(), developer_opt_in: developer });
    setBusy(false);
    if (error) return void toast.error(error.message);
    toast.success("تم حفظ البريد وفق إعدادات الخصوصية");
    qc.invalidateQueries({ queryKey: ["public-contacts"] });
    qc.invalidateQueries({ queryKey: ["own-contact"] });
  }
  async function remove() {
    if (!user) return;
    const { error } = await supabase.from("member_contacts").delete().eq("user_id", user.id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["public-contacts"] });
    qc.invalidateQueries({ queryKey: ["own-contact"] });
    setConsent(false); toast.success("تم إخفاء البريد");
  }
  const results = contacts.filter(c => `${c.display_name} ${c.description}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="mx-auto max-w-4xl space-y-8 px-4 py-10" dir="rtl">
    <h1 className="text-3xl font-semibold">دليل البريد العام · Public Mail</h1>
    <section className="border-y py-5"><h2 className="mb-3 text-xl font-semibold">إدارة مشروع كلمة</h2><Button asChild variant="outline"><a href={`mailto:${settings.contact_email}`}><Mail className="h-4 w-4" /><span dir="ltr">{settings.contact_email}</span></a></Button></section>
    {user && <form onSubmit={save} className="space-y-3 border-b pb-6"><h2 className="text-xl font-semibold">بريدي في الدليل</h2>
      {own && <p dir="ltr" className="text-sm text-muted-foreground">{own.email}</p>}
      <Label htmlFor="public-email">البريد الذي تريد نشره</Label><Input id="public-email" type="email" required dir="ltr" value={email} onChange={e => setEmail(e.target.value)} />
      <Label htmlFor="contact-description">التخصص / معلومات التواصل</Label><Input id="contact-description" maxLength={300} value={description} onChange={e => setDescription(e.target.value)} />
      <Button asChild variant="outline" size="sm"><Link to="/privacy">تحديد من يرى بريدي ومن يراسلني</Link></Button>
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} /> أوافق على مشاركة هذا البريد وفق إعدادات الخصوصية؛ يمكنني إزالته في أي وقت.</label>
      <label className="flex gap-2 text-sm"><input type="checkbox" checked={developer} onChange={e=>setDeveloper(e.target.checked)}/>أشارك أيضًا في دليل المطورين وفق إعدادات الخصوصية.</label>
      <div className="flex gap-2"><Button type="submit" disabled={!consent || busy}>نشر / تحديث</Button>{own && <Button type="button" variant="outline" onClick={remove}>إزالة بريدي</Button>}</div>
    </form>}
    <section><h2 className="mb-4 text-xl font-semibold">الأعضاء المشاركون في الدليل</h2><div className="mb-4 flex items-center gap-2"><Search className="h-4 w-4 text-muted-foreground" /><Input aria-label="البحث في دليل البريد" value={search} onChange={e => setSearch(e.target.value)} placeholder="اسم العضو أو تخصصه" /></div>
      {isPending ? <p role="status">جارٍ التحميل…</p> : error ? <p role="alert">تعذر تحميل الدليل.</p> : <ul className="divide-y">{results.map(c => <li key={c.user_id} className="flex flex-wrap items-center gap-3 py-4"><div className="min-w-0 flex-1"><h3 className="font-semibold">{c.display_name}</h3><p className="break-words text-sm text-muted-foreground">{c.description}</p><p dir="ltr" className="break-all text-sm">{c.email}</p></div><Button asChild variant="outline" size="sm"><a href={`mailto:${encodeURIComponent(c.email)}`}><Mail className="h-4 w-4" /> بريد</a></Button></li>)}</ul>}
      {!isPending && !error && !results.length && <p className="py-8 text-muted-foreground">لا توجد عناوين مشتركة حتى الآن.</p>}
    </section>
  </div>;
}