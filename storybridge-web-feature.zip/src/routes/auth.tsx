import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { redirect?: string | undefined } => ({
    redirect: safe(s["redirect"]),
  }),
  head: () => ({
    meta: [
      { title: "Sign in — Project of Word" },
      { name: "description", content: "Join Project of Word as a volunteer translator." },
      { property: "og:title", content: "Sign in — Project of Word" },
      { property: "og:description", content: "Join Project of Word as a volunteer translator." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [phone,setPhone]=useState('');const [code,setCode]=useState('');const [phoneSent,setPhoneSent]=useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "up") {
      const { error } = await supabase.auth.signUp({
        email, password,
        options: { emailRedirectTo: window.location.origin, data: { display_name: name } },
      });
      if (error) toast.error(error.message); else setSent(true);
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) toast.error(error.message); else navigate({ to: redirect ?? "/survey" });
    }
    setBusy(false);
  }

  async function social(provider:'google'|'microsoft'|'lovable') {
    if (redirect) sessionStorage.setItem("postAuth", redirect);
    const r = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin });
    if (r.error) return void toast.error(String(r.error.message ?? r.error));
    if (r.redirected) return;
    navigate({ to: redirect ?? "/dashboard" });
  }

  if (sent) return (
    <div className="mx-auto max-w-md px-4 py-20 text-center">
      <h1 className="text-3xl font-semibold">Check your email</h1>
      <p className="mt-3 text-muted-foreground">We sent a confirmation link to {email}. After confirming, you'll fill in a short translator survey.</p>
    </div>
  );

  return (
    <div className="mx-auto max-w-md px-4 py-14">
      <div className="rounded-lg border bg-card p-6 shadow-page">
        <h1 className="text-3xl font-semibold">{mode === "up" ? "Join as a translator" : "Welcome back"}</h1>
        <div className="mt-6 grid gap-2">{(['google','microsoft','lovable'] as const).map(provider=><Button key={provider} variant="outline" onClick={()=>social(provider)}>{provider==='google'?'Continue with Google':provider==='microsoft'?'Continue with Microsoft':'Sign in with Lovable'}</Button>)}</div>
        <div className="my-5 text-center text-xs uppercase tracking-widest text-muted-foreground">or</div>
        <form onSubmit={submit} className="space-y-4">
          {mode === "up" && (<div><Label htmlFor="name">Name</Label><Input id="name" required value={name} onChange={(e) => setName(e.target.value)} /></div>)}
          <div><Label htmlFor="email">Email</Label><Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><Label htmlFor="pw">Password</Label><Input id="pw" type="password" minLength={6} required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <Button type="submit" className="w-full" disabled={busy}>{mode === "up" ? "Create account" : "Sign in"}</Button>
        </form>
        <Button variant="outline" className="mt-3 w-full" disabled={busy || !email} onClick={async()=>{setBusy(true);const {error}=await supabase.auth.signInWithOtp({email,options:{emailRedirectTo:window.location.origin,data:{display_name:name}}});setBusy(false);if(error)toast.error(error.message);else setSent(true);}}>أرسل رابط دخول إلى بريدي</Button>
        <section dir="rtl" className="mt-6 space-y-3 border-t pt-5"><h2 className="text-lg font-semibold">التسجيل برقم الهاتف</h2><label className="block">رقم الهاتف الدولي<Input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+49…" type="tel"/></label>{phoneSent&&<label className="block">رمز التحقق<Input value={code} onChange={e=>setCode(e.target.value)} inputMode="numeric" autoComplete="one-time-code"/></label>}<Button disabled={busy} variant="outline" onClick={async()=>{if(!/^\+[1-9]\d{7,14}$/.test(phone))return void toast.error('أدخل رقمًا دوليًا صحيحًا');setBusy(true);if(phoneSent){const {error}=await supabase.auth.verifyOtp({phone,token:code,type:'sms'});if(error)toast.error(error.message);else navigate({to:'/survey'});}else{const {error}=await supabase.auth.signInWithOtp({phone});if(error)toast.error(error.message);else setPhoneSent(true);}setBusy(false);}}>{phoneSent?'تأكيد الرمز':'إرسال رمز SMS'}</Button><p className="text-xs text-muted-foreground">إرسال SMS يتطلب تفعيل إعدادات الهاتف وخدمة الرسائل؛ لم يُتحقق من الإرسال الفعلي بعد.</p></section>
        <section dir="rtl" className="mt-5 border-t pt-4"><h2 className="text-lg font-semibold">الجامعات والجهات الحكومية</h2><p className="mt-2 text-sm">سجل ببريد الجهة أو Microsoft ثم اختر صفتك وبلدك وموقع الجهة ولغات الترجمة. دخول الجامعة الموحد يحتاج ربط مزود الهوية الخاص بها.</p><p className="mt-3 text-xs text-muted-foreground">تسجيل Facebook وDiscord المباشر غير مدعوم حاليًا؛ يمكنك التسجيل بالبريد أو Google أو Microsoft وإضافة بريد للتواصل.</p></section>
        <button className="mt-4 text-sm text-primary underline" onClick={() => setMode(mode === "up" ? "in" : "up")}>
          {mode === "up" ? "Already have an account? Sign in" : "New here? Create an account"}
        </button>
      </div>
    </div>
  );
}

function safe(v: unknown) {
  return typeof v === "string" && v.startsWith("/") && !v.startsWith("//") ? v : undefined;
}
