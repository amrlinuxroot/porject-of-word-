import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, MessageCircle, Video, MessagesSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSettings, waLink } from "@/lib/settings";
import { useSession } from "@/lib/use-session";
import { AdminMessage } from '@/components/AdminMessage';

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Project of Word" },
      { name: "description", content: "Reach the Project of Word team by email, WhatsApp or Google Meet." },
      { property: "og:title", content: "Contact — Project of Word" },
      { property: "og:description", content: "Reach the team by email, WhatsApp or Google Meet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Contact,
});

function Contact() {
  const s = useSettings();
  const { user } = useSession();
  return (
    <div className="mx-auto max-w-xl px-4 py-14">
      <h1 className="text-4xl font-semibold">Contact us</h1>
      <div className="mt-8 space-y-3">
        <Button asChild variant="outline" className="w-full justify-start" size="lg"><Link to="/email-directory"><Mail className="h-5 w-5" /> Public Mail · دليل البريد العام</Link></Button>
        <Button asChild variant="outline" className="w-full justify-start" size="lg"><a href={`mailto:${s.contact_email}`}><Mail className="h-5 w-5" /> Email</a></Button>
        <Button asChild variant="outline" className="w-full justify-start" size="lg"><a href={waLink(s.whatsapp)} target="_blank" rel="noreferrer"><MessageCircle className="h-5 w-5" /> WhatsApp</a></Button>
        {user && <Button asChild variant="outline" className="w-full justify-start" size="lg"><a href={s.discord_url} target="_blank" rel="noreferrer"><MessagesSquare className="h-5 w-5" /> Join our Discord community (members)</a></Button>}
        <Button asChild variant="outline" className="w-full justify-start" size="lg"><a href={`mailto:${s.meet_email}?subject=Google%20Meet%20appointment`}><Video className="h-5 w-5" /> طلب موعد Google Meet</a></Button>
      </div>
      {user ? <AdminMessage userId={user.id}/> : <Button asChild variant="outline" className="mt-8"><Link to="/auth">سجل الدخول لإرسال رسالة ومرفقات للإدارة</Link></Button>}
    </div>
  );
}
