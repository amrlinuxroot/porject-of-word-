import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { FIELDS, LANGUAGES } from "@/lib/text";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { aiContributionPercent } from "@/lib/ai-disclosure";
import { HumanReview } from "@/components/HumanReview";

export const Route = createFileRoute("/free-library/")({
  head: () => ({
    meta: [
      { title: "Free Library — donated translations | Project of Word" },
      { name: "description", content: "Open library of translations donated for free, in many languages." },
      { property: "og:title", content: "Free Library — Project of Word" },
      { property: "og:description", content: "Read translations donated for free, in many languages." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FreeLibrary,
});

const empty = { title: "", author: "", translator_name: "", language: "Arabic", original_language: "English", field: "Literary", description: "", content: "" };

function FreeLibrary() {
  const { user } = useSession();
  const qc = useQueryClient();
  const [lang, setLang] = useState("All");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState(empty);
  const [aiPercent, setAiPercent] = useState("");
  const [reviewed,setReviewed] = useState(false); const [ethics,setEthics] = useState(false);
  const { data = [], isLoading } = useQuery({
    queryKey: ["free-books"],
    queryFn: async () => (await supabase.from("donated_books").select("id, title, author, translator_name, language, original_language, field, description").eq("status", "approved").order("created_at", { ascending: false })).data ?? [],
  });
  const langs = ["All", ...new Set(data.map((b) => b.language))];
  const shown = lang === "All" ? data : data.filter((b) => b.language === lang);

  async function onFile(file: File) {
    if (!/\.(txt|md)$/i.test(file.name)) return void toast.error("Please upload a .txt file, or paste the text");
    setF((x) => ({ ...x, content: "" })); const text = await file.text(); setF((x) => ({ ...x, content: text }));
  }
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (!f.title.trim() || !f.content.trim()) return void toast.error("Title and text are required");
    if (!reviewed || !ethics) return void toast.error('المراجعة البشرية وأخلاقيات الترجمة إلزاميتان');
    let percent: number;
    try { percent = aiContributionPercent(aiPercent); } catch(e) { return void toast.error(e instanceof Error ? e.message : 'أدخل نسبة الذكاء الاصطناعي'); }
    const { error } = await supabase.from("donated_books").insert({ ...f, ai_contribution_percent: percent, human_reviewed: reviewed, ethics_accepted: ethics, submitted_by: user.id });
    if (error) return void toast.error(error.message);
    toast.success("Thank you! An admin will review it soon."); setF(empty); setAiPercent(""); setOpen(false);
    qc.invalidateQueries({ queryKey: ["free-books"] });
  }
  const sel = "h-10 w-full rounded-md border bg-background px-3";
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="flex flex-wrap items-end gap-4">
        <div className="flex-1">
          <h1 className="text-4xl font-semibold">Free Library</h1>
          <p className="mt-2 text-muted-foreground">Translations donated by their owners, free for everyone, in many languages.</p>
        </div>
        {user ? <Button onClick={() => setOpen(!open)}>Donate a translation</Button> : <Button asChild variant="outline"><Link to="/auth">Sign in to donate a translation</Link></Button>}
      </div>

      {open && user && (
        <form onSubmit={submit} className="mt-6 grid gap-3 rounded-lg border bg-card p-5 sm:grid-cols-2">
          <div><Label>Title</Label><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div><Label>Original author</Label><Input value={f.author} onChange={(e) => setF({ ...f, author: e.target.value })} /></div>
          <div><Label>Translated by</Label><Input value={f.translator_name} onChange={(e) => setF({ ...f, translator_name: e.target.value })} /></div>
          <div><Label htmlFor="donated-ai">نسبة مشاركة الذكاء الاصطناعي (%) — إفصاح المترجم</Label><Input id="donated-ai" type="number" required min={0} max={100} step={1} value={aiPercent} onChange={e => setAiPercent(e.target.value)} /></div>
          <div><Label>Field</Label><select className={sel} value={f.field} onChange={(e) => setF({ ...f, field: e.target.value })}>{FIELDS.map((x) => <option key={x}>{x}</option>)}</select></div>
          <div><Label>Original language</Label><select className={sel} value={f.original_language} onChange={(e) => setF({ ...f, original_language: e.target.value })}>{LANGUAGES.map((x) => <option key={x}>{x}</option>)}</select></div>
          <div><Label>Language of this translation</Label><select className={sel} value={f.language} onChange={(e) => setF({ ...f, language: e.target.value })}>{LANGUAGES.map((x) => <option key={x}>{x}</option>)}</select></div>
          <div className="sm:col-span-2"><Label>Short description</Label><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Full text (paste or upload a .txt file)</Label>
            <Input type="file" accept=".txt,.md" className="mb-2" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
            <Textarea rows={8} value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} />
          </div>
          <p className="text-xs text-muted-foreground sm:col-span-2">By donating you confirm you own the rights to this translation and allow free publication.</p>
          <Button type="submit" className="sm:col-span-2">Submit for review</Button>
          <div className="sm:col-span-2"><HumanReview reviewed={reviewed} ethics={ethics} onReviewed={setReviewed} onEthics={setEthics}/></div>
        </form>
      )}

      <div className="mt-6 flex flex-wrap gap-2">
        {langs.map((l) => <Button key={l} size="sm" variant={l === lang ? "default" : "outline"} onClick={() => setLang(l)}>{l}</Button>)}
      </div>
      {isLoading ? <p className="mt-6 text-muted-foreground">Loading…</p> : shown.length === 0 ? (
        <p className="mt-6 rounded-lg border bg-card p-8 text-center text-muted-foreground">No donated books yet — be the first to share one.</p>
      ) : (
        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((b) => (
            <article key={b.id} className="flex flex-col rounded-lg border bg-paper p-5 shadow-page">
              <span className="text-xs text-muted-foreground">{b.field} · {b.original_language} → {b.language}</span>
              <h2 className="mt-1 text-xl font-semibold">{b.title}</h2>
              <p className="text-sm text-muted-foreground">{b.author}{b.translator_name && ` · translated by ${b.translator_name}`}</p>
              <p className="mt-3 line-clamp-3 flex-1 text-sm">{b.description}</p>
              <Button asChild size="sm" className="mt-4 self-start"><Link to="/free-library/$bookId" params={{ bookId: b.id }}>Read free</Link></Button>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
