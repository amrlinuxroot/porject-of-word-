import { createFileRoute, Link } from '@tanstack/react-router';
import { FileCheck2, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSession } from '@/lib/use-session';
import { useSettings } from '@/lib/settings';
import { DOCUMENT_KINDS } from '@/lib/certified';
export const Route = createFileRoute('/certified')({
  head: () => ({ meta: [{ title: 'الترجمة المعتمدة — مشروع كلمة' }, { name: 'description', content: 'طلب ترجمة الشهادات والوثائق والتقارير الطبية بمراجعة الإدارة واعتماد المترجم وسرية الملفات.' }, { property: 'og:title', content: 'الترجمة المعتمدة — مشروع كلمة' }, { property: 'og:description', content: 'خدمات ترجمة الوثائق بمراجعة الاعتماد وتسعير منصف.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] }),
  component: Certified,
});
function Certified() {
  const { user } = useSession(); const settings = useSettings();
  return <main dir="rtl" className="mx-auto max-w-5xl px-4 py-12">
    <FileCheck2 className="mb-4 size-10 text-accent" />
    <h1 className="text-4xl font-semibold">الترجمة المعتمدة</h1>
    <p className="mt-5 max-w-3xl text-lg leading-loose">الشهادات العلمية والدولية والوثائق والتقارير الطبية؛ تُراجع الإدارة الطلب والاعتماد المطلوب قبل إسناده إلى مترجم مناسب.</p>
    <div className="mt-7 flex flex-wrap gap-3"><Button asChild size="lg"><Link to={user ? '/certified-work' : '/auth'}>{user ? 'إرسال طلب / المشاركة في الترجمة' : 'تسجيل الدخول لإرسال طلب'}</Link></Button>{user && <Button asChild variant="outline"><Link to="/survey">ملفي وشهادات اعتمادي</Link></Button>}</div>
    <section className="mt-12 border-t py-8"><h2 className="text-2xl font-semibold">الوثائق</h2><ul className="mt-5 grid gap-4 sm:grid-cols-2">{Object.values(DOCUMENT_KINDS).map(k => <li key={k} className="flex items-center gap-3"><FileCheck2 className="size-5 shrink-0 text-primary" />{k}</li>)}</ul></section>
    <section className="border-t py-8"><h2 className="flex items-center gap-3 text-2xl font-semibold"><ShieldCheck className="size-6 text-primary" />السرية والاعتماد</h2><p className="mt-4 leading-loose">ملفاتك لا تُعرض في المكتبة العامة أو في دعوات المشاركة. لا يتسلمها المترجم إلا بعد مراجعة اعتماده وتوقيع ميثاق السرية وإسناد الطلب إليه. قبول الوثيقة لدى جهة معينة يخضع لشروط تلك الجهة، وليس مضمونًا تلقائيًا.</p></section>
    <section className="border-t py-8"><h2 className="text-2xl font-semibold">سياسة السعر</h2><p className="mt-4 leading-loose">{settings.certified_pricing_policy}</p><p className="mt-3 text-sm text-muted-foreground">لا يُطلب دفع قبل عرض السعر وموافقتك عليه. الدفع الإلكتروني وإرسال الدعوات بالبريد غير مفعّلين حاليًا.</p></section>
  </main>;
}