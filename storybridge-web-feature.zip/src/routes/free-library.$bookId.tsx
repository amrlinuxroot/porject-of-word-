import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/free-library/$bookId")({
  head: () => ({
    meta: [
      { title: "Read — Free Library | Project of Word" },
      { name: "description", content: "A translation donated to the Project of Word free library." },
      { property: "og:title", content: "Free Library book — Project of Word" },
      { property: "og:description", content: "Read this donated translation for free." },
      { property: "og:type", content: "book" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReadBook,
});

function ReadBook() {
  const { bookId } = Route.useParams();
  const { data: b, isLoading } = useQuery({
    queryKey: ["free-book", bookId],
    queryFn: async () => (await supabase.from("donated_books").select("*").eq("id", bookId).maybeSingle()).data,
  });
  if (isLoading) return <p className="p-10 text-center text-muted-foreground">Loading…</p>;
  if (!b) return <p className="p-10 text-center text-muted-foreground">Book not found.</p>;
  const rtl = ["Arabic", "Persian", "Urdu"].includes(b.language);
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Link to="/free-library" className="text-sm text-primary">← Free Library</Link>
      {b.status !== "approved" && <p className="mt-3 rounded-md bg-muted p-2 text-sm">Waiting for admin approval — only you and admins can see this.</p>}
      <h1 className="mt-3 text-4xl font-semibold">{b.title}</h1>
      <p className="text-muted-foreground">{b.author}{b.translator_name && ` · translated by ${b.translator_name}`} · {b.language}</p>
      <p className="mt-3 text-sm text-muted-foreground">نسبة مشاركة الذكاء الاصطناعي (إفصاح المترجم): {b.ai_contribution_percent === null ? 'لم تُذكر — عمل سابق' : `${b.ai_contribution_percent}%`}</p>
      <article dir={rtl ? "rtl" : "ltr"} className="mt-8 whitespace-pre-wrap rounded-lg border bg-paper p-6 font-serif text-lg leading-relaxed shadow-page">{b.content}</article>
    </div>
  );
}
