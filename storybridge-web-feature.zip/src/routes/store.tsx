import { createFileRoute } from "@tanstack/react-router";
import { BookList } from "@/components/BookList";

export const Route = createFileRoute("/store")({
  head: () => ({
    meta: [
      { title: "Store — Project of Word" },
      { name: "description", content: "Buy our translated books. Every sale pays the translators." },
      { property: "og:title", content: "Store — Project of Word" },
      { property: "og:description", content: "Every sale pays the translators who made the book." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-4xl font-semibold">Store</h1>
      <p className="mb-8 mt-2 max-w-xl text-muted-foreground">Every purchase is shared among the book's translators, with a small part covering operating costs. We keep no profit.</p>
      <BookList store />
    </div>
  ),
});
