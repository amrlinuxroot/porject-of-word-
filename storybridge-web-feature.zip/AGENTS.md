<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- Member documents use an owner/admin-readable private bucket and permission declaration; personal tasks are owner-only and inbox reuses consent-gated direct_messages. Why: no new public file or messaging access path.
- Institution verification uses immutable owner submissions in a separate private table and bucket; only admins can update review fields. Why: classification must not grant verified status or expose identity evidence.
- Certified services use separate private request, preference, credential and immutable charter-signature tables; SQL guards enforce reviewed matching accreditation and signed confidentiality before assignment/file access. Why: sensitive documents must never enter public collaborative projects or trust browser eligibility.
- Certified opportunity/project invitations are language-matched SQL-triggered in-app notifications, and paid jobs use admin quotes with owner-only acceptance. Why: protect document content and avoid inventing prices or implying payment collection.
- Pages read/write Lovable Cloud tables directly from the browser client; access is enforced by RLS policies. Why: simple CRUD, no privileged logic needed.
- Winner selection runs in the `select_best_translations` SQL function (security definer, owner/admin check) which also writes notifications. Why: atomic and tamper-proof.
- Revenue split logic lives in `src/lib/text.ts` with tests in `src/lib/text.test.ts`. Why: single source for the charity's payout rule.
- Editable site info (contact, Discord, IBAN) lives in `site_settings` rows read via `useSettings` in `src/lib/settings.ts`, with code defaults as fallback. Why: admins edit without code changes.
- Admin team changes go through `set_admin_by_email` / `list_admins` SQL functions (security definer, admin check). Why: needs auth.users lookup.
- AI tools run in `src/lib/ai.functions.ts` (authenticated server function, AI Gateway SDK). Why: keeps keys and prompts server-side.
- Mailbox completeness/assembly logic lives in `src/lib/mailbox.ts` with tests. Why: single source for "book is complete" rule.
- Visitor suggestions go into `book_suggestions` (anon insert only, admin read) with rights/permission fields required by RLS. Why: every work must have documented translation rights before a project starts.
- The 5-active-project limit is enforced by the `enforce_project_limit` trigger on `project_members`; the constant lives in `src/lib/text.ts`. Why: cannot be bypassed from the browser.
- Large files (PDF, EPUB, video) live on external storage (link stored on projects/suggestions; provider set in site_settings). Why: keep big data off the app's host.
- Public AI search (`aiSearch`) only ranks published catalogue entries passed by the client. Why: no private data in an unauthenticated call.
- Project videos upload to the private `project-videos` bucket under `<projectId>/`, owner/admin write, members read via signed URLs; path stored in `projects.video_path`. Why: big files kept private, progress needs XHR to the storage endpoint.
- Subtitle validation/export (`validateSegments`, `toSrt`, `toVtt`) lives in `src/lib/text.ts`; downloads are blocked while errors exist. Why: one rule set for preview and export.
- Founder names live in `src/lib/founders.ts`. Why: footer and About page share one list.
- Personal projects include owned and joined work via `src/lib/projects.ts`; `/dashboard` is the member landing and `/explore` is global discovery. Why: ownership does not automatically create membership.
- Poetry uses existing project translation/voting with explicit poem boundaries; members' original poems, discussions and sessions use separate poetry tables. Why: sharing a poem must not automatically authorize translation.
- Technical specialisms share the project field catalogue; code/explanation modes extend authenticated aiAssist and never execute code. Why: preserve collaborative translation and review workflows.
- Public email directory filters member_contacts through server-enforced member_privacy audiences; private notification email uses owner-only RPC and column grants. Why: prevent directory/profile access from exposing hidden email.
- Member activity uses server-stamped browser heartbeats; only admins can read other members' activity. Why: show recent connections without trusting client clocks or exposing presence publicly.
- Private chat uses direct_messages with participant-only reads and recipient-audience INSERT policy; nobody, including admins, bypasses a closed inbox. Why: protect both conversation history and recipient consent.
- Combined technical AI results keep source code byte-for-byte in a separate original section via assembleTechnicalResult; commentary translation stays separate. Why: generated edits must not alter executable identifiers or code.
- Interface localization uses i18next, compile-time UiText wrapping and allowlisted static AI catalogs with browser cache. Why: translate pages without sending private/user content or changing stored option values.
- Generated localization strings use JSX expression containers, including implicit option values. Why: quoted labels must remain valid JavaScript instead of producing invalid Unicode escapes in JSX attributes.
- Collaboration books/software use separate projects, applications and contributions; publication URLs are manually recorded. Why: original authorship is distinct from translation and external publishing requires platform accounts.
- Human review/ethics declarations and book AI percentages are guarded in SQL; admin/selection review remains required. Why: declarations cannot prove actual review.
- First-visit homepage language uses request country metadata then browser-language fallback, with saved manual choice taking priority. Why: country may be unavailable in preview and visitors must retain control.
