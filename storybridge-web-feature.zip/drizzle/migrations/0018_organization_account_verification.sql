CREATE TABLE public.organization_verifications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES public.profiles(id),
 organization_type text NOT NULL CHECK (organization_type IN ('government','university')),
 organization_name text NOT NULL CHECK (length(trim(organization_name)) >= 3),
 country text NOT NULL CHECK (length(trim(country)) >= 2),
 representative_name text NOT NULL CHECK (length(trim(representative_name)) >= 3),
 identity_path text NOT NULL,
 certificate_paths text[] NOT NULL CHECK (cardinality(certificate_paths) BETWEEN 1 AND 10),
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
 review_note text NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now(),
 reviewed_at timestamptz
);
GRANT SELECT, INSERT ON public.organization_verifications TO authenticated;
GRANT UPDATE (status, review_note, reviewed_at) ON public.organization_verifications TO authenticated;
GRANT ALL ON public.organization_verifications TO service_role;
ALTER TABLE public.organization_verifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Organization owner and admin read" ON public.organization_verifications FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "Organization owner submits pending" ON public.organization_verifications FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND status = 'pending' AND review_note = '' AND reviewed_at IS NULL AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.registration_type = organization_type));
CREATE POLICY "Admin reviews organizations" ON public.organization_verifications FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE FUNCTION public.validate_organization_evidence() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE prefix text; item text;
BEGIN
 prefix := NEW.user_id::text || '/' || NEW.id::text || '/';
 IF left(NEW.identity_path,length(prefix)) <> prefix OR NEW.identity_path LIKE '%..%' THEN RAISE EXCEPTION 'Invalid identity evidence path'; END IF;
 FOREACH item IN ARRAY NEW.certificate_paths LOOP
 IF item IS NULL OR left(item,length(prefix)) <> prefix OR item LIKE '%..%' THEN RAISE EXCEPTION 'Invalid certificate evidence path'; END IF;
 END LOOP;
 RETURN NEW;
END; $$;
CREATE TRIGGER validate_organization_evidence BEFORE INSERT ON public.organization_verifications FOR EACH ROW EXECUTE FUNCTION public.validate_organization_evidence();
CREATE POLICY "Private organization evidence read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'organization-verification' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.has_role(auth.uid(),'admin')));
CREATE POLICY "Owner uploads organization evidence" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'organization-verification' AND (storage.foldername(name))[1] = auth.uid()::text AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND registration_type IN ('government','university')) AND lower(storage.extension(name)) IN ('pdf','jpg','jpeg','png') AND NOT EXISTS (SELECT 1 FROM public.organization_verifications v WHERE v.user_id = auth.uid() AND v.id::text = (storage.foldername(name))[2]));
CREATE POLICY "Owner removes unsubmitted organization evidence" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'organization-verification' AND (storage.foldername(name))[1] = auth.uid()::text AND NOT EXISTS (SELECT 1 FROM public.organization_verifications v WHERE v.user_id = auth.uid() AND v.id::text = (storage.foldername(name))[2]));