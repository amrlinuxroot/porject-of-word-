ALTER TABLE public.projects ADD COLUMN video_path text NOT NULL DEFAULT '';

CREATE POLICY "members read project videos" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'project-videos');
CREATE POLICY "owner uploads project videos" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'project-videos' AND EXISTS (
    SELECT 1 FROM public.projects p WHERE p.id::text = (storage.foldername(name))[1]
      AND (p.created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))));
CREATE POLICY "owner deletes project videos" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'project-videos' AND EXISTS (
    SELECT 1 FROM public.projects p WHERE p.id::text = (storage.foldername(name))[1]
      AND (p.created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))));