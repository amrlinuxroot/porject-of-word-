CREATE TABLE public.site_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_settings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings public read" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin insert settings" ON public.site_settings FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin update settings" ON public.site_settings FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete settings" ON public.site_settings FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.donated_books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 300),
  author text NOT NULL DEFAULT '',
  translator_name text NOT NULL DEFAULT '',
  language text NOT NULL,
  original_language text NOT NULL DEFAULT '',
  field text NOT NULL DEFAULT 'Literary',
  description text NOT NULL DEFAULT '',
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 2000000),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  submitted_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.donated_books TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.donated_books TO authenticated;
GRANT ALL ON public.donated_books TO service_role;
ALTER TABLE public.donated_books ENABLE ROW LEVEL SECURITY;
CREATE POLICY "approved books public" ON public.donated_books FOR SELECT TO anon USING (status = 'approved');
CREATE POLICY "members see approved, own, or admin" ON public.donated_books FOR SELECT TO authenticated USING (status = 'approved' OR submitted_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "donate as self pending" ON public.donated_books FOR INSERT TO authenticated WITH CHECK (submitted_by = auth.uid() AND status = 'pending');
CREATE POLICY "admin reviews books" ON public.donated_books FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "own or admin delete book" ON public.donated_books FOR DELETE TO authenticated USING (submitted_by = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE TABLE public.mailbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL,
  project_number text NOT NULL,
  page_number integer NOT NULL CHECK (page_number > 0),
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 50000),
  note text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','accepted','rejected')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mailbox TO authenticated;
GRANT ALL ON public.mailbox TO service_role;
ALTER TABLE public.mailbox ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own or admin read mail" ON public.mailbox FOR SELECT TO authenticated USING (sender_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "send as self" ON public.mailbox FOR INSERT TO authenticated WITH CHECK (sender_id = auth.uid() AND status = 'received');
CREATE POLICY "admin updates mail" ON public.mailbox FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "own or admin delete mail" ON public.mailbox FOR DELETE TO authenticated USING (sender_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE POLICY "admins read all roles" ON public.user_roles FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.set_admin_by_email(_email text, _make_admin boolean)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE uid uuid; cnt int;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Not allowed'; END IF;
  SELECT id INTO uid FROM auth.users WHERE lower(email) = lower(trim(_email));
  IF uid IS NULL THEN RAISE EXCEPTION 'No account with that email yet — ask them to sign up first'; END IF;
  IF _make_admin THEN
    INSERT INTO public.user_roles(user_id, role) VALUES (uid,'admin') ON CONFLICT DO NOTHING;
  ELSE
    SELECT count(*) INTO cnt FROM public.user_roles WHERE role='admin';
    IF cnt <= 1 THEN RAISE EXCEPTION 'At least one admin must remain'; END IF;
    DELETE FROM public.user_roles WHERE user_id = uid AND role = 'admin';
  END IF;
  RETURN 'ok';
END $$;

CREATE OR REPLACE FUNCTION public.list_admins()
RETURNS TABLE(user_id uuid, email text, display_name text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Not allowed'; END IF;
  RETURN QUERY SELECT r.user_id, u.email::text, p.display_name FROM public.user_roles r
    JOIN auth.users u ON u.id = r.user_id LEFT JOIN public.profiles p ON p.id = r.user_id WHERE r.role = 'admin';
END $$;
REVOKE EXECUTE ON FUNCTION public.set_admin_by_email(text, boolean) FROM anon;
REVOKE EXECUTE ON FUNCTION public.list_admins() FROM anon;