CREATE TABLE public.member_documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id), title text NOT NULL CHECK(length(trim(title))>0), file_name text NOT NULL, file_path text NOT NULL UNIQUE, rights_confirmed boolean NOT NULL DEFAULT false CHECK(rights_confirmed), created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT,INSERT,DELETE ON public.member_documents TO authenticated;
GRANT ALL ON public.member_documents TO service_role;
ALTER TABLE public.member_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY documents_read ON public.member_documents FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY documents_insert ON public.member_documents FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid() AND split_part(file_path,'/',1)=auth.uid()::text AND file_path NOT LIKE '%..%');
CREATE POLICY documents_delete ON public.member_documents FOR DELETE TO authenticated USING(user_id=auth.uid());
CREATE TABLE public.member_tasks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES public.profiles(id), title text NOT NULL CHECK(length(trim(title))>0), description text NOT NULL DEFAULT '', status text NOT NULL DEFAULT 'todo' CHECK(status IN ('todo','in_progress','done')), priority text NOT NULL DEFAULT 'normal' CHECK(priority IN ('low','normal','high')), due_date date, created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.member_tasks TO authenticated;
GRANT ALL ON public.member_tasks TO service_role;
ALTER TABLE public.member_tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY tasks_owner ON public.member_tasks FOR ALL TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
CREATE POLICY member_document_upload ON storage.objects FOR INSERT TO authenticated WITH CHECK(bucket_id='member-documents' AND (storage.foldername(name))[1]=auth.uid()::text AND lower(storage.extension(name)) IN ('pdf','txt','doc','docx','jpg','jpeg','png'));
CREATE POLICY member_document_read ON storage.objects FOR SELECT TO authenticated USING(bucket_id='member-documents' AND ((storage.foldername(name))[1]=auth.uid()::text OR public.has_role(auth.uid(),'admin')));
CREATE POLICY member_document_delete ON storage.objects FOR DELETE TO authenticated USING(bucket_id='member-documents' AND (storage.foldername(name))[1]=auth.uid()::text);