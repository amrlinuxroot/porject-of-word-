CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL,
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read chat" ON public.messages FOR SELECT TO authenticated USING (true);
CREATE POLICY "members post as self" ON public.messages FOR INSERT TO authenticated WITH CHECK (sender_id = auth.uid());
CREATE POLICY "own or admin delete" ON public.messages FOR DELETE TO authenticated USING (sender_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  translator_id uuid NOT NULL,
  created_by uuid NOT NULL,
  topic text NOT NULL,
  starts_at timestamptz NOT NULL,
  meet_link text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meetings TO authenticated;
GRANT ALL ON public.meetings TO service_role;
ALTER TABLE public.meetings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "see own or admin" ON public.meetings FOR SELECT TO authenticated USING (translator_id = auth.uid() OR created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin creates" ON public.meetings FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin') AND created_by = auth.uid());
CREATE POLICY "admin updates" ON public.meetings FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin deletes" ON public.meetings FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.notify_meeting() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.notifications(user_id, message, link)
  VALUES (NEW.translator_id, 'Meeting scheduled: ' || NEW.topic || ' — ' || to_char(NEW.starts_at AT TIME ZONE 'Europe/Berlin', 'YYYY-MM-DD HH24:MI') || ' (Berlin)', '/meetings');
  RETURN NEW;
END $$;
CREATE TRIGGER meetings_notify AFTER INSERT ON public.meetings FOR EACH ROW EXECUTE FUNCTION public.notify_meeting();

CREATE OR REPLACE FUNCTION public.grant_admin_by_email() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF lower(NEW.email) = 'info@amrdarweesh.de' THEN
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_admin AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_admin_by_email();