-- Additive migration: shared team files and per-member external storage links.
-- Existing personal documents and their storage bucket are unchanged.

CREATE TABLE public.team_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.collaboration_projects(id) ON DELETE CASCADE,
  uploader_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 200),
  file_name text NOT NULL CHECK (lower(file_name) ~ '\.(pdf|doc|docx|txt)$'),
  file_path text NOT NULL UNIQUE,
  content_type text NOT NULL,
  file_size bigint NOT NULL CHECK (file_size BETWEEN 1 AND 20971520),
  rights_confirmed boolean NOT NULL DEFAULT false CHECK (rights_confirmed),
  is_shared boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (content_type IN ('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain')),
  CHECK (file_path = project_id::text || '/' || uploader_id::text || '/' || split_part(file_path, '/', 3)),
  CHECK (file_path !~ '(^|/)\.\.?(/|$)'),
  CHECK (array_length(string_to_array(file_path, '/'), 1) = 3),
  CHECK (split_part(file_path, '/', 3) <> '')
);

CREATE INDEX team_files_project_created_idx ON public.team_files (project_id, created_at DESC);
CREATE INDEX team_files_uploader_idx ON public.team_files (uploader_id, created_at DESC);
GRANT SELECT, INSERT, DELETE ON public.team_files TO authenticated;
GRANT UPDATE (is_shared) ON public.team_files TO authenticated;
GRANT ALL ON public.team_files TO service_role;
ALTER TABLE public.team_files ENABLE ROW LEVEL SECURITY;

CREATE POLICY team_files_read_authorized ON public.team_files
  FOR SELECT TO authenticated USING (
    public.has_role(auth.uid(), 'admin') OR EXISTS (
      SELECT 1 FROM public.collaboration_projects p
      WHERE p.id = team_files.project_id
        AND (p.owner_id = auth.uid() OR EXISTS (
          SELECT 1 FROM public.collaboration_members m
          WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
        ))
        AND (team_files.is_shared OR team_files.uploader_id = auth.uid() OR p.owner_id = auth.uid())
    )
  );

CREATE POLICY team_files_insert_member ON public.team_files
  FOR INSERT TO authenticated WITH CHECK (
    uploader_id = auth.uid()
    AND rights_confirmed
    AND file_path LIKE project_id::text || '/' || auth.uid()::text || '/%'
    AND EXISTS (
      SELECT 1 FROM public.collaboration_projects p
      WHERE p.id = project_id
        AND (p.owner_id = auth.uid() OR EXISTS (
          SELECT 1 FROM public.collaboration_members m
          WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
        ))
    )
  );

CREATE POLICY team_files_update_share ON public.team_files
  FOR UPDATE TO authenticated USING (
    public.has_role(auth.uid(), 'admin') OR EXISTS (
      SELECT 1 FROM public.collaboration_projects p
      WHERE p.id = project_id AND (p.owner_id = auth.uid() OR (
        uploader_id = auth.uid() AND EXISTS (
          SELECT 1 FROM public.collaboration_members m
          WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
        )
      ))
    )
  ) WITH CHECK (
    public.has_role(auth.uid(), 'admin') OR EXISTS (
      SELECT 1 FROM public.collaboration_projects p
      WHERE p.id = project_id AND (p.owner_id = auth.uid() OR (
        uploader_id = auth.uid() AND EXISTS (
          SELECT 1 FROM public.collaboration_members m
          WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
        )
      ))
    )
  );

CREATE POLICY team_files_delete_owner_or_uploader ON public.team_files
  FOR DELETE TO authenticated USING (
    uploader_id = auth.uid()
    OR public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.collaboration_projects p WHERE p.id = project_id AND p.owner_id = auth.uid())
  );

-- Private bucket; only PDF and Word/text files are allowed, with a 20 MiB cap.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'team-files', 'team-files', false, 20971520,
  ARRAY['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']
)
ON CONFLICT (id) DO NOTHING;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM storage.buckets
    WHERE id = 'team-files'
      AND name = 'team-files'
      AND public = false
      AND file_size_limit = 20971520
      AND allowed_mime_types @> ARRAY['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']::text[]
      AND cardinality(allowed_mime_types) = 4
  ) THEN
    RAISE EXCEPTION 'The existing team-files bucket does not match the required private upload settings; review it without changing existing data.';
  END IF;
END;
$$;

CREATE POLICY team_files_storage_upload_member ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (
    bucket_id = 'team-files'
    AND (storage.foldername(name))[2] = auth.uid()::text
    AND lower(storage.extension(name)) IN ('pdf', 'doc', 'docx', 'txt')
    AND EXISTS (
      SELECT 1 FROM public.collaboration_projects p
      WHERE p.id::text = (storage.foldername(name))[1]
        AND (p.owner_id = auth.uid() OR EXISTS (
          SELECT 1 FROM public.collaboration_members m
          WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
        ))
    )
  );

CREATE POLICY team_files_storage_read_authorized ON storage.objects
  FOR SELECT TO authenticated USING (
    bucket_id = 'team-files'
    AND EXISTS (
      SELECT 1 FROM public.team_files f
      JOIN public.collaboration_projects p ON p.id = f.project_id
      WHERE f.file_path = name
        AND (public.has_role(auth.uid(), 'admin') OR p.owner_id = auth.uid() OR EXISTS (
          SELECT 1 FROM public.collaboration_members m
          WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
        ))
        AND (f.is_shared OR f.uploader_id = auth.uid() OR p.owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
    )
  );

CREATE POLICY team_files_storage_delete_owner_or_uploader ON storage.objects
  FOR DELETE TO authenticated USING (
      bucket_id = 'team-files'
    AND (
      (storage.foldername(name))[2] = auth.uid()::text
      OR EXISTS (
        SELECT 1 FROM public.team_files f
        JOIN public.collaboration_projects p ON p.id = f.project_id
        WHERE f.file_path = name
          AND (p.owner_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
      )
    )
  );

CREATE TABLE public.member_cloud_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  project_id uuid REFERENCES public.collaboration_projects(id) ON DELETE CASCADE,
  provider text NOT NULL CHECK (provider IN ('box', 'google_drive', 'dropbox', 'onedrive', 'other')),
  label text NOT NULL CHECK (length(trim(label)) BETWEEN 1 AND 120),
  url text NOT NULL CHECK (url ~ '^https://[^[:space:]]+$'),
  visibility text NOT NULL DEFAULT 'private' CHECK (visibility IN ('private', 'team')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((visibility = 'private' AND project_id IS NULL) OR (visibility = 'team' AND project_id IS NOT NULL)),
  CHECK (url !~ '^https://[^/]*@'),
  CHECK (
    provider = 'other'
    OR (provider = 'box' AND (lower(split_part(split_part(url, '://', 2), '/', 1)) = 'box.com' OR lower(split_part(split_part(url, '://', 2), '/', 1)) LIKE '%.box.com'))
    OR (provider = 'google_drive' AND lower(split_part(split_part(url, '://', 2), '/', 1)) IN ('drive.google.com', 'docs.google.com'))
    OR (provider = 'dropbox' AND (lower(split_part(split_part(url, '://', 2), '/', 1)) = 'dropbox.com' OR lower(split_part(split_part(url, '://', 2), '/', 1)) LIKE '%.dropbox.com' OR lower(split_part(split_part(url, '://', 2), '/', 1)) = 'dl.dropboxusercontent.com'))
    OR (provider = 'onedrive' AND (lower(split_part(split_part(url, '://', 2), '/', 1)) IN ('onedrive.live.com', '1drv.ms', 'sharepoint.com') OR lower(split_part(split_part(url, '://', 2), '/', 1)) LIKE '%.sharepoint.com'))
  )
);

CREATE INDEX member_cloud_links_user_created_idx ON public.member_cloud_links (user_id, created_at DESC);
CREATE INDEX member_cloud_links_project_idx ON public.member_cloud_links (project_id) WHERE visibility = 'team';
GRANT SELECT, INSERT, UPDATE, DELETE ON public.member_cloud_links TO authenticated;
GRANT ALL ON public.member_cloud_links TO service_role;
ALTER TABLE public.member_cloud_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY member_cloud_links_read_owner_or_team ON public.member_cloud_links
  FOR SELECT TO authenticated USING (
    user_id = auth.uid()
    OR (
      visibility = 'team' AND project_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.collaboration_projects p
        WHERE p.id = project_id
          AND (p.owner_id = auth.uid() OR EXISTS (
            SELECT 1 FROM public.collaboration_members m
            WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
          ))
      )
    )
  );

CREATE POLICY member_cloud_links_insert_owner ON public.member_cloud_links
  FOR INSERT TO authenticated WITH CHECK (
    user_id = auth.uid()
    AND (
      (visibility = 'private' AND project_id IS NULL)
      OR (visibility = 'team' AND project_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.collaboration_projects p
        WHERE p.id = project_id
          AND (p.owner_id = auth.uid() OR EXISTS (
            SELECT 1 FROM public.collaboration_members m
            WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
          ))
      ))
    )
  );

CREATE POLICY member_cloud_links_update_owner ON public.member_cloud_links
  FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (
    user_id = auth.uid()
    AND (
      (visibility = 'private' AND project_id IS NULL)
      OR (visibility = 'team' AND project_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.collaboration_projects p
        WHERE p.id = project_id
          AND (p.owner_id = auth.uid() OR EXISTS (
            SELECT 1 FROM public.collaboration_members m
            WHERE m.project_id = p.id AND m.user_id = auth.uid() AND m.status = 'accepted'
          ))
      ))
    )
  );

CREATE POLICY member_cloud_links_delete_owner ON public.member_cloud_links
  FOR DELETE TO authenticated USING (user_id = auth.uid());
