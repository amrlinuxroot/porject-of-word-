
create type public.app_role as enum ('admin','translator');
create type public.project_status as enum ('translating','voting','published');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  bio text not null default '',
  languages text[] not null default '{}',
  fields text[] not null default '{}',
  expertise text not null default '',
  survey_completed boolean not null default false,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "profiles readable by members" on public.profiles for select to authenticated using (true);
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles readable" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)));
  insert into public.user_roles (user_id, role) values (new.id, 'translator');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create sequence public.project_number_seq start 1001;

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  project_number text not null unique default ('TR-' || nextval('public.project_number_seq')::text),
  title text not null,
  author text not null default '',
  description text not null default '',
  field text not null default 'Literary',
  source_language text not null,
  target_language text not null,
  status public.project_status not null default 'translating',
  ops_percent integer not null default 10,
  google_books_url text,
  kdp_url text,
  total_revenue_cents bigint not null default 0,
  created_by uuid not null,
  created_at timestamptz not null default now()
);
grant select on public.projects to anon;
grant select, insert, update, delete on public.projects to authenticated;
grant all on public.projects to service_role;
alter table public.projects enable row level security;
create policy "published projects public" on public.projects for select to anon using (status = 'published');
create policy "members read projects" on public.projects for select to authenticated using (true);
create policy "members create projects" on public.projects for insert to authenticated with check (auth.uid() = created_by);
create policy "owner or admin update" on public.projects for update to authenticated using (auth.uid() = created_by or public.has_role(auth.uid(),'admin'));
create policy "owner or admin delete" on public.projects for delete to authenticated using (auth.uid() = created_by or public.has_role(auth.uid(),'admin'));

create table public.pages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  page_number integer not null,
  original_text text not null,
  unique (project_id, page_number)
);
grant select on public.pages to anon;
grant select, insert, update, delete on public.pages to authenticated;
grant all on public.pages to service_role;
alter table public.pages enable row level security;
create policy "published pages public" on public.pages for select to anon using (exists (select 1 from public.projects p where p.id = project_id and p.status='published'));
create policy "members read pages" on public.pages for select to authenticated using (true);
create policy "owner writes pages" on public.pages for insert to authenticated with check (exists (select 1 from public.projects p where p.id = project_id and p.created_by = auth.uid()));
create policy "owner deletes pages" on public.pages for delete to authenticated using (exists (select 1 from public.projects p where p.id = project_id and p.created_by = auth.uid()));

create table public.translations (
  id uuid primary key default gen_random_uuid(),
  page_id uuid not null references public.pages(id) on delete cascade,
  translator_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  is_selected boolean not null default false,
  created_at timestamptz not null default now(),
  unique (page_id, translator_id)
);
grant select on public.translations to anon;
grant select, insert, update, delete on public.translations to authenticated;
grant all on public.translations to service_role;
alter table public.translations enable row level security;
create policy "selected translations public" on public.translations for select to anon using (is_selected and exists (select 1 from public.pages pg join public.projects p on p.id = pg.project_id where pg.id = page_id and p.status='published'));
create policy "members read translations" on public.translations for select to authenticated using (true);
create policy "translator inserts own" on public.translations for insert to authenticated with check (auth.uid() = translator_id and is_selected = false);
create policy "translator updates own" on public.translations for update to authenticated using (auth.uid() = translator_id and is_selected = false) with check (is_selected = false);
create policy "translator deletes own" on public.translations for delete to authenticated using (auth.uid() = translator_id and is_selected = false);

create table public.votes (
  translation_id uuid not null references public.translations(id) on delete cascade,
  voter_id uuid not null,
  created_at timestamptz not null default now(),
  primary key (translation_id, voter_id)
);
grant select, insert, delete on public.votes to authenticated;
grant all on public.votes to service_role;
alter table public.votes enable row level security;
create policy "members read votes" on public.votes for select to authenticated using (true);
create policy "vote as self, not own work" on public.votes for insert to authenticated with check (auth.uid() = voter_id and not exists (select 1 from public.translations t where t.id = translation_id and t.translator_id = auth.uid()));
create policy "remove own vote" on public.votes for delete to authenticated using (auth.uid() = voter_id);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  message text not null,
  link text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
grant select, update on public.notifications to authenticated;
grant all on public.notifications to service_role;
alter table public.notifications enable row level security;
create policy "own notifications" on public.notifications for select to authenticated using (auth.uid() = user_id);
create policy "mark own read" on public.notifications for update to authenticated using (auth.uid() = user_id);

-- Pick the most-voted translation for each page, mark it selected, notify the translator.
create or replace function public.select_best_translations(_project_id uuid)
returns integer language plpgsql security definer set search_path = public
as $$
declare r record; n integer := 0; proj public.projects;
begin
  select * into proj from public.projects where id = _project_id;
  if proj.id is null then raise exception 'Project not found'; end if;
  if proj.created_by <> auth.uid() and not public.has_role(auth.uid(),'admin') then raise exception 'Not allowed'; end if;
  update public.translations t set is_selected = false from public.pages pg where pg.id = t.page_id and pg.project_id = _project_id;
  for r in
    select distinct on (pg.id) pg.id as page_id, pg.page_number, t.id as tid, t.translator_id
    from public.pages pg join public.translations t on t.page_id = pg.id
    left join public.votes v on v.translation_id = t.id
    where pg.project_id = _project_id
    group by pg.id, pg.page_number, t.id, t.translator_id, t.created_at
    order by pg.id, count(v.voter_id) desc, t.created_at asc
  loop
    update public.translations set is_selected = true where id = r.tid;
    insert into public.notifications (user_id, message, link)
    values (r.translator_id, 'Your translation of page ' || r.page_number || ' in ' || proj.project_number || ' "' || proj.title || '" was selected!', '/projects/' || proj.id);
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.select_best_translations(uuid) from public, anon;
grant execute on function public.select_best_translations(uuid) to authenticated;

create table public.donations (
  id uuid primary key default gen_random_uuid(),
  amount_cents integer not null,
  donor_name text,
  created_at timestamptz not null default now()
);
grant select on public.donations to anon, authenticated;
grant all on public.donations to service_role;
alter table public.donations enable row level security;
create policy "donation totals public" on public.donations for select to anon, authenticated using (true);
