CREATE TABLE public.book_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL DEFAULT 'book',
  title text NOT NULL,
  author text NOT NULL DEFAULT '',
  original_language text NOT NULL DEFAULT '',
  target_languages text NOT NULL DEFAULT '',
  field text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  source_link text NOT NULL DEFAULT '',
  source_text text NOT NULL DEFAULT '',
  submitter_name text NOT NULL,
  submitter_email text NOT NULL,
  submitter_role text NOT NULL DEFAULT 'reader',
  has_copyright text NOT NULL,
  permission text NOT NULL,
  proof_link text NOT NULL DEFAULT '',
  proof_note text NOT NULL DEFAULT '',
  rights_holder_name text NOT NULL DEFAULT '',
  rights_holder_email text NOT NULL DEFAULT '',
  author_wants_royalty boolean NOT NULL DEFAULT false,
  declaration boolean NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  admin_note text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.book_suggestions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.book_suggestions TO authenticated;
GRANT ALL ON public.book_suggestions TO service_role;
ALTER TABLE public.book_suggestions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone suggests" ON public.book_suggestions FOR INSERT TO anon, authenticated
  WITH CHECK (status = 'pending' AND declaration = true AND length(title) BETWEEN 1 AND 300 AND length(submitter_email) BETWEEN 3 AND 255);
CREATE POLICY "admin reads suggestions" ON public.book_suggestions FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin updates suggestions" ON public.book_suggestions FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin deletes suggestions" ON public.book_suggestions FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

ALTER TABLE public.profiles
  ADD COLUMN contributor_role text NOT NULL DEFAULT 'translator',
  ADD COLUMN institution text NOT NULL DEFAULT '',
  ADD COLUMN study_level text NOT NULL DEFAULT '',
  ADD COLUMN notify_email text NOT NULL DEFAULT '';

ALTER TABLE public.projects
  ADD COLUMN media_type text NOT NULL DEFAULT 'book',
  ADD COLUMN video_url text NOT NULL DEFAULT '',
  ADD COLUMN source_link text NOT NULL DEFAULT '',
  ADD COLUMN author_royalty_percent integer NOT NULL DEFAULT 0;

ALTER TABLE public.pages
  ADD COLUMN start_time text NOT NULL DEFAULT '',
  ADD COLUMN end_time text NOT NULL DEFAULT '';

CREATE TABLE public.project_members (
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (project_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.project_members TO authenticated;
GRANT ALL ON public.project_members TO service_role;
ALTER TABLE public.project_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read membership" ON public.project_members FOR SELECT TO authenticated USING (true);
CREATE POLICY "join as self" ON public.project_members FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "leave self or admin" ON public.project_members FOR DELETE TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.enforce_project_limit() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF (SELECT count(*) FROM public.project_members m JOIN public.projects p ON p.id = m.project_id
      WHERE m.user_id = NEW.user_id AND p.status <> 'published') >= 5 THEN
    RAISE EXCEPTION 'You can join at most 5 active projects at a time.';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER project_limit BEFORE INSERT ON public.project_members FOR EACH ROW EXECUTE FUNCTION public.enforce_project_limit();