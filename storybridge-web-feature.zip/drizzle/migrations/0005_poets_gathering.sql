CREATE TABLE public.poetry_posts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 author_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 title text NOT NULL CHECK (length(trim(title)) > 0),
 content text NOT NULL CHECK (length(trim(content)) > 0),
 language text NOT NULL DEFAULT '',
 rights_confirmed boolean NOT NULL DEFAULT false CHECK (rights_confirmed),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.poetry_posts TO authenticated;
GRANT ALL ON public.poetry_posts TO service_role;
ALTER TABLE public.poetry_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read poems" ON public.poetry_posts FOR SELECT TO authenticated USING (true);
CREATE POLICY "authors post own poems" ON public.poetry_posts FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid() AND rights_confirmed);
CREATE POLICY "authors or admins delete poems" ON public.poetry_posts FOR DELETE TO authenticated USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE TABLE public.poetry_comments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 post_id uuid NOT NULL REFERENCES public.poetry_posts(id) ON DELETE CASCADE,
 author_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 content text NOT NULL CHECK (length(trim(content)) > 0),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.poetry_comments TO authenticated;
GRANT ALL ON public.poetry_comments TO service_role;
ALTER TABLE public.poetry_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read poetry discussions" ON public.poetry_comments FOR SELECT TO authenticated USING (true);
CREATE POLICY "members comment as self" ON public.poetry_comments FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid());
CREATE POLICY "authors or admins delete comments" ON public.poetry_comments FOR DELETE TO authenticated USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE TABLE public.poetry_sessions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 host_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 title text NOT NULL CHECK (length(trim(title)) > 0),
 description text NOT NULL DEFAULT '',
 starts_at timestamptz NOT NULL,
 meeting_url text NOT NULL CHECK (meeting_url ~ '^https://'),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.poetry_sessions TO authenticated;
GRANT ALL ON public.poetry_sessions TO service_role;
ALTER TABLE public.poetry_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read poetry sessions" ON public.poetry_sessions FOR SELECT TO authenticated USING (true);
CREATE POLICY "members host own sessions" ON public.poetry_sessions FOR INSERT TO authenticated WITH CHECK (host_id = auth.uid());
CREATE POLICY "hosts or admins cancel sessions" ON public.poetry_sessions FOR DELETE TO authenticated USING (host_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE INDEX poetry_comments_post_idx ON public.poetry_comments(post_id, created_at);
CREATE INDEX poetry_sessions_starts_idx ON public.poetry_sessions(starts_at);