<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# النجم الهادي

أن يقرأ الناس في كل مكان بلغتهم كتبًا لم يكن بإمكانهم قراءتها من قبل

## المقياس

عدد الساعات التي يقضيها القرّاء في قراءة الكتب المترجمة كل أسبوع
