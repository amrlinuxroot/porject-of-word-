import { parse } from '@babel/parser';
import traverse from '@babel/traverse';
import generate from '@babel/generator';
import * as t from '@babel/types';
// Compile-time wrapping: never collect text from the rendered DOM or translate form/data values.
export function interfaceLocalization() {
 return { name:'project-word-interface-localization', enforce:'pre', transform(code,id) {
  const file=id.split('?')[0];
  if(!file?.endsWith('.tsx') || !/\/src\/(routes|components)\//.test(file) || /\/(ui|UiText|HomeLanguage)\//.test(file) || /\/(UiText|HomeLanguage)\.tsx$/.test(file)) return null;
  const ast=parse(code,{sourceType:'module',plugins:['typescript','jsx']});let changed=false;
  const textCall=value=>t.callExpression(t.identifier('uiText'),[t.stringLiteral(value)]);
  traverse(ast,{StringLiteral(p){if(!p.findParent(x=>x.isJSXExpressionContainer())||p.findParent(x=>x.isJSXAttribute())||!/[A-Za-z\u0600-\u06ff]/.test(p.node.value)||p.parent.type==='ObjectProperty'&&p.key==='key')return;
    if(p.parent.type==='CallExpression'||p.parent.type==='MemberExpression')return;
    const value=p.node.value;p.replaceWith(textCall(value));p.skip();changed=true;
  },JSXText(p){const value=p.node.value.replace(/\s+/g,' ');if(!value.trim()||!/[A-Za-z\u0600-\u06ff]/.test(value))return;
   if(p.parent.openingElement?.name?.name==='option'&&!p.parent.openingElement.attributes.some(a=>a.name?.name==='value'))p.parent.openingElement.attributes.push(t.jsxAttribute(t.jsxIdentifier('value'),t.jsxExpressionContainer(t.stringLiteral(value))));
   p.replaceWith(t.jsxElement(t.jsxOpeningElement(t.jsxIdentifier('UiText'),[t.jsxAttribute(t.jsxIdentifier('source'),t.jsxExpressionContainer(t.stringLiteral(value)))],true),null,[],true));changed=true;
  }});
  if(!changed)return null;
  ast.program.body.unshift(t.importDeclaration([t.importSpecifier(t.identifier('UiText'),t.identifier('UiText'))],t.stringLiteral('@/components/UiText')),t.importDeclaration([t.importSpecifier(t.identifier('uiText'),t.identifier('uiText'))],t.stringLiteral('@/lib/interface-language')));
  return {code:generate(ast,{retainLines:true,jsescOption:{minimal:true}},code).code,map:null};
 }};
}